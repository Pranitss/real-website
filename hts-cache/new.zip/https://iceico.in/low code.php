<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>ICEICO - Low Code</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Favicons -->
    <!-- <link href="assets/img/favicon.png" rel="icon"> -->
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

    <!-- jquery cdn -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.3/jquery.min.js" integrity="sha512-STof4xm1wgkfm7heWqFJVn58Hm3EtS31XFaagaa8VMReCXAkQnJZ+jEy8PCC/iT18dFy95WcExNHFTqLyp72eQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Vendor CSS Files -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <link href="assets/vendor/aos/aos.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
    <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

    <!--Main CSS File -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/img_slider.css" rel="stylesheet">
    <link href="assets/css/slick.min.css" rel="stylesheet">
    <link href="assets/css/MultipleTestimonial_Slider.min.css" rel="stylesheet">

    <style>
        .position-absolute {
            position: absolute;
            bottom: 20px;
            left: 35px;
        }

        .img-s {
            aspect-ratio: 3/2 !important;
            width: 50%;
            /* height: 30%; */
            object-fit: contain;
        }
    </style>

</head>

<body id="aboutbg">

    <!-- ======= Header ======= -->
    <!-- ======= Header ======= -->

<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
    <div class="container-xl">
        <a class="navbar-brand" href="index.php"><img src="assets/img/Group 1.png" alt="logo" class="img-fluid" style="max-width: 100%; width: 70px" /></a>
        <button class="navbar-toggler collapsed" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon" style="width: 5vw"></span>
        </button>
        <div class="navbar-collapse collapse" id="navbarNavDropdown" style="">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <div class="separator" style="
                        height: 1px;
                        border-top: 1px solid rgba(255, 255, 255, 0.55);
                        margin-left: 20px;
                        margin-right: 20px;
                        width: 150px;
                        flex: 1;
                        margin-top: 20px;
            "></div>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="industries.php" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Industries
                    </a>
                    <ul class="text-light dropdown-menu p-3 pt-3 pb-3" aria-labelledby="navbarDropdownMenuLink">
                        <li>
                            <a class="link-light dropdown-item" href="gaming.php">Gaming &amp; Entertainment</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="life-sciences.php">Life sciences &amp;
                                healthcare</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="media.php">Media &amp; publishing</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="non-profits.php">Non-profits and education</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="retails.php">Retail &amp; cpg</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="smart-buildings.php">Smart buildings</a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Services
                    </a>
                    <ul class="container container-sm text-light dropdown-menu overflow dropdown-menu-scrollable" aria-labelledby="navbarDropdownMenuLink" style="width: 100vw; left: -400px; margin: 0px -20px">
                        <li class="p-2 pb-5 pt-5 row">
                            <section class="col-lg-3 col-md-12 col-sm-12 d-lg-block d-md-none">
                                <ul class="mylist">
                                    <li>
                                        <div class="menu-title fs-3">Services</div>
                                    </li>
                                    <li>
                                        <p class="">
                                            Accelerate your vision with technologies that are both
                                            agile and cutting edge.
                                        </p>
                                    </li>
                                    <li class="position-absolute top-50">
                                        <a href="all_services.php" class="link-light p-5 pt-2 pb-2 bg-success link-hover d-none d-lg-block" style="border-radius: 50px">view all services</a>
                                    </li>
                                </ul>
                            </section>
                            <section class="col-lg-3 col-md-12 col-sm-12">
                                <ul class="mylist">
                                    <li>
                                        <a href="accelerated-quality.php" class="link-light dropdown-item">
                                            <h6>accelerated quality &amp; test-engineering</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="agile.php" class="link-light dropdown-item">
                                            <h6>agile</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="api-mgmt.php" class="link-light dropdown-item">
                                            <h6>api management</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="app-develop.php" class="link-light dropdown-item">
                                            <h6>application development</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="app-manage.php" class="link-light dropdown-item">
                                            <h6>application managed services</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="ai-da.php" class="link-light dropdown-item">
                                            <h6>artificial intelligence, data &amp; analytics</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="blockchain.php" class="link-light dropdown-item">
                                            <h6>blockchain</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="cloud.php" class="link-light dropdown-item">
                                            <h6>cloud</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="crm.php" class="link-light dropdown-item">
                                            <h6>crm</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="customer-communications.php" class="link-light dropdown-item">
                                            <h6>customer communications</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="design.php" class="link-light dropdown-item">
                                            <h6>design</h6>
                                        </a>
                                    </li>
                                </ul>
                            </section>
                            <section class="col-lg-3 col-md-12 col-sm-12">
                                <ul class="mylist">
                                    <li>
                                        <a href="devops.php" class="link-light dropdown-item">
                                            <h6>devops</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="digital-commerce.php" class="link-light dropdown-item">
                                            <h6>digital commerce</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="digital-experiences.php" class="link-light dropdown-item">
                                            <h6>digital experiences</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="digital-ventures.php" class="link-light dropdown-item">
                                            <h6>digital ventures</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="ecm-&amp;-portals.php" class="link-light dropdown-item">
                                            <h6>ecm &amp; portals</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="embedded.php" class="link-light dropdown-item">
                                            <h6>embedded systems</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="enterprising consu.php" class="link-light dropdown-item">
                                            <h6>enterprise architecture consulting</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="erp.php" class="link-light dropdown-item">
                                            <h6>erp</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="identify man.php" class="link-light dropdown-item">
                                            <h6>identity and access management</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="inovation.php" class="link-light dropdown-item">
                                            <h6>innovation</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="internet of things.php" class="link-light dropdown-item">
                                            <h6>internet of things</h6>
                                        </a>
                                    </li>
                                </ul>
                            </section>
                            <section class="col-lg-3 col-md-12 col-sm-12">
                                <ul class="mylist">
                                    <li>
                                        <a href="low code.php" class="link-light dropdown-item">
                                            <h6>low code</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="mainfraim &amp; legacy.php" class="link-light dropdown-item">
                                            <h6>mainframe &amp; legacy</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="mobility solu.php" class="link-light dropdown-item">
                                            <h6>mobility solutions</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="process consulting.php" class="link-light dropdown-item">
                                            <h6>process consulting</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="product engeeniring.php" class="link-light dropdown-item">
                                            <h6>product engineering</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="resilience_engineering.php" class="link-light dropdown-item">
                                            <h6>resilience engineering</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="sap_services.php" class="link-light dropdown-item">
                                            <h6>sap services</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="security.php" class="link-light dropdown-item">
                                            <h6>security</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="technical_communication.php" class="link-light dropdown-item">
                                            <h6>technical communication</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="trainings.php" class="link-light dropdown-item">
                                            <h6>trainings</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="transformation.php" class="link-light dropdown-item">
                                            <h6>transformation and modernization</h6>
                                        </a>
                                    </li>
                                </ul>
                            </section>
                        </li>
                    </ul>
                </li>
                <li class="nav-item dropdown overflow">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Insights
                    </a>
                    <ul class="container container-sm text-light dropdown-menu dropdown-menu-scrollable" aria-labelledby="navbarDropdownMenuLink" style="width: 100vw; left: -490px; margin: 0 -20px">
                        <li class="container container-sm insight p-2 pb-4 pt-4" style="width: 100vw; left: -825px">
                            <div class="headings">
                                <div class="row text-center p-1 d-lg-flex d-md-none">
                                    <div class="col-md-6 fs-2">Thinking Breakthroughs</div>
                                    <div class="col-md-6">
                                        <a href="#" class="link-light p-5 pt-2 pb-2 bg-success link-hover d-none d-lg-inline-block">
                                            Explore our best ideas</a>
                                    </div>
                                </div>
                                <hr />
                                <div class="row p-5 pt-4 pb-4">
                                    <section class="col-lg-4 col-md-12 col-sm-12">
                                        <ul class="mylist">
                                            <li>
                                                <div class="fs-6 p-3 pt-0 pb-0 text-success">Filter by Goal</div>
                                            </li>
                                            <li>
                                                <a href="modernize.php" class="link-light dropdown-item fs-3">Modernize</a>
                                            </li>
                                            <li>
                                                <a href="optimize.php" class="link-light dropdown-item fs-3">Optimize</a>
                                            </li>
                                            <li>
                                                <a href="innovate.php" class="link-light dropdown-item fs-3">Innovate</a>
                                            </li>
                                            <li>
                                                <a href="disrupt.php" class="link-light dropdown-item fs-3">Disrupt</a>
                                            </li>
                                            <li>
                                                <a href="transform.php" class="link-light dropdown-item fs-3">Transform</a>
                                            </li>
                                        </ul>
                                    </section>
                                    <section class="col-lg-4 col-md-12 col-sm-12 border-right" style="border-left: 1px solid #999">
                                        <ul class="mylist">
                                            <li>
                                                <div class="fs-6 p-3 pt-0 pb-0 text-success">
                                                    Trending technologies
                                                </div>
                                            </li>
                                            <li>
                                                <a href="ai_ml.php" class="link-light dropdown-item fs-5">AI and ML</a>
                                            </li>
                                            <li>
                                                <a href="data_science.php" class="link-light dropdown-item fs-5">Data Science</a>
                                            </li>
                                            <li>
                                                <a href="iot.php" class="link-light dropdown-item fs-5">IoT</a>
                                            </li>
                                            <li>
                                                <a href="low_code_ins.php" class="link-light dropdown-item fs-5">Low Code</a>
                                            </li>
                                            <li>
                                                <a href="api_ins.php" class="link-light dropdown-item fs-5">API-Management</a>
                                            </li>
                                            <li>
                                                <a href="aqt.php" class="link-light dropdown-item fs-5">AQT</a>
                                            </li>
                                            <li>
                                                <a href="cloud_ins.php" class="link-light dropdown-item fs-5">Cloud</a>
                                            </li>
                                            <li>
                                                <a href="agile_ins.php" class="link-light dropdown-item fs-5">Agile</a>
                                            </li>
                                            <li>
                                                <a href="devops_ins.php" class="link-light dropdown-item fs-5">DevOps</a>
                                            </li>
                                            <li>
                                                <a href="chaos_engineering.php" class="link-light dropdown-item fs-5">Chaos Engineering</a>
                                            </li>
                                            <li>
                                                <a href="data_mesh.php" class="link-light dropdown-item fs-5">Data Mesh</a>
                                            </li>
                                        </ul>
                                    </section>
                                    <section class="col-lg-4 col-md-12 col-sm-12 border-right" style="border-left: 1px solid #999">
                                        <ul class="mylist">
                                            <li>
                                                <div class="fs-6 p-3 pt-0 pb-0 text-success">Industry</div>
                                            </li>
                                            <li>
                                                <a href="automotive_ins.php" class="link-light dropdown-item">Automotive</a>
                                            </li>
                                            <li>
                                                <a href="banking_financial_ins.php" class="link-light dropdown-item">Banking and Financial
                                                    Services</a>
                                            </li>
                                            <li>
                                                <a href="insurance_ins.php" class="link-light dropdown-item">Insurance</a>
                                            </li>
                                            <li>
                                                <a href="energy_ins.php" class="link-light dropdown-item">Energy and Utilities</a>
                                            </li>
                                            <li>
                                                <a href="gaming_ins.php" class="link-light dropdown-item">Gaming and
                                                    Entertainment</a>
                                            </li>
                                            <li>
                                                <a href="isv_ins.php" class="link-light dropdown-item">ISV</a>
                                            </li>
                                            <li>
                                                <a href="life_science_ins.php" class="link-light dropdown-item">Life-sciences and
                                                    Healthcare</a>
                                            </li>
                                            <li>
                                                <a href="media_ins.php" class="link-light dropdown-item">Media and Publishing</a>
                                            </li>
                                            <li>
                                                <a href="retail_cpg_ins.php" class="link-light dropdown-item">Retail and CPG</a>
                                            </li>
                                            <li>
                                                <a href="telecommunications_ins.php" class="link-light dropdown-item">Telecommunications</a>
                                            </li>
                                            <li>
                                                <a href="travel_ins.php" class="link-light dropdown-item">Travel &amp; Logistics</a>
                                            </li>
                                            <li>
                                                <a href="industry_ins.php" class="link-light dropdown-item">Industry and Automation</a>
                                            </li>
                                            <li>
                                                <a href="non_profits_ins.php" class="link-light dropdown-item">Non-profits and
                                                    Education</a>
                                            </li>
                                            <li>
                                                <a href="public_sector_ins.php" class="link-light dropdown-item">Public Sector</a>
                                            </li>
                                        </ul>
                                    </section>
                                </div>
                            </div>
                        </li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="maintenance.php" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-expanded="false">
                        Maintenance
                    </a>
                </li>
            </ul>

            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        About us
                    </a>
                    <div class="text-light dropdown-menu p-3 pt-3 pb-3" aria-labelledby="navbarDropdownMenuLink">
                        <a class="link-light dropdown-item" href="canyoutrustus.php">Can you trust us
                        </a>

                        <a class="link-light dropdown-item" href="reasontojoin.php">10 reason to join
                        </a>
                    </div>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Careers
                    </a>
                    <ul class="text-light dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                        <li>
                            <a class="link-light dropdown-item" href="action.php">Action</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="another_action.php">Another action</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="else_here.php">Something else here</a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="contact_us.php" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-expanded="false">
                        Contact us
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- End Header -->    <!-- End Header -->
    <section style="background-color: #13294B;padding: 100px 10px;">
        <div class="container builddetails">
            <div id="acc-bgimg">
                <div class=" py-lg-0 p-5 order-2 order-lg-1 mt-3" data-aos="fade-right">
                    <a id=" " class="fs-3 text-white" href="">Services</a> &nbsp;<a href="" class="text-success fs-3 text-capitalize">low code</a>
                    <h1 class=" text-start">Ideation to scalable <br> digitalization in 60 <br> hours!</h1>

                </div>
            </div>
        </div>
    </section>

    <section class="bg-white py-5">
        <div class="container fs-5 p-5" style="text-align:justify;">
            <p>Transformation, Innovation, or Disruption, whatever you call it: it’s an absolute reality. To be or remain relevant and successful only organizations with a digital-first ecosystem will succeed. IT plays a major role in accelerating the digital-first approach. But organizations face numerous challenges when scouting for the right talent that often culminates in lag towards the journey towards this transformation. </p>
            <p>At ICEICO, we partner with our customers to navigate these challenges and view them as an opportunity for a Low Code-driven innovation. We work as strategic partners for customers with our ‘solving for value’ mindset, agile delivery process, with innovation at heart. We help them ideate, assess, and deliver value-driven ROI. Our service offerings across leading Low Code application platforms such as Mendix, Microsoft Power Apps, Simplifier, among others, provide end-to-end capabilities for inculcating a scalable digital-first mindset. To know more about our Low Code capabilities, click here.</p>
        </div>
    </section>

    <!-- What we do -->
    <section class=" bg-white" style="padding: 100px 10px;">
        <div class="container">
            <h2 class="pb-5 text-center text-capitalize"> What We Do</h2>
            <div class="row text-center text-lg-start">
                <div class="col-lg-4 col-12 p-5">
                    <h4 class="p-0 pt-0">Consulting and <br> Platform Advisory</h4>
                    <img src="assets/img/title-underline.jpg" alt="">
                    <p class="text-secondary p-0 pt-4 pb-4">We think through your business challenges to ideate to identify the potential areas of digitization. We help you assess the right mix of applications and platforms, followed by onboarding resources through robust training frameworks.</p>

                </div>
                <div class="col-lg-4 col-12 p-5">
                    <h4 class="p-0 pt-0">Plan, Pilot & Evaluate</h4>
                    <img src="assets/img/title-underline.jpg" alt="">
                    <p class="text-secondary p-0 pt-4 pb-4">We partner to co-create and define a roadmap for prototype development within the first 60 hours. Our goal is to help you quickly achieve true enterprise scalability across the identified mix of lighthouse applications.</p>
                </div>

                <div class="col-lg-4 col-12 p-5">
                    <h4 class="p-0 pt-0">Enterprise Scalability</h4>
                    <img src="assets/img/title-underline.jpg" alt="">
                    <p class="text-secondary p-0 pt-4 pb-4">We strive for value creation and the right insights that are critical in your digitization journey. We help you achieve a digital-first enterprise vision, at a rapid pace, leveraging agile implementation methodologies.
                    </p>

                </div>
            </div>


        </div>
        </div>
    </section>
    <!--  End what we do -->

    <section class="bg-white py-5">
        <div class="container">
            <h2 class="pb-5 text-center text-capitalize">applications we built with low code</h2>
            <div class="row justify-content-center my-3">
                <div class="col-md-6 col-sm-12 col-lg-6 mb-3">
                    <div class="content" style="background:#0f0f0f; height:600px;">
                        <a href="" class="link-light ">
                        </a>
                        <div class="img1"><a href="" class="link-light ">
                                <img src="assets/img/3d-printing.png" alt="" class="w-100">
                            </a>
                            <div class="wrap"><a href="" class="link-light ">
                                </a><a href="" class="link-light ">
                                    <h3>3D Printing</h3>
                                    <h6>
                                        Declutter raw material management
                                    </h6>
                                    <div class="btn-hover">
                                        <button class="btn btn-light" style="border-radius: 50px;">Know More</button>
                                    </div>
                                </a>
                            </div>
                        </div>

                    </div>
                </div>

                <div class="col-md-6 col-sm-12 col-lg-6">
                    <div class="content" style="background:#7884b6; height:600px;">
                        <a href="" class="link-light ">
                        </a>
                        <div class="img1"><a href="" class="link-light ">
                                <img src="assets/img/cold-chain-monitoring.png" alt="" class="w-100">

                            </a>
                            <div class="wrap"><a href="" class="link-light ">
                                </a><a href="" class="link-light ">
                                    <h3>Cold chain monitoring</h3>
                                    <h6>
                                        Ensure end-to-end visibility with our cold-storage tracking app build on Simplifier
                                    </h6>
                                    <div class="btn-hover">
                                        <button class="btn btn-light" style="border-radius: 50px;">Know More</button>
                                    </div>
                                </a>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Image Slider -->
    <div class="bg-white py-5 row-depth-1 row-fluid-wrapper row-number-7">
        <div class="row-fluid">
            <div class="span12 widget-span widget-type-custom_widget" data-widget-type="custom_widget" data-x="0" data-w="12">
                <div id="hs_cos_wrapper_module_159558284117034" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_module" data-hs-cos-general-type="widget" data-hs-cos-type="module">
                    <div class="featured-story-wrapper">
                        <div class="page-center page-pad">
                            <div class="row-fluid">
                                <div class="span12 section-center">
                                    <div class="featured-story-heading mb-20">
                                        <h3 class="fs-2 mb-3 ps-5 text-capitalize pt-4">
                                            featured success story

                                            <span class="featured-story-list-view-all-wrapper pe-4">
                                                <a href="https://www.ICEICO.com/en/success-stories" class="featured-story-list-view-all brand-08">view all</a>
                                            </span>
                                        </h3>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="featured-story-list mb-30">
                            <section class="slider-outer">
                                <div class="row-fluid">
                                    <div class="span1">
                                        <div class="carousel__progress hide-mobile">
                                            <span class="carousel__progress-background">
                                                <span class="carousel__progress-bar"></span>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="span11 content-section">
                                        <div id="StorySliderID" class="storyslider regular slider">
                                            <div class="story-slider-wrapper" data-cursor="cursor" data-cursor-type="drag">
                                                <div class="story-list active-slide newlogoanimate" data-slide-index="0" style="">
                                                    <div class="left-section span5">
                                                        <div class="drag-overlay hide-mobile"></div>
                                                        <div class="client-logo hide-mobile">
                                                            <img src="assets/img/Palfinger_logo.svg" alt="admiral_color" style="max-width: 50%; height: auto">
                                                        </div>
                                                        <div class="client-logo hide-desktop">
                                                        </div>
                                                        <div class="story-content">
                                                            <h4>
                                                                <div id="hs_cos_wrapper_module_159558284117034_" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_inline_text" data-hs-cos-general-type="widget" data-hs-cos-type="inline_text" data-hs-cos-field="story_title">
                                                                    Digitalizing the visual inspection process
                                                                </div>
                                                            </h4>
                                                            <div class="description brand-04-neg-20 small-text">
                                                                <div id="hs_cos_wrapper_module_159558284117034_" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_inline_rich_text" data-hs-cos-general-type="widget" data-hs-cos-type="inline_rich_text" data-hs-cos-field="description">
                                                                    Innovating business processes and product lines to make them future-proof using low code
                                                                </div>
                                                            </div>
                                                            <h6 class="bottom-text brand-04-neg-20">
                                                                <div id="hs_cos_wrapper_module_159558284117034_" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_inline_rich_text" data-hs-cos-general-type="widget" data-hs-cos-type="inline_rich_text" data-hs-cos-field="bottom_text"></div>
                                                            </h6>

                                                            <a href="#" target="_blank" class="page-btn page-btn03 btn btn-outline-secondary text-capitalize">read full story</a>
                                                        </div>
                                                    </div>
                                                    <div class="right-section span7">
                                                        <div class="right-section-content" style="">
                                                            <div class="right-section--image">
                                                                <img src="assets/img/Palfinger-Success-Story-Tile-min.jpg" loading="lazy" class="right-section--imageSrc">

                                                                <div class="mobile-overlay"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="story-list" data-slide-index="1" style="">
                                                    <div class="left-section span5">
                                                        <div class="drag-overlay hide-mobile"></div>
                                                        <div class="client-logo hide-mobile"> </div>
                                                        <div class="client-logo hide-desktop"> </div>
                                                        <div class="story-content">
                                                            <h4>
                                                                <div id="hs_cos_wrapper_module_159558284117034_" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_inline_text" data-hs-cos-general-type="widget" data-hs-cos-type="inline_text" data-hs-cos-field="story_title">
                                                                    Analyzing survey data in real-time
                                                                </div>
                                                            </h4>
                                                            <div class="description brand-04-neg-20 small-text">
                                                                <div id="hs_cos_wrapper_module_159558284117034_" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_inline_rich_text" data-hs-cos-general-type="widget" data-hs-cos-type="inline_rich_text" data-hs-cos-field="description">
                                                                    <p>
                                                                        Leveraging low-code in data collection & management processes, supporting the conservation of the Wadden Sea National Park, Germany.
                                                                    </p>
                                                                </div>
                                                            </div>
                                                            <h6 class="bottom-text brand-04-neg-20">
                                                                <div id="hs_cos_wrapper_module_159558284117034_" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_inline_rich_text" data-hs-cos-general-type="widget" data-hs-cos-type="inline_rich_text" data-hs-cos-field="bottom_text"></div>
                                                            </h6>

                                                            <a href="#" class="btn btn-outline-secondary page-btn page-btn03 text-capitalize">read
                                                                success story</a>
                                                        </div>
                                                    </div>
                                                    <div class="right-section span7">
                                                        <div class="right-section-content" style="">
                                                            <div class="right-section--image">
                                                                <img src="assets/img/BMP_0334-1.jpg" loading="lazy" class="right-section--imageSrc">

                                                                <div class="mobile-overlay"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="story-list" data-slide-index="2" style="">
                                                    <div class="left-section span5">
                                                        <div class="drag-overlay hide-mobile"></div>
                                                        <div class="client-logo hide-mobile">
                                                        </div>
                                                        <div class="client-logo hide-desktop">
                                                        </div>
                                                        <div class="story-content">
                                                            <h4>
                                                                <div id="hs_cos_wrapper_module_159558284117034_" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_inline_text" data-hs-cos-general-type="widget" data-hs-cos-type="inline_text" data-hs-cos-field="story_title">
                                                                    Making process digitalization a reality
                                                                </div>
                                                            </h4>
                                                            <div class="description brand-04-neg-20 small-text">
                                                                <div id="hs_cos_wrapper_module_159558284117034_" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_inline_rich_text" data-hs-cos-general-type="widget" data-hs-cos-type="inline_rich_text" data-hs-cos-field="description">
                                                                    Driving higher shopfloor efficiency and effective collaboration through Low Code appllications for one of the largest pharmaceuticals importers in Germany.
                                                                </div>
                                                            </div>
                                                            <h6 class="bottom-text brand-04-neg-20">
                                                                <div id="hs_cos_wrapper_module_159558284117034_" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_inline_rich_text" data-hs-cos-general-type="widget" data-hs-cos-type="inline_rich_text" data-hs-cos-field="bottom_text"></div>
                                                            </h6>

                                                            <a href="#" target="_blank" class="page-btn page-btn03 btn btn-outline-secondary text-capitalize">read full
                                                                story</a>
                                                        </div>
                                                    </div>
                                                    <div class="right-section span7">
                                                        <div class="right-section-content" style="">
                                                            <div class="right-section--image">
                                                                <img src="assets/img/Low-code-featured-tile.jpg" loading="lazy" class="right-section--imageSrc">

                                                                <div class="mobile-overlay"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <!-- Pagination section start -->
                                                <ul class="story--slider-pagination-section">
                                                    <li class="slider-numbers">
                                                        <span class="xs-pagination-number">1</span>
                                                        <span class="total-number">3</span>
                                                    </li>
                                                    <li class="slide-arrow slider-pagination-left" id="storyprevSlideControl">
                                                        <svg width="36" height="32" viewBox="0 0 36 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M34 2C28.5 8.00001 6 16 6 16C6 16 29 25.5 34 30" stroke="#13294B" stroke-width="4" stroke-linecap="round"></path>
                                                        </svg>
                                                    </li>
                                                    <li class="slide-arrow slider-pagination-right" id="storynextSlideControl">
                                                        <svg width="36" height="32" viewBox="0 0 36 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M2 2C7.5 8.00001 30 16 30 16C30 16 7 25.5 2 30" stroke="#13294B" stroke-width="4" stroke-linecap="round"></path>
                                                        </svg>
                                                    </li>
                                                </ul>
                                                <!--  Pagination section end -->
                                                <!-- Pagination section start -->
                                                <ul class="story--slider-pagination-section" style="overflow: hidden">
                                                    <li data-pagination-index="0" class="slide-pagination-block active-slide-pagination-block">
                                                        <div class="slide-pagination-number">1</div>
                                                        <div class="slide-pagination-text"></div>
                                                    </li>

                                                    <li data-pagination-index="1" class="slide-pagination-block">
                                                        <div class="slide-pagination-number">2</div>
                                                        <div class="slide-pagination-text"></div>
                                                    </li>

                                                    <li data-pagination-index="2" class="slide-pagination-block">
                                                        <div class="slide-pagination-number">3</div>
                                                        <div class="slide-pagination-text"></div>
                                                    </li>
                                                </ul>
                                                <!--  Pagination section end -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <!--end widget-span -->
        </div>
        <!--end row-->
    </div>

    <!-- Tab Slider -->
    <!-- <section class="bg-white py-5">
        <div class=" bg-white container">
            <div class="row-fluid ">
                <div class="span12 widget-span widget-type-custom_widget " style="" data-widget-type="custom_widget" data-x="0" data-w="12">
                    <div id="hs_cos_wrapper_module_1616735299530140" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_module" style="" data-hs-cos-general-type="widget" data-hs-cos-type="module">

                        <div class="multiple-testimonials mb-30">
                            <div class="page-center page-pad">
                                <div class="row-fluid">
                                    <div class="span8 span12-small center-aligned">
                                        <div class="slider client-logos slick-initialized slick-slider">
                                            <div class="slick-list draggable" style="padding: 0px 50px;">
                                                <div class="slick-track" style="opacity: 1; width: 630px; transform: translate3d(105px, 0px, 0px);">
                                                    <div class="slick-slide slick-current slick-center" data-slick-index="0" aria-hidden="true" style="width: 210px;">
                                                        <div>
                                                            <div class="logo-outer" style="width: 100%; display: inline-block;">

                                                                <img src="assets/img/Palfinger_logo.svg" alt="Palfinger_logo">

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="slick-slide slick-center" data-slick-index="1" aria-hidden="true" style="width: 210px;">
                                                        <div>
                                                            <div class="logo-outer" style="width: 100%; display: inline-block;">

                                                                <img src="assets/img/Logo_Schutzstation_Wattenmeer.jpg" alt="Logo_Schutzstation_Wattenmeer">

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="slick-slide" data-slick-index="2" aria-hidden="true" style="width: 210px;">
                                                        <div>
                                                            <div class="logo-outer" style="width: 100%; display: inline-block;">

                                                                <img src="assets/img/Logo_Schutzstation_Wattenmeer.jpg" alt="Logo_Schutzstation_Wattenmeer">

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div class="row-fluid">
                                    <div class="span12">
                                        <div class="slider client-testimonials drag-cursor slick-initialized slick-slider"><button class="slick-prev slick-arrow" aria-label="Previous" type="button" style="display: block;">Previous</button>
                                            <div class="slick-list draggable">
                                                <div class="slick-track" style="opacity: 1; width: 2511px;">
                                                    <div class="slick-slide slick-current slick-active" data-slick-index="0" aria-hidden="false" style="width: 837px; position: relative; left: 0px; top: 0px; z-index: 999; opacity: 1;">
                                                        <div>
                                                            <div style="width: 100%; display: inline-block;">
                                                                <h4 class="brand-09">
                                                                    ICEICO worked as a true strategic partner while challenging the status quo. They helped evolve our initial idea while putting the customer at the heart of the user's perspective. Our business and customers immensely benefit from the simplified processes we enabled together with ICEICO.
                                                                </h4>
                                                                <div class="user-profile">

                                                                    <div class="profile-pic">
                                                                        <img src="assets/img/PALFINGER_MA_Portraits_Marius_Stehling-square.jpg" alt="PALFINGER_MA_Portraits_Marius_Stehling-square">
                                                                    </div>


                                                                    <div class="other-info">
                                                                        <span class="name body-text brand-09">Marius Stehling</span>
                                                                        <span class="designation small-print-text brand-08">Head of Digital Manufacturing, PALFINGER AG</span>

                                                                    </div>


                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="slick-slide" data-slick-index="1" aria-hidden="true" style="width: 837px; position: relative; left: -837px; top: 0px; z-index: 998; opacity: 0; transition: opacity 500ms ease 0s;" tabindex="-1">
                                                        <div>
                                                            <div style="width: 100%; display: inline-block;">
                                                                <h4 class="brand-09">
                                                                    <p>ICEICO clearly specified our requirements. Second, they visualized them really well; and third, they successfully implemented them. Considering our specific requirements, the strong support during the course of the project, and the smooth cooperation across national borders mean that I can recommend ICEICO without any hesitation.</p>
                                                                </h4>
                                                                <div class="user-profile">

                                                                    <div class="profile-pic">
                                                                        <img src="/assets/img/Bjoern_Philipps.jpg" alt="Bjorn_Philipps">
                                                                    </div>


                                                                    <div class="other-info">
                                                                        <span class="name body-text brand-09">Björn Marten Philipps</span>
                                                                        <span class="designation small-print-text brand-08">CEO, Schutzstation Wattenmeer e.V.</span>

                                                                    </div>


                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="slick-slide" data-slick-index="2" aria-hidden="true" style="width: 837px; position: relative; left: -1674px; top: 0px; z-index: 998; opacity: 0; transition: opacity 500ms ease 0s;" tabindex="-1">
                                                        <div>
                                                            <div style="width: 100%; display: inline-block;">
                                                                <h4 class="brand-09">
                                                                    The application we developed with ICEICO is a giant step forward in facilitating communication and data transfer between our stations and the main office. Data on natural history and conservation activities are now instantly transferred and readily available for further research and public relations.
                                                                </h4>
                                                                <div class="user-profile">

                                                                    <div class="profile-pic">
                                                                        <img src="assets/img/Barbara_Ganter.jpg" alt="Barbara_Ganter">
                                                                    </div>


                                                                    <div class="other-info">
                                                                        <span class="name body-text brand-09">Dr. Barbara Ganter</span>
                                                                        <span class="designation small-print-text brand-08">Head of Nature Conservation, Schutzstation Wattenmeer e.V.</span>

                                                                    </div>


                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div><button class="slick-next slick-arrow" aria-label="Next" type="button" style="display: block;">Next</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section> -->



    <!-- our partner -->
    <section class="bg-white py-5">
        <div class="container">
            <h2 class="pb-5 text-center text-uppercase">our platform expertise</h2>
            <div class=" text-center text-lg-start row">
                <div class="col-lg-3 col-md-3 col-sm-12">
                    <img src="assets/img/MicrosoftTeams-image (10)-1.png" alt="" class="img-fluid" style="max-width: 80%;height: 20%;">
                    <p class="pt-5 text-black-50">As a Mendix partner, we provide advice, help organizations realize their projects, and take over development cycles.</p>
                </div>
                <hr class="d-lg-none">
                <div class="col-lg-4 col-md-4 col-sm-12">
                    <img src="assets/img/Simplifier-Logo-web-2000x378px-72dpi.jpg" alt="" class="img-fluid" style="max-width: 80%;height: 20%;">
                    <p class="pt-5 text-black-50">As a Simplifier partner, we help provide scalable digitalization opportunities to our customers and create new applications up to 10 times faster at optimized licensing costs. Together, we have developed over 40 applications cross multiple domains including manufacturing, energy, pharmaceuticals and closely collaborated on industrial automation, wearables and connected worker segments. </p>
                </div>
                <hr class="d-lg-none">
                <div class="col-lg-3 col-md-3 col-sm-12">
                    <img src="assets/img/servicenow-logo-new.png" class="img-fluid" style="max-width: 80%;height: 20%;">
                    <p class="pt-5 text-black-50">As an Elite partner, we enable customers to speed up their digitalization journey and achieve business value. IntegrationHub, together with App Engine on the Now Platform, simplifies and scales cross-system process automation on a single low-code workflow application platform. </p>
                </div>
            </div>
        </div>
    </section>

    <!-- featured insights -->
    <section class="container-fluid bg-white py-5">
        <div class="container">
            <div class="featured1 mt-5 mb-5">
                <h2 class="fs-2 text-center mt-5 mb-5 text-capitalize">featured insights</h2>
                <div class="row justify-content-center">
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Manufacturing-Low-Code-M-min.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">How low-code platforms can help the manufacturing industry</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Aug 8, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/low code no code in India.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Decoding Low code | Tech talk highlights </p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Jul 28,2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Nasscom report on Low Code No Code India.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Low Code No Code - The India Story</p>
                                <span class="position-absolute"><a href="" class="text-success">Report</a> &nbsp;
                                    &nbsp; Mar 4, 2022</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/low code MOBILE.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-1 p-md-3 p-sm-3">To low-code or not to low-code?</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Oct 19, 2021</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Low code platforms-financial services-digital transformation-Tile.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-1 p-md-3 p-sm-3">Democratizing digital transformation of financial services via low-code platforms</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Jun 24, 2020</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Content Services Platform_Banner.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-1 p-md-3 p-sm-3">Are you content services aligned to your digital transformation goals?</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Jan 11,2020</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- //user Review  -->
    <section class="py-3">
  <div class="container  responsive-container text-center">
    <h2 class="fs-2 pt-2 pt-5 text-center text-light">Our Community With User Review</h2>
    <div class="m-md-5 py-5 py-lg-0 py-md-0 row user-review-background">

      <div class="col-12 col-lg-4 col-sm-12 mt-0 mt-lg-5 mt-md-5 ps-sm-5 pt-sm-5"><img src="assets/img/Group 1.png" class="ellipseimg pt-0" alt="" width="150" height="100"></div>
      <div class="col-12 col-lg-5 col-sm-12 offset-lg-0 p-lg-5 text-center user-prghp" style="height: 240px;">
        <p>The system has produced a significant competitive advantage in the industry thanks to ICEICO Technologies well-thought opinions.

They shouldered the burden of constantly updating a project management tool with a high level of detail and were committed to producing the best possible solution. <br>-Amol Ramteke, Business Owner of Carbonblack.education</p>

      </div>

    </div>
  </div>

</section>



    <!-- footer section  start-->
    

<div class="mt-4">
  <div class="footer footer-bg">
    <div class="container ">
      <div class="row">
        <div class="col-sm-6 p-md-5 p-sm-2 text-center">
          <h3 style="color:white;">Contact Us</h3>
          <p style="color:#0fc88a;">ICEICO TECHNOLOGIES PVT. LTD. <br> Plot No. 91, Ganesh Nagar, Azamshah Layout, Nandanwan, Nagpur, Maharashtra 440009 </p>
         
        </div>


        <div class="col-sm-6 p-5 text-center">
          <div>
            <h3 style="color:white ;">NEWSLETTER</h3>
          </div>
          <div>
            <!--<span><input type="Email" class="emailform " placeholder="Email Address"><button class="formbutton">Submit</button></span>-->
            <div class="input-group mx-auto w-50">
                <input type="email" class="form-control emailform bg-transparent text-white" placeholder="Email Address" aria-label="Input group example" aria-describedby="btnGroupAddon" >
                <button class="input-group-text formbutton px-2" id="btnGroupAddon">Submit</button>    
            </div>

          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-sm-6 p-md-5  ">
          <div class="row">
            <div class="col-sm-6 col-12 p-3 text-center">
              <ul style="list-style-type:none;">
                <caption><span class="cptndetail"><b>About Us</b></span></caption>
                <li class="p-3"><a class="listdetails" href="">Whitepaper</a></li>
                <li class="p-3"><a class="listdetails" href="blog.php">Blog</a></li>
                <li class="p-3"><a class="listdetails" href="">Activity</a></li>

              </ul>
            </div>


            <div class="col-sm-6 col-12 p-md-3 text-center">
              <ul style="list-style-type:none;">
                <caption><span class="cptndetail"><b>support</b></span></caption>
                <li class="p-3"><a class="listdetails" href="">Author Profile</a></li>
                <li class="p-3"><a class="listdetails" href="">Community</a></li>
                <li class="p-3"><a class="listdetails" href="">Help & support</a></li>
                <li class="p-3"><a class="listdetails" href="contact_us.php">Contact</a></li>

              </ul>
            </div>
          </div>

        </div>
        <div class="col-sm-6 p-5 text-center">
          <h3 class="mt-5" style="color: white;">Social Media</h3>
          <div class="mt-2">
            <i class="bi bi-facebook p-2"></i>
            <i class="bi bi-twitter p-2"></i>
            <i class="bi bi-instagram p-2"></i>
          </div>
        </div>

      </div>
    </div>


  </div>
</div>    </section>

    <script src="assets/vendor/aos/aos.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
    <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
    <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
    <script src="assets/vendor/php-email-form/validate.js"></script>
    <script src="assets/js/main.js"></script>
    <script src="assets/js/img_slider.js"></script>
    <script src="assets/js/slick.min.js"></script>
</body>

</html>