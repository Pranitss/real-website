<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>ICEICO - Accelerated Quality</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Favicons -->
    <!-- <link href="assets/img/favicon.png" rel="icon"> -->
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- jquery cdn -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.3/jquery.min.js" integrity="sha512-STof4xm1wgkfm7heWqFJVn58Hm3EtS31XFaagaa8VMReCXAkQnJZ+jEy8PCC/iT18dFy95WcExNHFTqLyp72eQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <!-- Vendor CSS Files -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href="assets/vendor/aos/aos.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
    <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

    <!--Main CSS File -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/img_slider.css" rel="stylesheet">
    <link href="assets/css/slide_animation.css" rel="stylesheet">
    

    <style>
        .position-absolute {
            position: absolute;
            bottom: 20px;
            left: 35px;
        }
    </style>

</head>

<body id="aboutbg">

    <!-- ======= Header ======= -->
    <!-- ======= Header ======= -->

<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
    <div class="container-xl">
        <a class="navbar-brand" href="index.php"><img src="assets/img/Group 1.png" alt="logo" class="img-fluid" style="max-width: 100%; width: 70px" /></a>
        <button class="navbar-toggler collapsed" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon" style="width: 5vw"></span>
        </button>
        <div class="navbar-collapse collapse" id="navbarNavDropdown" style="">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <div class="separator" style="
                        height: 1px;
                        border-top: 1px solid rgba(255, 255, 255, 0.55);
                        margin-left: 20px;
                        margin-right: 20px;
                        width: 150px;
                        flex: 1;
                        margin-top: 20px;
            "></div>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="industries.php" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Industries
                    </a>
                    <ul class="text-light dropdown-menu p-3 pt-3 pb-3" aria-labelledby="navbarDropdownMenuLink">
                        <li>
                            <a class="link-light dropdown-item" href="gaming.php">Gaming &amp; Entertainment</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="life-sciences.php">Life sciences &amp;
                                healthcare</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="media.php">Media &amp; publishing</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="non-profits.php">Non-profits and education</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="retails.php">Retail &amp; cpg</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="smart-buildings.php">Smart buildings</a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Services
                    </a>
                    <ul class="container container-sm text-light dropdown-menu overflow dropdown-menu-scrollable" aria-labelledby="navbarDropdownMenuLink" style="width: 100vw; left: -400px; margin: 0px -20px">
                        <li class="p-2 pb-5 pt-5 row">
                            <section class="col-lg-3 col-md-12 col-sm-12 d-lg-block d-md-none">
                                <ul class="mylist">
                                    <li>
                                        <div class="menu-title fs-3">Services</div>
                                    </li>
                                    <li>
                                        <p class="">
                                            Accelerate your vision with technologies that are both
                                            agile and cutting edge.
                                        </p>
                                    </li>
                                    <li class="position-absolute top-50">
                                        <a href="all_services.php" class="link-light p-5 pt-2 pb-2 bg-success link-hover d-none d-lg-block" style="border-radius: 50px">view all services</a>
                                    </li>
                                </ul>
                            </section>
                            <section class="col-lg-3 col-md-12 col-sm-12">
                                <ul class="mylist">
                                    <li>
                                        <a href="accelerated-quality.php" class="link-light dropdown-item">
                                            <h6>accelerated quality &amp; test-engineering</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="agile.php" class="link-light dropdown-item">
                                            <h6>agile</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="api-mgmt.php" class="link-light dropdown-item">
                                            <h6>api management</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="app-develop.php" class="link-light dropdown-item">
                                            <h6>application development</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="app-manage.php" class="link-light dropdown-item">
                                            <h6>application managed services</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="ai-da.php" class="link-light dropdown-item">
                                            <h6>artificial intelligence, data &amp; analytics</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="blockchain.php" class="link-light dropdown-item">
                                            <h6>blockchain</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="cloud.php" class="link-light dropdown-item">
                                            <h6>cloud</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="crm.php" class="link-light dropdown-item">
                                            <h6>crm</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="customer-communications.php" class="link-light dropdown-item">
                                            <h6>customer communications</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="design.php" class="link-light dropdown-item">
                                            <h6>design</h6>
                                        </a>
                                    </li>
                                </ul>
                            </section>
                            <section class="col-lg-3 col-md-12 col-sm-12">
                                <ul class="mylist">
                                    <li>
                                        <a href="devops.php" class="link-light dropdown-item">
                                            <h6>devops</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="digital-commerce.php" class="link-light dropdown-item">
                                            <h6>digital commerce</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="digital-experiences.php" class="link-light dropdown-item">
                                            <h6>digital experiences</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="digital-ventures.php" class="link-light dropdown-item">
                                            <h6>digital ventures</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="ecm-&amp;-portals.php" class="link-light dropdown-item">
                                            <h6>ecm &amp; portals</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="embedded.php" class="link-light dropdown-item">
                                            <h6>embedded systems</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="enterprising consu.php" class="link-light dropdown-item">
                                            <h6>enterprise architecture consulting</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="erp.php" class="link-light dropdown-item">
                                            <h6>erp</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="identify man.php" class="link-light dropdown-item">
                                            <h6>identity and access management</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="inovation.php" class="link-light dropdown-item">
                                            <h6>innovation</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="internet of things.php" class="link-light dropdown-item">
                                            <h6>internet of things</h6>
                                        </a>
                                    </li>
                                </ul>
                            </section>
                            <section class="col-lg-3 col-md-12 col-sm-12">
                                <ul class="mylist">
                                    <li>
                                        <a href="low code.php" class="link-light dropdown-item">
                                            <h6>low code</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="mainfraim &amp; legacy.php" class="link-light dropdown-item">
                                            <h6>mainframe &amp; legacy</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="mobility solu.php" class="link-light dropdown-item">
                                            <h6>mobility solutions</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="process consulting.php" class="link-light dropdown-item">
                                            <h6>process consulting</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="product engeeniring.php" class="link-light dropdown-item">
                                            <h6>product engineering</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="resilience_engineering.php" class="link-light dropdown-item">
                                            <h6>resilience engineering</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="sap_services.php" class="link-light dropdown-item">
                                            <h6>sap services</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="security.php" class="link-light dropdown-item">
                                            <h6>security</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="technical_communication.php" class="link-light dropdown-item">
                                            <h6>technical communication</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="trainings.php" class="link-light dropdown-item">
                                            <h6>trainings</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="transformation.php" class="link-light dropdown-item">
                                            <h6>transformation and modernization</h6>
                                        </a>
                                    </li>
                                </ul>
                            </section>
                        </li>
                    </ul>
                </li>
                <li class="nav-item dropdown overflow">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Insights
                    </a>
                    <ul class="container container-sm text-light dropdown-menu dropdown-menu-scrollable" aria-labelledby="navbarDropdownMenuLink" style="width: 100vw; left: -490px; margin: 0 -20px">
                        <li class="container container-sm insight p-2 pb-4 pt-4" style="width: 100vw; left: -825px">
                            <div class="headings">
                                <div class="row text-center p-1 d-lg-flex d-md-none">
                                    <div class="col-md-6 fs-2">Thinking Breakthroughs</div>
                                    <div class="col-md-6">
                                        <a href="#" class="link-light p-5 pt-2 pb-2 bg-success link-hover d-none d-lg-inline-block">
                                            Explore our best ideas</a>
                                    </div>
                                </div>
                                <hr />
                                <div class="row p-5 pt-4 pb-4">
                                    <section class="col-lg-4 col-md-12 col-sm-12">
                                        <ul class="mylist">
                                            <li>
                                                <div class="fs-6 p-3 pt-0 pb-0 text-success">Filter by Goal</div>
                                            </li>
                                            <li>
                                                <a href="modernize.php" class="link-light dropdown-item fs-3">Modernize</a>
                                            </li>
                                            <li>
                                                <a href="optimize.php" class="link-light dropdown-item fs-3">Optimize</a>
                                            </li>
                                            <li>
                                                <a href="innovate.php" class="link-light dropdown-item fs-3">Innovate</a>
                                            </li>
                                            <li>
                                                <a href="disrupt.php" class="link-light dropdown-item fs-3">Disrupt</a>
                                            </li>
                                            <li>
                                                <a href="transform.php" class="link-light dropdown-item fs-3">Transform</a>
                                            </li>
                                        </ul>
                                    </section>
                                    <section class="col-lg-4 col-md-12 col-sm-12 border-right" style="border-left: 1px solid #999">
                                        <ul class="mylist">
                                            <li>
                                                <div class="fs-6 p-3 pt-0 pb-0 text-success">
                                                    Trending technologies
                                                </div>
                                            </li>
                                            <li>
                                                <a href="ai_ml.php" class="link-light dropdown-item fs-5">AI and ML</a>
                                            </li>
                                            <li>
                                                <a href="data_science.php" class="link-light dropdown-item fs-5">Data Science</a>
                                            </li>
                                            <li>
                                                <a href="iot.php" class="link-light dropdown-item fs-5">IoT</a>
                                            </li>
                                            <li>
                                                <a href="low_code_ins.php" class="link-light dropdown-item fs-5">Low Code</a>
                                            </li>
                                            <li>
                                                <a href="api_ins.php" class="link-light dropdown-item fs-5">API-Management</a>
                                            </li>
                                            <li>
                                                <a href="aqt.php" class="link-light dropdown-item fs-5">AQT</a>
                                            </li>
                                            <li>
                                                <a href="cloud_ins.php" class="link-light dropdown-item fs-5">Cloud</a>
                                            </li>
                                            <li>
                                                <a href="agile_ins.php" class="link-light dropdown-item fs-5">Agile</a>
                                            </li>
                                            <li>
                                                <a href="devops_ins.php" class="link-light dropdown-item fs-5">DevOps</a>
                                            </li>
                                            <li>
                                                <a href="chaos_engineering.php" class="link-light dropdown-item fs-5">Chaos Engineering</a>
                                            </li>
                                            <li>
                                                <a href="data_mesh.php" class="link-light dropdown-item fs-5">Data Mesh</a>
                                            </li>
                                        </ul>
                                    </section>
                                    <section class="col-lg-4 col-md-12 col-sm-12 border-right" style="border-left: 1px solid #999">
                                        <ul class="mylist">
                                            <li>
                                                <div class="fs-6 p-3 pt-0 pb-0 text-success">Industry</div>
                                            </li>
                                            <li>
                                                <a href="automotive_ins.php" class="link-light dropdown-item">Automotive</a>
                                            </li>
                                            <li>
                                                <a href="banking_financial_ins.php" class="link-light dropdown-item">Banking and Financial
                                                    Services</a>
                                            </li>
                                            <li>
                                                <a href="insurance_ins.php" class="link-light dropdown-item">Insurance</a>
                                            </li>
                                            <li>
                                                <a href="energy_ins.php" class="link-light dropdown-item">Energy and Utilities</a>
                                            </li>
                                            <li>
                                                <a href="gaming_ins.php" class="link-light dropdown-item">Gaming and
                                                    Entertainment</a>
                                            </li>
                                            <li>
                                                <a href="isv_ins.php" class="link-light dropdown-item">ISV</a>
                                            </li>
                                            <li>
                                                <a href="life_science_ins.php" class="link-light dropdown-item">Life-sciences and
                                                    Healthcare</a>
                                            </li>
                                            <li>
                                                <a href="media_ins.php" class="link-light dropdown-item">Media and Publishing</a>
                                            </li>
                                            <li>
                                                <a href="retail_cpg_ins.php" class="link-light dropdown-item">Retail and CPG</a>
                                            </li>
                                            <li>
                                                <a href="telecommunications_ins.php" class="link-light dropdown-item">Telecommunications</a>
                                            </li>
                                            <li>
                                                <a href="travel_ins.php" class="link-light dropdown-item">Travel &amp; Logistics</a>
                                            </li>
                                            <li>
                                                <a href="industry_ins.php" class="link-light dropdown-item">Industry and Automation</a>
                                            </li>
                                            <li>
                                                <a href="non_profits_ins.php" class="link-light dropdown-item">Non-profits and
                                                    Education</a>
                                            </li>
                                            <li>
                                                <a href="public_sector_ins.php" class="link-light dropdown-item">Public Sector</a>
                                            </li>
                                        </ul>
                                    </section>
                                </div>
                            </div>
                        </li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="maintenance.php" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-expanded="false">
                        Maintenance
                    </a>
                </li>
            </ul>

            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        About us
                    </a>
                    <div class="text-light dropdown-menu p-3 pt-3 pb-3" aria-labelledby="navbarDropdownMenuLink">
                        <a class="link-light dropdown-item" href="canyoutrustus.php">Can you trust us
                        </a>

                        <a class="link-light dropdown-item" href="reasontojoin.php">10 reason to join
                        </a>
                    </div>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Careers
                    </a>
                    <ul class="text-light dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                        <li>
                            <a class="link-light dropdown-item" href="action.php">Action</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="another_action.php">Another action</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="else_here.php">Something else here</a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="contact_us.php" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-expanded="false">
                        Contact us
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- End Header -->    <!-- End Header -->
    <section style="background-color: #13294B;padding: 100px 10px;">
        <div class="container builddetails">
            <div id="acc-bgimg">
                <div class=" py-lg-0 p-5 order-2 order-lg-1 mt-3" data-aos="fade-right">
                    <a id=" " class="fs-3 text-white text-capitalize" href=""> services </a> &nbsp;<a href="" class="text-success fs-3 text-capitalize">application managed services</a>
                    <h1 class="text-capitalize text-start">re-envision your operations in the digital world</h1>
                    <a href="contact_us.php" class="btn-get-started">Connect with us</a>
                </div>
            </div>
        </div>
    </section>
    <section class=" bg-white" style="padding:100px 0;">
        <div class="container mt-5 mb-5" style="text-align:justify;">
            <p class="fs-5">ICEICO Application Managed Services (AMS) goes beyond traditional AMS model of resource cost optimization by focusing on value driven business outcomes aided by digital transformation and automation. It enables client’s businesses to not only optimise processes and technology landscape but also easily adopt and integrate newer technologies to achieve IT goals that are aligned with business needs.

                Our capability is underpinned by an unrivalled advisory function blended with execution, which harnesses our technology expertise available globally to deliver managed services solutions through an optimised onshore, nearshore and offshore delivery model.</p>
        </div>
    </section>

    <!-- What we do -->
    <section class=" bg-white" style="padding:100px 0">
        <div class="container">
            <h2 class=" pb-5 text-center text-capitalize"> what we do</h2>
            <div class="row justify-content-center">
                <div class="col-lg-4 col-12 p-4">
                    <h4 class="p-0 pt-0">Application Services</h4>
                    <img src="assets/img/title-underline.jpg" alt="">
                    <p class="text-secondary p-0 pt-4 pb-4">Provide all levels of support (helpdesk, technical, functional, and application support) for their custom-built applications as well as COTS products and platforms.</p>
                </div>
                <div class="col-lg-4 col-12 p-4">
                    <h4 class="p-0 pt-0">Operational Services</h4>
                    <img src="assets/img/title-underline.jpg" alt="">
                    <p class="text-secondary p-0 pt-4 pb-4">24x7 operational services (monitoring services, DevOps toolchain support, NOC support, etc.) for both application as well as infrastructure be it on-premise or on-cloud.</p>
                </div>
                <div class="col-lg-4 col-12 p-4">
                    <h4 class="p-0 pt-0">Transformation Services</h4>
                    <img src="assets/img/title-underline.jpg" alt="">
                    <p class="text-secondary p-0 pt-4 pb-4">Portfolio rationalization, legacy modernization, EOL extension, roadmap consulting, automation, cloud enablement and support, DevOps enablement and toolchain support, AIOps, IOTOps consulting, implementation & support</p>
                </div>
            </div>
        </div>
    </section>

     <!-- Image Slider -->
     <div class="bg-white py-5 row-depth-1 row-fluid-wrapper row-number-7">
        <div class="row-fluid">
            <div class="span12 widget-span widget-type-custom_widget" data-widget-type="custom_widget" data-x="0" data-w="12">
                <div id="hs_cos_wrapper_module_159558284117034" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_module" data-hs-cos-general-type="widget" data-hs-cos-type="module">
                    <div class="featured-story-wrapper">
                        <div class="page-center page-pad">
                            <div class="row-fluid">
                                <div class="span12 section-center">
                                    <div class="featured-story-heading mb-20">
                                        <h3 class="fs-2 mb-3 ps-5 text-capitalize pt-4">
                                            featured success story

                                            <span class="featured-story-list-view-all-wrapper pe-4">
                                                <a href="https://www.ICEICO.com/en/success-stories" class="featured-story-list-view-all brand-08">view all</a>
                                            </span>
                                        </h3>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="featured-story-list mb-30">
                            <section class="slider-outer">
                                <div class="row-fluid">
                                    <div class="span1">
                                        <div class="carousel__progress hide-mobile">
                                            <span class="carousel__progress-background">
                                                <span class="carousel__progress-bar"></span>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="span11 content-section">
                                        <div id="StorySliderID" class="storyslider regular slider">
                                            <div class="story-slider-wrapper" data-cursor="cursor" data-cursor-type="drag">
                                                <div class="story-list active-slide newlogoanimate" data-slide-index="0">
                                                    <div class="left-section span5">
                                                        <div class="drag-overlay hide-mobile"></div>
                                                        <div class="client-logo hide-mobile">
                                                            <img src="assets/img/Trodat_Logo.svg.png" alt="" style="max-width: 1000%; height: auto">
                                                        </div>
                                                        <div class="client-logo hide-desktop">

                                                        </div>
                                                        <div class="story-content">
                                                            <h4>
                                                                <div id="hs_cos_wrapper_module_159558284117034_" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_inline_text" data-hs-cos-general-type="widget" data-hs-cos-type="inline_text" data-hs-cos-field="story_title">
                                                                    Transforming e-commerce infrastructure to scale
                                                                </div>
                                                            </h4>
                                                            <div class="description brand-04-neg-20 small-text">
                                                                <div id="hs_cos_wrapper_module_159558284117034_" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_inline_rich_text" data-hs-cos-general-type="widget" data-hs-cos-type="inline_rich_text" data-hs-cos-field="description">
                                                                    Modernizing and harmonizing more than 600 online shops for Trodat GmbH, a world leader in self-ink stamp manufacturing.
                                                                </div>
                                                            </div>
                                                            <h6 class="bottom-text brand-04-neg-20">
                                                                <div id="hs_cos_wrapper_module_159558284117034_" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_inline_rich_text" data-hs-cos-general-type="widget" data-hs-cos-type="inline_rich_text" data-hs-cos-field="bottom_text"></div>
                                                            </h6>

                                                            <a href="#" target="_blank" class="page-btn page-btn03 btn btn-outline-secondary text-capitalize">read success
                                                                story</a>
                                                        </div>
                                                    </div>
                                                    <div class="right-section span7">
                                                        <div class="right-section-content">
                                                            <div class="right-section--image">
                                                                <img src="assets/img/trodat-750.jpg" loading="lazy" class="right-section--imageSrc">

                                                                <div class="mobile-overlay"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- Pagination section start -->
                                                <ul class="story--slider-pagination-section">
                                                    <li class="slider-numbers">
                                                        <span class="xs-pagination-number">1</span>
                                                        <span class="total-number">1</span>
                                                    </li>
                                                    <li class="slide-arrow slider-pagination-left" id="storyprevSlideControl">
                                                        <svg width="36" height="32" viewBox="0 0 36 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M34 2C28.5 8.00001 6 16 6 16C6 16 29 25.5 34 30" stroke="#13294B" stroke-width="4" stroke-linecap="round"></path>
                                                        </svg>
                                                    </li>
                                                    <li class="slide-arrow slider-pagination-right" id="storynextSlideControl">
                                                        <svg width="36" height="32" viewBox="0 0 36 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M2 2C7.5 8.00001 30 16 30 16C30 16 7 25.5 2 30" stroke="#13294B" stroke-width="4" stroke-linecap="round"></path>
                                                        </svg>
                                                    </li>
                                                </ul>
                                                <!--  Pagination section end -->
                                                <!-- Pagination section start -->
                                                <ul class="story--slider-pagination-section" style="overflow: hidden">
                                                    <li data-pagination-index="0" class="slide-pagination-block">
                                                        <div class="slide-pagination-number">1</div>
                                                        <div class="slide-pagination-text"></div>
                                                    </li>
                                                </ul>
                                                <!--  Pagination section end -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <!--end widget-span -->
        </div>
        <!--end row-->
    </div>

    <!-- our partner -->
    <section class="bg-white py-5">
        <h2 class="pb-5 text-center text-capitalize ">Our Partners</h2>
        <div class="container-1 mt-5">
            <div class="slide-container">

                <div class="slide-img d-block text-center">
                    <img src="assets/img/servicenow-logo-new.png" class="img-s" alt="">
                    <p class="fs-5 fst-italic">As an Elite partner and managed services provider for ServiceNow, ICEICO enables customers to achieve the desired IT maturity state and business value seamlessly, from the implementation of IT Service/operations management to deep dive into non-IT functions like GRC or HR. Know more about our comprehensive capabilities as a ServiceNow partner. </p>
                </div>

                <div class="slide-img d-block text-center">
                    <img src="assets/img/Zendesk-Logo-1.jpg" class="img-s" alt="">
                    <p class="fs-5 fst-italic">ICEICO is an implementation partner of Zendesk. We deliver a comprehensive suite of CRM/CX Solutions for our clients. Together, ICEICO & Zendesk provide best-in-class CRM solutions to help businesses harness digital transformation opportunities to achieve desired business value. </p>
                </div>

                <div class="slide-img d-block text-center">
                    <img src="assets/img/Atlassian-1.png" class="img-s" alt="">
                    <p class="fs-5 fst-italic">As an Atlassian Platinum Solution Partner, we deliver complete solutions for software & IT teams integrating processes for agile product development, DevOps & service management. We enable business teams through work process optimization and collaboration solutions.</p>
                </div>

                <div class="slide-img d-block text-center">
                    <img src="assets/img/Google_Cloud_Logo 1.svg" class="img-s" alt="">
                    <p class="fs-5 fst-italic">As a service and reselling partner of Google Cloud, we work with our clients on multiple Cloud inspired use cases with a focus on SAP and enterprise IT modernization, Apigee-based API-enablement, and cloud-based data analytics, and artificial intelligence.</p>
                </div>

                <div class="slide-img d-block text-center">
                    <img src="assets/img/azure-250.png" class="img-s" alt="">
                    <p class="fs-5 fst-italic">ICEICO is a Microsoft Cloud Gold Partner and a Microsoft Azure  reseller making cloud accessible to every company and organization, from small or large to established or new. ICEICO received the coveted “Microsoft Partner of the Year” award in 2018 for its outstanding work. </p>
                </div>

                <div class="slide-img d-block text-center">
                    <img src="assets/img/servicenow-logo-new.png" class="img-s" alt="">
                    <p class="fs-5 fst-italic">As an Elite partner and managed services provider for ServiceNow, ICEICO enables customers to achieve the desired IT maturity state and business value seamlessly, from the implementation of IT Service/operations management to deep dive into non-IT functions like GRC or HR. Know more about our comprehensive capabilities as a ServiceNow partner. </p>
                </div>

                <div class="slide-img d-block text-center">
                    <img src="assets/img/Zendesk-Logo-1.jpg" class="img-s" alt="">
                    <p class="fs-5 fst-italic">ICEICO is an implementation partner of Zendesk. We deliver a comprehensive suite of CRM/CX Solutions for our clients. Together, ICEICO & Zendesk provide best-in-class CRM solutions to help businesses harness digital transformation opportunities to achieve desired business value. </p>
                </div>

                <div class="slide-img d-block text-center">
                    <img src="assets/img/Atlassian-1.png" class="img-s" alt="">
                    <p class="fs-5 fst-italic">As an Atlassian Platinum Solution Partner, we deliver complete solutions for software & IT teams integrating processes for agile product development, DevOps & service management. We enable business teams through work process optimization and collaboration solutions.</p>
                </div>

                <div class="slide-img d-block text-center">
                    <img src="assets/img/Google_Cloud_Logo 1.svg" class="img-s" alt="">
                    <p class="fs-5 fst-italic">As a service and reselling partner of Google Cloud, we work with our clients on multiple Cloud inspired use cases with a focus on SAP and enterprise IT modernization, Apigee-based API-enablement, and cloud-based data analytics, and artificial intelligence.</p>
                </div>

                <div class="slide-img d-block text-center">
                    <img src="assets/img/azure-250.png" class="img-s" alt="">
                    <p class="fs-5 fst-italic">ICEICO is a Microsoft Cloud Gold Partner and a Microsoft Azure  reseller making cloud accessible to every company and organization, from small or large to established or new. ICEICO received the coveted “Microsoft Partner of the Year” award in 2018 for its outstanding work. </p>
                </div>

                <div class="slide-img d-block text-center">
                    <img src="assets/img/servicenow-logo-new.png" class="img-s" alt="">
                    <p class="fs-5 fst-italic">As an Elite partner and managed services provider for ServiceNow, ICEICO enables customers to achieve the desired IT maturity state and business value seamlessly, from the implementation of IT Service/operations management to deep dive into non-IT functions like GRC or HR. Know more about our comprehensive capabilities as a ServiceNow partner. </p>
                </div>

                <div class="slide-img d-block text-center">
                    <img src="assets/img/Zendesk-Logo-1.jpg" class="img-s" alt="">
                    <p class="fs-5 fst-italic">ICEICO is an implementation partner of Zendesk. We deliver a comprehensive suite of CRM/CX Solutions for our clients. Together, ICEICO & Zendesk provide best-in-class CRM solutions to help businesses harness digital transformation opportunities to achieve desired business value. </p>
                </div>

                <div class="slide-img d-block text-center">
                    <img src="assets/img/Atlassian-1.png" class="img-s" alt="">
                    <p class="fs-5 fst-italic">As an Atlassian Platinum Solution Partner, we deliver complete solutions for software & IT teams integrating processes for agile product development, DevOps & service management. We enable business teams through work process optimization and collaboration solutions.</p>
                </div>

            </div>
        </div>
    </section>

    <!-- featured insights -->
    <section class="container-fluid  bg-white" style="padding:100px 0;">
        <div class="container">
            <div class="featured1 mt-5 mb-5">
                <h2 class="fs-2 text-center mt-5 mb-5 text-capitalize">featured insights</h2>
                <div class="row justify-content-center">
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Landing Page Banner_COVID AI Webinar_Nagarro_Jun2020_tile.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Can AI reinvent IT Ops?</p>
                                <span class="position-absolute"><a href="" class="text-success">White Paper</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/chatbot blog 2.png" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Chatbots and Live Agents: Future Allies set to transform customer experience </p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/optimization.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Power RACI</p>
                                <span class="position-absolute"><a href="" class="text-success">White Paper</a></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Amplifying the Utility of CI-CT-CD in AMS_developers working_for social.png" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-1 p-md-3 p-sm-3">Amplifying the utility of CI/CT/CD in AMS</p>
                                <span class="position-absolute"><a href="" class="text-success">White Paper</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/desktopbanner-integrated-work-management-1.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-1 p-md-3 p-sm-3">Integrated work management</p>
                                <span class="position-absolute"><a href="" class="text-success">White Paper</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Knowledge management 720x442.png" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-1 p-md-3 p-sm-3">Knowledge management during service transition</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- //user Review  -->
    <section class="py-3">
  <div class="container  responsive-container text-center">
    <h2 class="fs-2 pt-2 pt-5 text-center text-light">Our Community With User Review</h2>
    <div class="m-md-5 py-5 py-lg-0 py-md-0 row user-review-background">

      <div class="col-12 col-lg-4 col-sm-12 mt-0 mt-lg-5 mt-md-5 ps-sm-5 pt-sm-5"><img src="assets/img/Group 1.png" class="ellipseimg pt-0" alt="" width="150" height="100"></div>
      <div class="col-12 col-lg-5 col-sm-12 offset-lg-0 p-lg-5 text-center user-prghp" style="height: 240px;">
        <p>The system has produced a significant competitive advantage in the industry thanks to ICEICO Technologies well-thought opinions.

They shouldered the burden of constantly updating a project management tool with a high level of detail and were committed to producing the best possible solution. <br>-Amol Ramteke, Business Owner of Carbonblack.education</p>

      </div>

    </div>
  </div>

</section>



    <!-- footer section  start-->
    

<div class="mt-4">
  <div class="footer footer-bg">
    <div class="container ">
      <div class="row">
        <div class="col-sm-6 p-md-5 p-sm-2 text-center">
          <h3 style="color:white;">Contact Us</h3>
          <p style="color:#0fc88a;">ICEICO TECHNOLOGIES PVT. LTD. <br> Plot No. 91, Ganesh Nagar, Azamshah Layout, Nandanwan, Nagpur, Maharashtra 440009 </p>
         
        </div>


        <div class="col-sm-6 p-5 text-center">
          <div>
            <h3 style="color:white ;">NEWSLETTER</h3>
          </div>
          <div>
            <!--<span><input type="Email" class="emailform " placeholder="Email Address"><button class="formbutton">Submit</button></span>-->
            <div class="input-group mx-auto w-50">
                <input type="email" class="form-control emailform bg-transparent text-white" placeholder="Email Address" aria-label="Input group example" aria-describedby="btnGroupAddon" >
                <button class="input-group-text formbutton px-2" id="btnGroupAddon">Submit</button>    
            </div>

          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-sm-6 p-md-5  ">
          <div class="row">
            <div class="col-sm-6 col-12 p-3 text-center">
              <ul style="list-style-type:none;">
                <caption><span class="cptndetail"><b>About Us</b></span></caption>
                <li class="p-3"><a class="listdetails" href="">Whitepaper</a></li>
                <li class="p-3"><a class="listdetails" href="blog.php">Blog</a></li>
                <li class="p-3"><a class="listdetails" href="">Activity</a></li>

              </ul>
            </div>


            <div class="col-sm-6 col-12 p-md-3 text-center">
              <ul style="list-style-type:none;">
                <caption><span class="cptndetail"><b>support</b></span></caption>
                <li class="p-3"><a class="listdetails" href="">Author Profile</a></li>
                <li class="p-3"><a class="listdetails" href="">Community</a></li>
                <li class="p-3"><a class="listdetails" href="">Help & support</a></li>
                <li class="p-3"><a class="listdetails" href="contact_us.php">Contact</a></li>

              </ul>
            </div>
          </div>

        </div>
        <div class="col-sm-6 p-5 text-center">
          <h3 class="mt-5" style="color: white;">Social Media</h3>
          <div class="mt-2">
            <i class="bi bi-facebook p-2"></i>
            <i class="bi bi-twitter p-2"></i>
            <i class="bi bi-instagram p-2"></i>
          </div>
        </div>

      </div>
    </div>


  </div>
</div>    </section>


    <script src="assets/vendor/aos/aos.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
    <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
    <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
    <script src="assets/vendor/php-email-form/validate.js"></script>
    <script src="assets/js/main.js"></script>
    <script src="assets/js/img_slider.js"></script>

</body>

</html>