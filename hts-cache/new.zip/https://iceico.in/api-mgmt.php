<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>ICEICO - API management</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Favicons -->
    <!-- <link href="assets/img/favicon.png" rel="icon"> -->
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- jquery cdn -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.3/jquery.min.js"
        integrity="sha512-STof4xm1wgkfm7heWqFJVn58Hm3EtS31XFaagaa8VMReCXAkQnJZ+jEy8PCC/iT18dFy95WcExNHFTqLyp72eQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <!-- Vendor CSS Files -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <link href="assets/vendor/aos/aos.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
    <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

    <!--Main CSS File -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/img_slider.css" rel="stylesheet">
    <link href="assets/css/slide_animation.css" rel="stylesheet">



    <style>
        .position-absolute {
            position: absolute;
            bottom: 20px;
            left: 35px;
        }
    </style>

</head>

<body id="aboutbg">

    <!-- ======= Header ======= -->
    <!-- ======= Header ======= -->

<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
    <div class="container-xl">
        <a class="navbar-brand" href="index.php"><img src="assets/img/Group 1.png" alt="logo" class="img-fluid" style="max-width: 100%; width: 70px" /></a>
        <button class="navbar-toggler collapsed" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon" style="width: 5vw"></span>
        </button>
        <div class="navbar-collapse collapse" id="navbarNavDropdown" style="">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <div class="separator" style="
                        height: 1px;
                        border-top: 1px solid rgba(255, 255, 255, 0.55);
                        margin-left: 20px;
                        margin-right: 20px;
                        width: 150px;
                        flex: 1;
                        margin-top: 20px;
            "></div>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="industries.php" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Industries
                    </a>
                    <ul class="text-light dropdown-menu p-3 pt-3 pb-3" aria-labelledby="navbarDropdownMenuLink">
                        <li>
                            <a class="link-light dropdown-item" href="gaming.php">Gaming &amp; Entertainment</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="life-sciences.php">Life sciences &amp;
                                healthcare</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="media.php">Media &amp; publishing</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="non-profits.php">Non-profits and education</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="retails.php">Retail &amp; cpg</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="smart-buildings.php">Smart buildings</a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Services
                    </a>
                    <ul class="container container-sm text-light dropdown-menu overflow dropdown-menu-scrollable" aria-labelledby="navbarDropdownMenuLink" style="width: 100vw; left: -400px; margin: 0px -20px">
                        <li class="p-2 pb-5 pt-5 row">
                            <section class="col-lg-3 col-md-12 col-sm-12 d-lg-block d-md-none">
                                <ul class="mylist">
                                    <li>
                                        <div class="menu-title fs-3">Services</div>
                                    </li>
                                    <li>
                                        <p class="">
                                            Accelerate your vision with technologies that are both
                                            agile and cutting edge.
                                        </p>
                                    </li>
                                    <li class="position-absolute top-50">
                                        <a href="all_services.php" class="link-light p-5 pt-2 pb-2 bg-success link-hover d-none d-lg-block" style="border-radius: 50px">view all services</a>
                                    </li>
                                </ul>
                            </section>
                            <section class="col-lg-3 col-md-12 col-sm-12">
                                <ul class="mylist">
                                    <li>
                                        <a href="accelerated-quality.php" class="link-light dropdown-item">
                                            <h6>accelerated quality &amp; test-engineering</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="agile.php" class="link-light dropdown-item">
                                            <h6>agile</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="api-mgmt.php" class="link-light dropdown-item">
                                            <h6>api management</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="app-develop.php" class="link-light dropdown-item">
                                            <h6>application development</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="app-manage.php" class="link-light dropdown-item">
                                            <h6>application managed services</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="ai-da.php" class="link-light dropdown-item">
                                            <h6>artificial intelligence, data &amp; analytics</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="blockchain.php" class="link-light dropdown-item">
                                            <h6>blockchain</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="cloud.php" class="link-light dropdown-item">
                                            <h6>cloud</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="crm.php" class="link-light dropdown-item">
                                            <h6>crm</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="customer-communications.php" class="link-light dropdown-item">
                                            <h6>customer communications</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="design.php" class="link-light dropdown-item">
                                            <h6>design</h6>
                                        </a>
                                    </li>
                                </ul>
                            </section>
                            <section class="col-lg-3 col-md-12 col-sm-12">
                                <ul class="mylist">
                                    <li>
                                        <a href="devops.php" class="link-light dropdown-item">
                                            <h6>devops</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="digital-commerce.php" class="link-light dropdown-item">
                                            <h6>digital commerce</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="digital-experiences.php" class="link-light dropdown-item">
                                            <h6>digital experiences</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="digital-ventures.php" class="link-light dropdown-item">
                                            <h6>digital ventures</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="ecm-&amp;-portals.php" class="link-light dropdown-item">
                                            <h6>ecm &amp; portals</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="embedded.php" class="link-light dropdown-item">
                                            <h6>embedded systems</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="enterprising consu.php" class="link-light dropdown-item">
                                            <h6>enterprise architecture consulting</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="erp.php" class="link-light dropdown-item">
                                            <h6>erp</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="identify man.php" class="link-light dropdown-item">
                                            <h6>identity and access management</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="inovation.php" class="link-light dropdown-item">
                                            <h6>innovation</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="internet of things.php" class="link-light dropdown-item">
                                            <h6>internet of things</h6>
                                        </a>
                                    </li>
                                </ul>
                            </section>
                            <section class="col-lg-3 col-md-12 col-sm-12">
                                <ul class="mylist">
                                    <li>
                                        <a href="low code.php" class="link-light dropdown-item">
                                            <h6>low code</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="mainfraim &amp; legacy.php" class="link-light dropdown-item">
                                            <h6>mainframe &amp; legacy</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="mobility solu.php" class="link-light dropdown-item">
                                            <h6>mobility solutions</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="process consulting.php" class="link-light dropdown-item">
                                            <h6>process consulting</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="product engeeniring.php" class="link-light dropdown-item">
                                            <h6>product engineering</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="resilience_engineering.php" class="link-light dropdown-item">
                                            <h6>resilience engineering</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="sap_services.php" class="link-light dropdown-item">
                                            <h6>sap services</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="security.php" class="link-light dropdown-item">
                                            <h6>security</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="technical_communication.php" class="link-light dropdown-item">
                                            <h6>technical communication</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="trainings.php" class="link-light dropdown-item">
                                            <h6>trainings</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="transformation.php" class="link-light dropdown-item">
                                            <h6>transformation and modernization</h6>
                                        </a>
                                    </li>
                                </ul>
                            </section>
                        </li>
                    </ul>
                </li>
                <li class="nav-item dropdown overflow">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Insights
                    </a>
                    <ul class="container container-sm text-light dropdown-menu dropdown-menu-scrollable" aria-labelledby="navbarDropdownMenuLink" style="width: 100vw; left: -490px; margin: 0 -20px">
                        <li class="container container-sm insight p-2 pb-4 pt-4" style="width: 100vw; left: -825px">
                            <div class="headings">
                                <div class="row text-center p-1 d-lg-flex d-md-none">
                                    <div class="col-md-6 fs-2">Thinking Breakthroughs</div>
                                    <div class="col-md-6">
                                        <a href="#" class="link-light p-5 pt-2 pb-2 bg-success link-hover d-none d-lg-inline-block">
                                            Explore our best ideas</a>
                                    </div>
                                </div>
                                <hr />
                                <div class="row p-5 pt-4 pb-4">
                                    <section class="col-lg-4 col-md-12 col-sm-12">
                                        <ul class="mylist">
                                            <li>
                                                <div class="fs-6 p-3 pt-0 pb-0 text-success">Filter by Goal</div>
                                            </li>
                                            <li>
                                                <a href="modernize.php" class="link-light dropdown-item fs-3">Modernize</a>
                                            </li>
                                            <li>
                                                <a href="optimize.php" class="link-light dropdown-item fs-3">Optimize</a>
                                            </li>
                                            <li>
                                                <a href="innovate.php" class="link-light dropdown-item fs-3">Innovate</a>
                                            </li>
                                            <li>
                                                <a href="disrupt.php" class="link-light dropdown-item fs-3">Disrupt</a>
                                            </li>
                                            <li>
                                                <a href="transform.php" class="link-light dropdown-item fs-3">Transform</a>
                                            </li>
                                        </ul>
                                    </section>
                                    <section class="col-lg-4 col-md-12 col-sm-12 border-right" style="border-left: 1px solid #999">
                                        <ul class="mylist">
                                            <li>
                                                <div class="fs-6 p-3 pt-0 pb-0 text-success">
                                                    Trending technologies
                                                </div>
                                            </li>
                                            <li>
                                                <a href="ai_ml.php" class="link-light dropdown-item fs-5">AI and ML</a>
                                            </li>
                                            <li>
                                                <a href="data_science.php" class="link-light dropdown-item fs-5">Data Science</a>
                                            </li>
                                            <li>
                                                <a href="iot.php" class="link-light dropdown-item fs-5">IoT</a>
                                            </li>
                                            <li>
                                                <a href="low_code_ins.php" class="link-light dropdown-item fs-5">Low Code</a>
                                            </li>
                                            <li>
                                                <a href="api_ins.php" class="link-light dropdown-item fs-5">API-Management</a>
                                            </li>
                                            <li>
                                                <a href="aqt.php" class="link-light dropdown-item fs-5">AQT</a>
                                            </li>
                                            <li>
                                                <a href="cloud_ins.php" class="link-light dropdown-item fs-5">Cloud</a>
                                            </li>
                                            <li>
                                                <a href="agile_ins.php" class="link-light dropdown-item fs-5">Agile</a>
                                            </li>
                                            <li>
                                                <a href="devops_ins.php" class="link-light dropdown-item fs-5">DevOps</a>
                                            </li>
                                            <li>
                                                <a href="chaos_engineering.php" class="link-light dropdown-item fs-5">Chaos Engineering</a>
                                            </li>
                                            <li>
                                                <a href="data_mesh.php" class="link-light dropdown-item fs-5">Data Mesh</a>
                                            </li>
                                        </ul>
                                    </section>
                                    <section class="col-lg-4 col-md-12 col-sm-12 border-right" style="border-left: 1px solid #999">
                                        <ul class="mylist">
                                            <li>
                                                <div class="fs-6 p-3 pt-0 pb-0 text-success">Industry</div>
                                            </li>
                                            <li>
                                                <a href="automotive_ins.php" class="link-light dropdown-item">Automotive</a>
                                            </li>
                                            <li>
                                                <a href="banking_financial_ins.php" class="link-light dropdown-item">Banking and Financial
                                                    Services</a>
                                            </li>
                                            <li>
                                                <a href="insurance_ins.php" class="link-light dropdown-item">Insurance</a>
                                            </li>
                                            <li>
                                                <a href="energy_ins.php" class="link-light dropdown-item">Energy and Utilities</a>
                                            </li>
                                            <li>
                                                <a href="gaming_ins.php" class="link-light dropdown-item">Gaming and
                                                    Entertainment</a>
                                            </li>
                                            <li>
                                                <a href="isv_ins.php" class="link-light dropdown-item">ISV</a>
                                            </li>
                                            <li>
                                                <a href="life_science_ins.php" class="link-light dropdown-item">Life-sciences and
                                                    Healthcare</a>
                                            </li>
                                            <li>
                                                <a href="media_ins.php" class="link-light dropdown-item">Media and Publishing</a>
                                            </li>
                                            <li>
                                                <a href="retail_cpg_ins.php" class="link-light dropdown-item">Retail and CPG</a>
                                            </li>
                                            <li>
                                                <a href="telecommunications_ins.php" class="link-light dropdown-item">Telecommunications</a>
                                            </li>
                                            <li>
                                                <a href="travel_ins.php" class="link-light dropdown-item">Travel &amp; Logistics</a>
                                            </li>
                                            <li>
                                                <a href="industry_ins.php" class="link-light dropdown-item">Industry and Automation</a>
                                            </li>
                                            <li>
                                                <a href="non_profits_ins.php" class="link-light dropdown-item">Non-profits and
                                                    Education</a>
                                            </li>
                                            <li>
                                                <a href="public_sector_ins.php" class="link-light dropdown-item">Public Sector</a>
                                            </li>
                                        </ul>
                                    </section>
                                </div>
                            </div>
                        </li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="maintenance.php" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-expanded="false">
                        Maintenance
                    </a>
                </li>
            </ul>

            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        About us
                    </a>
                    <div class="text-light dropdown-menu p-3 pt-3 pb-3" aria-labelledby="navbarDropdownMenuLink">
                        <a class="link-light dropdown-item" href="canyoutrustus.php">Can you trust us
                        </a>

                        <a class="link-light dropdown-item" href="reasontojoin.php">10 reason to join
                        </a>
                    </div>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Careers
                    </a>
                    <ul class="text-light dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                        <li>
                            <a class="link-light dropdown-item" href="action.php">Action</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="another_action.php">Another action</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="else_here.php">Something else here</a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="contact_us.php" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-expanded="false">
                        Contact us
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- End Header -->    <!-- End Header -->
    <section style="background-color: #13294B;padding: 100px 10px;">
        <div class="container builddetails">
            <div id="acc-bgimg">
                <div class=" py-lg-0 p-5 order-2 order-lg-1 mt-3" data-aos="fade-right">
                    <a id=" " class="fs-3 text-white" href=""> Services </a> &nbsp;<a href="" class="text-success fs-3">Api Management</a>
                    <h1 class="text-start">Use the Power of APIs to Transform and Innovate</h1>
                    <a href="contact_us.php" class="btn-get-started">Connect with us</a>
                </div>
            </div>
        </div>
    </section>

    <section class="bg-white py-5">
        <div class="container p-lg-5" style="text-align:justify;">
            <h2>API management is meaningless without digital business ambition. Digital business ambition is blind without API management.</h2>
            <p>
                Think about transforming and innovating your business to become more flexible, bringing forward differentiating services or creating new customer experiences - API management plays a key role in such transformative journey - orchestrating the connection between applications, data, and services.</p>
            <p>
                Clients select ICEICO as their digital transformation partner to leverage our customer-centric “solving for value” approach, based on our Thinking Breakthroughs methodology and CARING philosophy. Besides our extensive work experience and product knowledge in API Management, our partnerships with leading APIM platform product providers help us deliver high-end vendor-agnostic consulting. And that’s not all – thanks to our indubitable expertise in complementary domains such as Enterprise Architecture Management, Cloud Migration, and DevOps, we can holistically address all your challenges right through your digital transformation journey.</p>
            <p>
                ICEICO’s API Management experts build smart digital solutions around carefully-curated APIM platform products. Our portfolio of services includes – but is not limited to – value-focused business and technology consulting, customer-specific design, and implementation of solutions based on APIM platforms and “API first” principles as well as managed services.</p>
        </div>
    </section>

    <!-- What we do -->
    <section class=" bg-white py-5">
        <div class="container">
            <h2 class="pb-5 text-center text-capitalize"> what we do</h2>
            <div class="row justify-content-center">
                <div class="col-lg-4 col-12 p-5">
                    <h4 class="p-0 pt-0">API Strategy Consulting</h4>
                    <img src="assets/img/title-underline.jpg" alt="">
                    <p class="text-secondary p-0 pt-4 pb-4">We make sure you take a solid first step with business-enabling API strategy, value metrics and platform selection. Our strategy works on enterprise-wide API governance and stakeholder mobilization. Another key component of our approach is to set up and empower a central API unit.</p>
                </div>
                <div class="col-lg-4 col-12 p-5">
                    <h4 class="p-0 pt-0">API Product Advisory</h4>
                    <img src="assets/img/title-underline.jpg" alt="">
                    <p class="text-secondary p-0 pt-4 pb-4">We help you make the leap from treating APIs as a project to “API as a product” mindset. Precisely why, our developer portal concepts pay special focus on products and stakeholders. Our approach will enable you to transition towards a more open and advanced API marketplace.</p>
                </div>
                <div class="col-lg-4 col-12 p-5">
                    <h4 class="p-0 pt-0">Platform Design & Implementation</h4>
                    <img src="assets/img/title-underline.jpg" alt="">
                    <p class="text-secondary p-0 pt-4 pb-4">We ensure our design requirements reflect the business and API strategy accurately. Our approach follows best practices in designing and implementing API management platforms. This implementation is accompanied with thorough testing, training, and incubation.</p>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-4 col-12 p-5">
                    <h4 class="p-0 pt-0">Operation & Managed Service</h4>
                    <img src="assets/img/title-underline.jpg" alt="">
                    <p class="text-secondary p-0 pt-4 pb-4">We follow insight-driven API lifecycle management, based on API monitoring. Our integration of third-party services ensures custom solutions and automation. And that’s not all. Our APIM-centric solution also comes flanked with smart DevOps practices.</p>
                </div>
                <div class="col-lg-4 col-12 p-5">
                    <h4 class="p-0 pt-0">Technical Architecture Consulting</h4>
                    <img src="assets/img/title-underline.jpg" alt="">
                    <p class="text-secondary p-0 pt-4 pb-4">We team up with clients to modernize enterprise architecture based on microservice principles and an API-first approach. Such a modernization starts with adeptly analyzing the current IT landscape along with any anticipated change requirements due to new business, overall IT or cloud strategy.</p>
                </div>
            </div>
        </div>
    </section>
    <!--  End what we do -->

    <!-- Featured offerings -->
    <section class="bg-white py-5">
        <div class="container">
        <h2 class="pb-5 text-center text-capitalize">Featured offerings</h2>
            <div class="row justify-content-center">
                <div class="col-md-4 col-sm-12 col-12 my-2">
                    <div class="content" style="background:#14294B; height:700px;">
                        <a href="" class="link-light ">
                            <div class="img1">
                                <img src="assets/img/API-enabled Banking.png" alt="" class="w-100">
                                <div class="wrap">
                                    <a href="" class="link-light ">
                                        <h3>API - enabled Banking</h3>
                                        <h6>
                                        The right API strategy towards open banking can enable banks to be innovative, agile, and increase cost efficiency while ensuring security and scalability.
                                        </h6>
                                        <div class="btn-hover">
                                            <button class="btn btn-light" style="border-radius: 50px;">Give me details</button>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-md-4 col-sm-12 col-12 my-2">
                    <div class="content" style="background:#14294B; height:700px;">
                        <a href="" class="link-light ">
                            <div class="img1">
                                <img src="assets/img/Flying high, powered by API.png" alt="" class="w-100">

                                <div class="wrap">
                                    <a href="" class="link-light ">
                                        <h3>Flying high, powered by API</h3>
                                        <h6>
                                        Want to use API gateways to move out of legacy systems? Find out how API architecture can create a seamless transition strategy for you.                    
                                        </h6>
                                        <div class="btn-hover">
                                            <button class="btn btn-light" style="border-radius: 50px;">I'm Interested</button>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-md-4 col-sm-12 col-12 my-2">
                    <div class="content" style="background:#14294B; height:700px;">
                        <a href="" class="link-light ">
                            <div class="img1">
                                <img src="assets/img/Accelerate innovation in automotives with API marketplaces.png" alt="" class="w-100">

                                <div class="wrap">
                                    <a href="" class="link-light ">
                                        <h3>Accelerate innovation in automotives</h3>
                                        <h6>
                                        As an Automotive OEM, learn about innovative mobility practices, challenges in digital transformation and how to use API marketplaces to overcome each challenge and succeed.                           
                                        </h6>
                                        <div class="btn-hover">
                                            <button class="btn btn-light " style="border-radius: 50px;">Tell me more</button>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

     <!-- Image Slider -->
     <div class="bg-white py-5 row-depth-1 row-fluid-wrapper row-number-7">
        <div class="row-fluid">
            <div class="span12 widget-span widget-type-custom_widget"  data-widget-type="custom_widget"
                data-x="0" data-w="12">
                <div id="hs_cos_wrapper_module_159558284117034"
                    class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_module" 
                    data-hs-cos-general-type="widget" data-hs-cos-type="module">
                    <div class="featured-story-wrapper">
                        <div class="page-center page-pad">
                            <div class="row-fluid">
                                <div class="span12 section-center">
                                    <div class="featured-story-heading mb-20">
                                        <h3 class="fs-2 mb-3 ps-5 text-capitalize pt-4">
                                            featured success story

                                            <span class="featured-story-list-view-all-wrapper pe-4">
                                                <a href="https://www.ICEICO.com/en/success-stories"
                                                    class="featured-story-list-view-all brand-08">view all</a>
                                            </span>
                                        </h3>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="featured-story-list mb-30">
                            <section class="slider-outer">
                                <div class="row-fluid">
                                    <div class="span1">
                                        <div class="carousel__progress hide-mobile">
                                            <span class="carousel__progress-background">
                                                <span class="carousel__progress-bar"></span>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="span11 content-section">
                                        <div id="StorySliderID" class="storyslider regular slider">
                                            <div class="story-slider-wrapper" data-cursor="cursor"
                                                data-cursor-type="drag">
                                                <div class="story-list active-slide newlogoanimate" data-slide-index="0" >
                                                    <div class="left-section span5">
                                                        <div class="drag-overlay hide-mobile"></div>
                                                        <div class="client-logo hide-mobile">
                                                            
                                                        </div>
                                                        <div class="client-logo hide-desktop">
                                                            
                                                        </div>
                                                        <div class="story-content">
                                                            <h4>
                                                                <div id="hs_cos_wrapper_module_159558284117034_"
                                                                    class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_inline_text"
                                                                     data-hs-cos-general-type="widget"
                                                                    data-hs-cos-type="inline_text"
                                                                    data-hs-cos-field="story_title">
                                                                    Transforming automotive retail experiences with an API - first digital ecosystem
                                                                </div>
                                                            </h4>
                                                            <div class="description brand-04-neg-20 small-text">
                                                                <div id="hs_cos_wrapper_module_159558284117034_"
                                                                    class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_inline_rich_text"
                                                                     data-hs-cos-general-type="widget"
                                                                    data-hs-cos-type="inline_rich_text"
                                                                    data-hs-cos-field="description">
                                                                    A Cloud native platform to make systems conversational.
                                                                </div>
                                                            </div>
                                                            <h6 class="bottom-text brand-04-neg-20">
                                                                <div id="hs_cos_wrapper_module_159558284117034_"
                                                                    class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_inline_rich_text"
                                                                     data-hs-cos-general-type="widget"
                                                                    data-hs-cos-type="inline_rich_text"
                                                                    data-hs-cos-field="bottom_text"></div>
                                                            </h6>

                                                            <a href="#"
                                                                target="_blank" class="page-btn page-btn03 btn btn-outline-secondary text-capitalize">read success
                                                                story</a>
                                                        </div>
                                                    </div>
                                                    <div class="right-section span7">
                                                        <div class="right-section-content" >
                                                            <div class="right-section--image">
                                                                <img src="assets/img/AdobeStock_397527752-new-featured-tile.jpg"
                                                                    loading="lazy" class="right-section--imageSrc">

                                                                <div class="mobile-overlay"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="story-list" data-slide-index="1"
                                                    >
                                                    <div class="left-section span5">
                                                        <div class="drag-overlay hide-mobile"></div>
                                                        <div class="client-logo hide-mobile">
                                                                
                                                        </div>
                                                        <div class="client-logo hide-desktop">
                                                            
                                                        </div>
                                                        <div class="story-content">
                                                            <h4>
                                                                <div id="hs_cos_wrapper_module_159558284117034_"
                                                                    class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_inline_text"
                                                                     data-hs-cos-general-type="widget"
                                                                    data-hs-cos-type="inline_text"
                                                                    data-hs-cos-field="story_title">
                                                                    Expanding API- enabled banking operations
                                                                </div>
                                                            </h4>
                                                            <div class="description brand-04-neg-20 small-text">
                                                                <div id="hs_cos_wrapper_module_159558284117034_"
                                                                    class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_inline_rich_text"
                                                                     data-hs-cos-general-type="widget"
                                                                    data-hs-cos-type="inline_rich_text"
                                                                    data-hs-cos-field="description">
                                                                    <p>
                                                                        API Marketplace support and a solution to enable the client's strategic vision of expanding their operations.
                                                                    </p>
                                                                </div>
                                                            </div>
                                                            <h6 class="bottom-text brand-04-neg-20">
                                                                <div id="hs_cos_wrapper_module_159558284117034_"
                                                                    class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_inline_rich_text"
                                                                     data-hs-cos-general-type="widget"
                                                                    data-hs-cos-type="inline_rich_text"
                                                                    data-hs-cos-field="bottom_text"></div>
                                                            </h6>

                                                            <a href="#"
                                                                class="btn btn-outline-secondary page-btn page-btn03 text-capitalize">read
                                                                success story</a>
                                                        </div>
                                                    </div>
                                                    <div class="right-section span7">
                                                        <div class="right-section-content" >
                                                            <div class="right-section--image">
                                                                <img src="assets/img/Expanding API-enabled banking operations_featured-image-tile.jpg"
                                                                    loading="lazy" class="right-section--imageSrc">

                                                                <div class="mobile-overlay"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="story-list" data-slide-index="2" >
                                                    <div class="left-section span5">
                                                        <div class="drag-overlay hide-mobile"></div>
                                                        <div class="client-logo hide-mobile">
                                                            <img src="assets/img/RuV_Logo_Blau.png"
                                                                alt=""
                                                                style="max-width: 50%; height: auto">
                                                        </div>
                                                        <div class="client-logo hide-desktop">
                                                            
                                                        </div>
                                                        <div class="story-content">
                                                            <h4>
                                                                <div id="hs_cos_wrapper_module_159558284117034_"
                                                                    class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_inline_text"
                                                                     data-hs-cos-general-type="widget"
                                                                    data-hs-cos-type="inline_text"
                                                                    data-hs-cos-field="story_title">
                                                                    Streamlining information exchange, improving customer satisfaction
                                                                </div>
                                                            </h4>
                                                            <div class="description brand-04-neg-20 small-text">
                                                                <div id="hs_cos_wrapper_module_159558284117034_"
                                                                    class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_inline_rich_text"
                                                                     data-hs-cos-general-type="widget"
                                                                    data-hs-cos-type="inline_rich_text"
                                                                    data-hs-cos-field="description">
                                                                    R+V Versicherung AG adapt APIs to new industry standards and fulfil branch requirements, while also improving service levels for customers.
                                                                </div>
                                                            </div>
                                                            <h6 class="bottom-text brand-04-neg-20">
                                                                <div id="hs_cos_wrapper_module_159558284117034_"
                                                                    class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_inline_rich_text"
                                                                     data-hs-cos-general-type="widget"
                                                                    data-hs-cos-type="inline_rich_text"
                                                                    data-hs-cos-field="bottom_text"></div>
                                                            </h6>

                                                            <a href="#"
                                                                target="_blank" class="page-btn page-btn03 btn btn-outline-secondary text-capitalize">read success
                                                                story</a>
                                                        </div>
                                                    </div>
                                                    <div class="right-section span7">
                                                        <div class="right-section-content" >
                                                            <div class="right-section--image">
                                                                <img src="assets/img/R+V.jpg"
                                                                    loading="lazy" class="right-section--imageSrc">

                                                                <div class="mobile-overlay"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <!-- Pagination section start -->
                                                <ul class="story--slider-pagination-section">
                                                    <li class="slider-numbers">
                                                        <span class="xs-pagination-number">1</span>
                                                        <span class="total-number">3</span>
                                                    </li>
                                                    <li class="slide-arrow slider-pagination-left"
                                                        id="storyprevSlideControl">
                                                        <svg width="36" height="32" viewBox="0 0 36 32" fill="none"
                                                            xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M34 2C28.5 8.00001 6 16 6 16C6 16 29 25.5 34 30"
                                                                stroke="#13294B" stroke-width="4"
                                                                stroke-linecap="round"></path>
                                                        </svg>
                                                    </li>
                                                    <li class="slide-arrow slider-pagination-right"
                                                        id="storynextSlideControl">
                                                        <svg width="36" height="32" viewBox="0 0 36 32" fill="none"
                                                            xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M2 2C7.5 8.00001 30 16 30 16C30 16 7 25.5 2 30"
                                                                stroke="#13294B" stroke-width="4"
                                                                stroke-linecap="round"></path>
                                                        </svg>
                                                    </li>
                                                </ul>
                                                <!--  Pagination section end -->
                                                <!-- Pagination section start -->
                                                <ul class="story--slider-pagination-section" style="overflow: hidden">
                                                    <li data-pagination-index="0" class="slide-pagination-block active-slide-pagination-block">
                                                        <div class="slide-pagination-number">1</div>
                                                        <div class="slide-pagination-text"></div>
                                                    </li>

                                                    <li data-pagination-index="1"
                                                        class="slide-pagination-block ">
                                                        <div class="slide-pagination-number">2</div>
                                                        <div class="slide-pagination-text"></div>
                                                    </li>

                                                    <li data-pagination-index="2" class="slide-pagination-block">
                                                        <div class="slide-pagination-number">3</div>
                                                        <div class="slide-pagination-text"></div>
                                                    </li>
                                                </ul>
                                                <!--  Pagination section end -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <!--end widget-span -->
        </div>
        <!--end row-->
    </div>

     <!-- Our Partners -->
     <section class="bg-white py-5">
        <h2 class="pb-5 text-center text-capitalize">Our Partners</h2>
        <div class="container-1 mt-5">
            <div class="slide-container">

                <div class="slide-img d-block text-center">
                    <img src="assets/img/Apigee_logo.svg.png" class="img-s" alt="">
                    <p class="fs-5 fst-italic">As a reselling partner of Google Apigee, ICEICO engages with the client to provide value potential API - enabled solutions where Apigee plays a pivotal role in the journey.</p>
                </div>

                <div class="slide-img d-block text-center">
                    <img src="assets/img/azure-250.png" class="img-s" alt="">
                    <p class="fs-5 fst-italic">As Microsoft Cloud Gold Partner, ICEICO provides Azure APIM-based solutions to clients whose IT landscape is rich in Azure or in architectural need of the solution.</p>
                </div>

                <div class="slide-img d-block text-center">
                    <img src="assets/img/Amazon_Web_Services_Logo 1.svg" class="img-s" alt="">
                    <p class="fs-5 fst-italic">As an AWS consulting partner, ICEICO helps customers to unlock the full potential of an AWS cloud transformation by leveraging a respective API management solution.</p>
                </div>

                <div class="slide-img d-block text-center">
                    <img src="assets/img/wso2-logo.png" class="img-s" alt="">
                    <p class="fs-5 fst-italic">ICEICO is a system integrator partner to provide WSO2-based APIM solutions for clients. Together we help design and implement digital solutions using WSO2 as an API Management platform.</p>
                </div>
                
                <div class="slide-img d-block text-center">
                    <img src="assets/img/Broadcom.png" class="img-s" alt="">
                    <p class="fs-5 fst-italic">For Broadcom Layer7, ICEICO acts as a system integrator partner to provide Layer7 based APIM solutions for clients where ICEICO helps in designing and implementing digital solutions using Layer7 as an API Management platform.</p>
                </div>

                <div class="slide-img d-block text-center">
                    <img src="assets/img/APIIDA-Logo-mit-Claim-2C.jpg" class="img-s" alt="">
                    <p class="fs-5 fst-italic">With Apiida, ICEICO acts as a joint consulting, implementation, and service partner to provide APIM-enabled solutions using Layer7 as a platform for clients of a different magnitude - small, medium, or large.</p>
                </div>

               
                <div class="slide-img d-block text-center">
                    <img src="assets/img/Apigee_logo.svg.png" class="img-s" alt="">
                    <p class="fs-5 fst-italic">As a reselling partner of Google Apigee, ICEICO engages with the client to provide value potential API - enabled solutions where Apigee plays a pivotal role in the journey.</p>
                </div>

                <div class="slide-img d-block text-center">
                    <img src="assets/img/azure-250.png" class="img-s" alt="">
                    <p class="fs-5 fst-italic">As Microsoft Cloud Gold Partner, ICEICO provides Azure APIM-based solutions to clients whose IT landscape is rich in Azure or in architectural need of the solution.</p>
                </div>

                <div class="slide-img d-block text-center">
                    <img src="assets/img/Amazon_Web_Services_Logo 1.svg" class="img-s" alt="">
                    <p class="fs-5 fst-italic">As an AWS consulting partner, ICEICO helps customers to unlock the full potential of an AWS cloud transformation by leveraging a respective API management solution.</p>
                </div>

                <div class="slide-img d-block text-center">
                    <img src="assets/img/wso2-logo.png" class="img-s" alt="">
                    <p class="fs-5 fst-italic">ICEICO is a system integrator partner to provide WSO2-based APIM solutions for clients. Together we help design and implement digital solutions using WSO2 as an API Management platform.</p>
                </div>
                
                <div class="slide-img d-block text-center">
                    <img src="assets/img/Broadcom.png" class="img-s" alt="">
                    <p class="fs-5 fst-italic">For Broadcom Layer7, ICEICO acts as a system integrator partner to provide Layer7 based APIM solutions for clients where ICEICO helps in designing and implementing digital solutions using Layer7 as an API Management platform.</p>
                </div>

                <div class="slide-img d-block text-center">
                    <img src="assets/img/APIIDA-Logo-mit-Claim-2C.jpg" class="img-s" alt="">
                    <p class="fs-5 fst-italic">With Apiida, ICEICO acts as a joint consulting, implementation, and service partner to provide APIM-enabled solutions using Layer7 as a platform for clients of a different magnitude - small, medium, or large.</p>
                </div>

               
               
            </div>
        </div>
    </section>


    <!-- featured insights -->
    <section class="container-fluid bg-white py-5">
        <div class="container">
            <div class="featured1 mt-5 mb-5">
                <h2 class="text-center pb-5 text-capitalize">featured insights</h2>
                <div class="row justify-content-center">
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/APIM-Digital-Transformation-F-min.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Platform-based API management: Strategic enabler of digital transformation</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp; &nbsp; Feb 23, 2023</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/APIM-Data-Security-M-min.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">API Security: A pragmatic approach to safeguarding data </p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp; &nbsp; Oct 4, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/video_apim.png" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">"How to"- video snippets with API managment experts</p>
                                <span class="position-absolute"><a href="" class="text-success">Video playlist</a></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/API pitfalls_blog_tile.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-1 p-md-3 p-sm-3">10 potential pitfalls to avoid on your API- fication journey</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp; &nbsp; Jul 13, 2021</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/AdobeStock_359397898_Open_Banking_WhitePaper_Banner_featured-tile.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-1 p-md-3 p-sm-3">Embracing open banking with enterprise agility</p>
                                <span class="position-absolute"><a href="" class="text-success">White Paper</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/cover_whitepaper.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-1 p-md-3 p-sm-3">Preparing for tech-first future in financial services</p>
                                <span class="position-absolute"><a href="" class="text-success">White Paper</a></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/bfsi_flyer_tile.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Banking in transition- embracing API-enabled business transformation</p>
                                <span class="position-absolute"><a href="" class="text-success">White Paper</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Automotive2_0.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Automotive OEM 2.0: Drive innovation with API technologies and marketplaces </p>
                                <span class="position-absolute"><a href="" class="text-success">White Paper</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/apim-aviation-webinar-airline newsletter.png" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Building a future-ready airline based on API management</p>
                                <span class="position-absolute"><a href="" class="text-success">On-demand webinar</a></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- //user Review  -->
    <section class="py-3">
  <div class="container  responsive-container text-center">
    <h2 class="fs-2 pt-2 pt-5 text-center text-light">Our Community With User Review</h2>
    <div class="m-md-5 py-5 py-lg-0 py-md-0 row user-review-background">

      <div class="col-12 col-lg-4 col-sm-12 mt-0 mt-lg-5 mt-md-5 ps-sm-5 pt-sm-5"><img src="assets/img/Group 1.png" class="ellipseimg pt-0" alt="" width="150" height="100"></div>
      <div class="col-12 col-lg-5 col-sm-12 offset-lg-0 p-lg-5 text-center user-prghp" style="height: 240px;">
        <p>The system has produced a significant competitive advantage in the industry thanks to ICEICO Technologies well-thought opinions.

They shouldered the burden of constantly updating a project management tool with a high level of detail and were committed to producing the best possible solution. <br>-Amol Ramteke, Business Owner of Carbonblack.education</p>

      </div>

    </div>
  </div>

</section>

    <!-- footer section  start-->
    

<div class="mt-4">
  <div class="footer footer-bg">
    <div class="container ">
      <div class="row">
        <div class="col-sm-6 p-md-5 p-sm-2 text-center">
          <h3 style="color:white;">Contact Us</h3>
          <p style="color:#0fc88a;">ICEICO TECHNOLOGIES PVT. LTD. <br> Plot No. 91, Ganesh Nagar, Azamshah Layout, Nandanwan, Nagpur, Maharashtra 440009 </p>
         
        </div>


        <div class="col-sm-6 p-5 text-center">
          <div>
            <h3 style="color:white ;">NEWSLETTER</h3>
          </div>
          <div>
            <!--<span><input type="Email" class="emailform " placeholder="Email Address"><button class="formbutton">Submit</button></span>-->
            <div class="input-group mx-auto w-50">
                <input type="email" class="form-control emailform bg-transparent text-white" placeholder="Email Address" aria-label="Input group example" aria-describedby="btnGroupAddon" >
                <button class="input-group-text formbutton px-2" id="btnGroupAddon">Submit</button>    
            </div>

          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-sm-6 p-md-5  ">
          <div class="row">
            <div class="col-sm-6 col-12 p-3 text-center">
              <ul style="list-style-type:none;">
                <caption><span class="cptndetail"><b>About Us</b></span></caption>
                <li class="p-3"><a class="listdetails" href="">Whitepaper</a></li>
                <li class="p-3"><a class="listdetails" href="blog.php">Blog</a></li>
                <li class="p-3"><a class="listdetails" href="">Activity</a></li>

              </ul>
            </div>


            <div class="col-sm-6 col-12 p-md-3 text-center">
              <ul style="list-style-type:none;">
                <caption><span class="cptndetail"><b>support</b></span></caption>
                <li class="p-3"><a class="listdetails" href="">Author Profile</a></li>
                <li class="p-3"><a class="listdetails" href="">Community</a></li>
                <li class="p-3"><a class="listdetails" href="">Help & support</a></li>
                <li class="p-3"><a class="listdetails" href="contact_us.php">Contact</a></li>

              </ul>
            </div>
          </div>

        </div>
        <div class="col-sm-6 p-5 text-center">
          <h3 class="mt-5" style="color: white;">Social Media</h3>
          <div class="mt-2">
            <i class="bi bi-facebook p-2"></i>
            <i class="bi bi-twitter p-2"></i>
            <i class="bi bi-instagram p-2"></i>
          </div>
        </div>

      </div>
    </div>


  </div>
</div>    </section>

    <script src="assets/vendor/aos/aos.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
    <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
    <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
    <script src="assets/vendor/php-email-form/validate.js"></script>
    <script src="assets/js/main.js"></script>
    <script src="assets/js/img_slider.js"></script>

</body>

</html>