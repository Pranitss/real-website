<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>ICEICO - Identity and Access Management</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Favicons -->
    <!-- <link href="assets/img/favicon.png" rel="icon"> -->
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Vendor CSS Files -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <script src="https://kit.fontawesome.com/4669dfa340.js" crossorigin="anonymous"></script>

    <link href="assets/vendor/aos/aos.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
    <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

    <!--Main CSS File -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/slide_animation.css" rel="stylesheet">

    <style>
        .position-absolute {
            position: absolute;
            bottom: 20px;
            left: 35px;
        }

        .container-1 {
            height: 535px !important;
        }
    </style>

</head>

<body id="aboutbg">

    <!-- ======= Header ======= -->
    <!-- ======= Header ======= -->

<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
    <div class="container-xl">
        <a class="navbar-brand" href="index.php"><img src="assets/img/Group 1.png" alt="logo" class="img-fluid" style="max-width: 100%; width: 70px" /></a>
        <button class="navbar-toggler collapsed" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon" style="width: 5vw"></span>
        </button>
        <div class="navbar-collapse collapse" id="navbarNavDropdown" style="">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <div class="separator" style="
                        height: 1px;
                        border-top: 1px solid rgba(255, 255, 255, 0.55);
                        margin-left: 20px;
                        margin-right: 20px;
                        width: 150px;
                        flex: 1;
                        margin-top: 20px;
            "></div>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="industries.php" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Industries
                    </a>
                    <ul class="text-light dropdown-menu p-3 pt-3 pb-3" aria-labelledby="navbarDropdownMenuLink">
                        <li>
                            <a class="link-light dropdown-item" href="gaming.php">Gaming &amp; Entertainment</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="life-sciences.php">Life sciences &amp;
                                healthcare</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="media.php">Media &amp; publishing</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="non-profits.php">Non-profits and education</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="retails.php">Retail &amp; cpg</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="smart-buildings.php">Smart buildings</a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Services
                    </a>
                    <ul class="container container-sm text-light dropdown-menu overflow dropdown-menu-scrollable" aria-labelledby="navbarDropdownMenuLink" style="width: 100vw; left: -400px; margin: 0px -20px">
                        <li class="p-2 pb-5 pt-5 row">
                            <section class="col-lg-3 col-md-12 col-sm-12 d-lg-block d-md-none">
                                <ul class="mylist">
                                    <li>
                                        <div class="menu-title fs-3">Services</div>
                                    </li>
                                    <li>
                                        <p class="">
                                            Accelerate your vision with technologies that are both
                                            agile and cutting edge.
                                        </p>
                                    </li>
                                    <li class="position-absolute top-50">
                                        <a href="all_services.php" class="link-light p-5 pt-2 pb-2 bg-success link-hover d-none d-lg-block" style="border-radius: 50px">view all services</a>
                                    </li>
                                </ul>
                            </section>
                            <section class="col-lg-3 col-md-12 col-sm-12">
                                <ul class="mylist">
                                    <li>
                                        <a href="accelerated-quality.php" class="link-light dropdown-item">
                                            <h6>accelerated quality &amp; test-engineering</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="agile.php" class="link-light dropdown-item">
                                            <h6>agile</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="api-mgmt.php" class="link-light dropdown-item">
                                            <h6>api management</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="app-develop.php" class="link-light dropdown-item">
                                            <h6>application development</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="app-manage.php" class="link-light dropdown-item">
                                            <h6>application managed services</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="ai-da.php" class="link-light dropdown-item">
                                            <h6>artificial intelligence, data &amp; analytics</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="blockchain.php" class="link-light dropdown-item">
                                            <h6>blockchain</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="cloud.php" class="link-light dropdown-item">
                                            <h6>cloud</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="crm.php" class="link-light dropdown-item">
                                            <h6>crm</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="customer-communications.php" class="link-light dropdown-item">
                                            <h6>customer communications</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="design.php" class="link-light dropdown-item">
                                            <h6>design</h6>
                                        </a>
                                    </li>
                                </ul>
                            </section>
                            <section class="col-lg-3 col-md-12 col-sm-12">
                                <ul class="mylist">
                                    <li>
                                        <a href="devops.php" class="link-light dropdown-item">
                                            <h6>devops</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="digital-commerce.php" class="link-light dropdown-item">
                                            <h6>digital commerce</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="digital-experiences.php" class="link-light dropdown-item">
                                            <h6>digital experiences</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="digital-ventures.php" class="link-light dropdown-item">
                                            <h6>digital ventures</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="ecm-&amp;-portals.php" class="link-light dropdown-item">
                                            <h6>ecm &amp; portals</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="embedded.php" class="link-light dropdown-item">
                                            <h6>embedded systems</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="enterprising consu.php" class="link-light dropdown-item">
                                            <h6>enterprise architecture consulting</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="erp.php" class="link-light dropdown-item">
                                            <h6>erp</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="identify man.php" class="link-light dropdown-item">
                                            <h6>identity and access management</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="inovation.php" class="link-light dropdown-item">
                                            <h6>innovation</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="internet of things.php" class="link-light dropdown-item">
                                            <h6>internet of things</h6>
                                        </a>
                                    </li>
                                </ul>
                            </section>
                            <section class="col-lg-3 col-md-12 col-sm-12">
                                <ul class="mylist">
                                    <li>
                                        <a href="low code.php" class="link-light dropdown-item">
                                            <h6>low code</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="mainfraim &amp; legacy.php" class="link-light dropdown-item">
                                            <h6>mainframe &amp; legacy</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="mobility solu.php" class="link-light dropdown-item">
                                            <h6>mobility solutions</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="process consulting.php" class="link-light dropdown-item">
                                            <h6>process consulting</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="product engeeniring.php" class="link-light dropdown-item">
                                            <h6>product engineering</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="resilience_engineering.php" class="link-light dropdown-item">
                                            <h6>resilience engineering</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="sap_services.php" class="link-light dropdown-item">
                                            <h6>sap services</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="security.php" class="link-light dropdown-item">
                                            <h6>security</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="technical_communication.php" class="link-light dropdown-item">
                                            <h6>technical communication</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="trainings.php" class="link-light dropdown-item">
                                            <h6>trainings</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="transformation.php" class="link-light dropdown-item">
                                            <h6>transformation and modernization</h6>
                                        </a>
                                    </li>
                                </ul>
                            </section>
                        </li>
                    </ul>
                </li>
                <li class="nav-item dropdown overflow">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Insights
                    </a>
                    <ul class="container container-sm text-light dropdown-menu dropdown-menu-scrollable" aria-labelledby="navbarDropdownMenuLink" style="width: 100vw; left: -490px; margin: 0 -20px">
                        <li class="container container-sm insight p-2 pb-4 pt-4" style="width: 100vw; left: -825px">
                            <div class="headings">
                                <div class="row text-center p-1 d-lg-flex d-md-none">
                                    <div class="col-md-6 fs-2">Thinking Breakthroughs</div>
                                    <div class="col-md-6">
                                        <a href="#" class="link-light p-5 pt-2 pb-2 bg-success link-hover d-none d-lg-inline-block">
                                            Explore our best ideas</a>
                                    </div>
                                </div>
                                <hr />
                                <div class="row p-5 pt-4 pb-4">
                                    <section class="col-lg-4 col-md-12 col-sm-12">
                                        <ul class="mylist">
                                            <li>
                                                <div class="fs-6 p-3 pt-0 pb-0 text-success">Filter by Goal</div>
                                            </li>
                                            <li>
                                                <a href="modernize.php" class="link-light dropdown-item fs-3">Modernize</a>
                                            </li>
                                            <li>
                                                <a href="optimize.php" class="link-light dropdown-item fs-3">Optimize</a>
                                            </li>
                                            <li>
                                                <a href="innovate.php" class="link-light dropdown-item fs-3">Innovate</a>
                                            </li>
                                            <li>
                                                <a href="disrupt.php" class="link-light dropdown-item fs-3">Disrupt</a>
                                            </li>
                                            <li>
                                                <a href="transform.php" class="link-light dropdown-item fs-3">Transform</a>
                                            </li>
                                        </ul>
                                    </section>
                                    <section class="col-lg-4 col-md-12 col-sm-12 border-right" style="border-left: 1px solid #999">
                                        <ul class="mylist">
                                            <li>
                                                <div class="fs-6 p-3 pt-0 pb-0 text-success">
                                                    Trending technologies
                                                </div>
                                            </li>
                                            <li>
                                                <a href="ai_ml.php" class="link-light dropdown-item fs-5">AI and ML</a>
                                            </li>
                                            <li>
                                                <a href="data_science.php" class="link-light dropdown-item fs-5">Data Science</a>
                                            </li>
                                            <li>
                                                <a href="iot.php" class="link-light dropdown-item fs-5">IoT</a>
                                            </li>
                                            <li>
                                                <a href="low_code_ins.php" class="link-light dropdown-item fs-5">Low Code</a>
                                            </li>
                                            <li>
                                                <a href="api_ins.php" class="link-light dropdown-item fs-5">API-Management</a>
                                            </li>
                                            <li>
                                                <a href="aqt.php" class="link-light dropdown-item fs-5">AQT</a>
                                            </li>
                                            <li>
                                                <a href="cloud_ins.php" class="link-light dropdown-item fs-5">Cloud</a>
                                            </li>
                                            <li>
                                                <a href="agile_ins.php" class="link-light dropdown-item fs-5">Agile</a>
                                            </li>
                                            <li>
                                                <a href="devops_ins.php" class="link-light dropdown-item fs-5">DevOps</a>
                                            </li>
                                            <li>
                                                <a href="chaos_engineering.php" class="link-light dropdown-item fs-5">Chaos Engineering</a>
                                            </li>
                                            <li>
                                                <a href="data_mesh.php" class="link-light dropdown-item fs-5">Data Mesh</a>
                                            </li>
                                        </ul>
                                    </section>
                                    <section class="col-lg-4 col-md-12 col-sm-12 border-right" style="border-left: 1px solid #999">
                                        <ul class="mylist">
                                            <li>
                                                <div class="fs-6 p-3 pt-0 pb-0 text-success">Industry</div>
                                            </li>
                                            <li>
                                                <a href="automotive_ins.php" class="link-light dropdown-item">Automotive</a>
                                            </li>
                                            <li>
                                                <a href="banking_financial_ins.php" class="link-light dropdown-item">Banking and Financial
                                                    Services</a>
                                            </li>
                                            <li>
                                                <a href="insurance_ins.php" class="link-light dropdown-item">Insurance</a>
                                            </li>
                                            <li>
                                                <a href="energy_ins.php" class="link-light dropdown-item">Energy and Utilities</a>
                                            </li>
                                            <li>
                                                <a href="gaming_ins.php" class="link-light dropdown-item">Gaming and
                                                    Entertainment</a>
                                            </li>
                                            <li>
                                                <a href="isv_ins.php" class="link-light dropdown-item">ISV</a>
                                            </li>
                                            <li>
                                                <a href="life_science_ins.php" class="link-light dropdown-item">Life-sciences and
                                                    Healthcare</a>
                                            </li>
                                            <li>
                                                <a href="media_ins.php" class="link-light dropdown-item">Media and Publishing</a>
                                            </li>
                                            <li>
                                                <a href="retail_cpg_ins.php" class="link-light dropdown-item">Retail and CPG</a>
                                            </li>
                                            <li>
                                                <a href="telecommunications_ins.php" class="link-light dropdown-item">Telecommunications</a>
                                            </li>
                                            <li>
                                                <a href="travel_ins.php" class="link-light dropdown-item">Travel &amp; Logistics</a>
                                            </li>
                                            <li>
                                                <a href="industry_ins.php" class="link-light dropdown-item">Industry and Automation</a>
                                            </li>
                                            <li>
                                                <a href="non_profits_ins.php" class="link-light dropdown-item">Non-profits and
                                                    Education</a>
                                            </li>
                                            <li>
                                                <a href="public_sector_ins.php" class="link-light dropdown-item">Public Sector</a>
                                            </li>
                                        </ul>
                                    </section>
                                </div>
                            </div>
                        </li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="maintenance.php" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-expanded="false">
                        Maintenance
                    </a>
                </li>
            </ul>

            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        About us
                    </a>
                    <div class="text-light dropdown-menu p-3 pt-3 pb-3" aria-labelledby="navbarDropdownMenuLink">
                        <a class="link-light dropdown-item" href="canyoutrustus.php">Can you trust us
                        </a>

                        <a class="link-light dropdown-item" href="reasontojoin.php">10 reason to join
                        </a>
                    </div>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Careers
                    </a>
                    <ul class="text-light dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                        <li>
                            <a class="link-light dropdown-item" href="action.php">Action</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="another_action.php">Another action</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="else_here.php">Something else here</a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="contact_us.php" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-expanded="false">
                        Contact us
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- End Header -->    <!-- End Header -->
    <section style="background-color: #13294B;padding: 100px 10px;">
        <div class="container builddetails">
            <div id="acc-bgimg">
                <div class=" py-lg-0 p-5 order-2 order-lg-1 mt-3" data-aos="fade-right">
                    <a id=" " class="fs-3 text-white text-capitalize" href="">Services </a> &nbsp;<a href="" class="text-success fs-3 text-capitalize">identity and access management</a>
                    <h1 class="text-capitalize text-start">Secure management of identities, entitlements, and access</h1>
                </div>
            </div>
        </div>
    </section>

    <section class="bg-white py-5">
        <div class="container p-5" style="text-align:justify;">
            <p class="fs-5">Identity and access management (IAM) is the discipline that enables the right individuals to access the right resources at the right times and for the right reasons. </p>
            <p class="fs-5"> As Companies continue to move to software as a service and public cloud services (AWS, Azure, GCP, etc.), keeping control over services, policies, permissions, and capabilities is more challenging. The task of knowing who or what has access to which resources is becoming a source of difficulty and even a possible security risk.</p>
            <p class="fs-5">At ICEICO, our experts leverage market-leading products to solve problems for a wide range of areas. These include user lifecycle management, user access governance, and authentication management across the premises, cloud, and hybrid deployments. We enable industry leaders to optimize their information security and risk management programs with our IAM solutions. </p>
        </div>
    </section>

    <!-- What we do -->
    <section class=" bg-white py-5">
        <div class="container">
            <h2 class="pb-5 text-center text-capitalize"> What We Do</h2>
            <div class="row text-center text-lg-start">
                <div class="col-lg-4 col-12 p-5">
                    <h4 class="p-0 pt-0">IDM</h4>
                    <img src="assets/img/title-underline.jpg" alt="">
                    <p class="text-secondary p-0 pt-4 pb-4">Create a digital identity for a person or device and manage access requests with approval workflows.</p>

                </div>
                <div class="col-lg-4 col-12 p-5">
                    <h4 class="p-0 pt-0">AM</h4>
                    <img src="assets/img/title-underline.jpg" alt="">
                    <p class="text-secondary p-0 pt-4 pb-4">Control user access to critical information through centralised authentication and authorization.</p>


                </div>

                <div class="col-lg-4 col-12 p-5">
                    <h4 class="p-0 pt-0">Governance</h4>
                    <img src="assets/img/title-underline.jpg" alt="">
                    <p class="text-secondary p-0 pt-4 pb-4">Improve control of access by implementing centralised audits and implement compliance rules according to regulations.
                    </p>

                </div>
            </div>
            <div class="row text-center text-lg-start">
                <div class="col-lg-4 col-12 p-5">
                    <h4 class="p-0 pt-0">Single Sign-on
                    </h4>
                    <img src="assets/img/title-underline.jpg" alt="">
                    <p class="text-secondary p-0 pt-4 pb-4">Provide web SSO to improve user experience with a single user login for all integrated applications.</p>

                </div>

                <div class="col-lg-4 col-12 p-5">
                    <h4 class="p-0 pt-0">identity cloud</h4>
                    <img src="assets/img/title-underline.jpg" alt="">
                    <p class="text-secondary p-0 pt-4 pb-4">Leverage a cloud platform for all your IAM needs without worrying about maintenance, patching or upgrading. .</p>

                </div>
                <div class="col-lg-4 col-12 p-5">
                    <h4 class="p-0 pt-0">Zero Trust</h4>
                    <img src="assets/img/title-underline.jpg" alt="">
                    <p class="text-secondary p-0 pt-4 pb-4">Use modern IAM as the foundation for establishing a continuous, trust-oriented authorization approach.</p>

                </div>
                <div class="col-lg-4 col-12 p-5">
                    <h4 class="p-0 pt-0">Analytics</h4>
                    <img src="assets/img/title-underline.jpg" alt="">
                    <p class="text-secondary p-0 pt-4 pb-4">Gain visibility into how access to data is used once granted and discover unused privileges by monitoring and analysing user behaviour.</p>

                </div>
                <div class="col-lg-4 col-12 p-5">
                    <h4 class="p-0 pt-0">AI</h4>
                    <img src="assets/img/title-underline.jpg" alt="">
                    <p class="text-secondary p-0 pt-4 pb-4">Apply machine learning to establish normal behavior and adjust the security challenges based on the situation.</p>

                </div>
            </div>
        </div>
    </section>
    <!--  End what we do -->

    <!-- our partners -->
    <section class="bg-white py-5">
        <div class="container">
            <h2 class="pb-5 text-center text-capitalize">Our partner</h2>
            <div class="row text-center text-lg-start">
                <div class="col-lg-3 col-md-3 col-sm-12 me-4">
                    <img src="assets/img/d459f7a6-3c3f-4134-a919-7a1d00e7b7cb.png" alt="" class="img-s">
                    <h4 class="pb-3 pt-4">ForgeRock</h4>
                    <p class="text-black-50">ICEICO has worked closely with ForgeRock since it's foundation in 2010, and the companies have developed a highly trusted partnership with each other. Initially, based on open source, ForgeRock has built one of the most robust and reliable IAM platforms there is.</p>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-12 me-4">
                    <img src="assets/img/microsoft-azure.svg" alt="" class="img-s">
                    <h4 class="pb-3 pt-4">Microsoft Azure</h4>
                    <p class="text-black-50">ICEICO is a Microsoft Cloud Gold Partner and a Microsoft Azure reseller making cloud accessible to every company and organization, from small or large to established or new.</p>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-12 me-4">
                    <img src="assets/img/385-3854337_keycloak-logo-600px-keycloak-spring.png" alt="" class="img-s">
                    <h4 class="pb-3 pt-4">Keycloak</h4>
                    <p class="text-black-50">Our experts deliver open source Keycloak IAM solutions. Keycloak is developed by Red Hat and implements popular standards such as SAML 2.0, OpenID Connect and OAuth 2.0.</p>
                </div>
            </div>
        </div>
    </section>


    <!-- our experts -->
    <!--<section class="bg-white py-5">-->
    <!--    <div class="container container-1">-->
    <!--        <h2 class="pb-5 text-center text-capitalize">meet our experts</h2>-->
    <!--        <div class="row slide-container">-->
    <!--            <div class="slide-img col-md-3 col-sm-12 col-lg-3 py-2 d-block">-->
    <!--                <img src="assets/img/IAM_frank-500.jpg" alt="" class="img-fluid">-->
    <!--                <h2>Frank R Svendson</h2>-->
    <!--                <h5 class="text-secondary">Practice Lead - IAM,</h5>-->
    <!--                <h5 class="text-secondary">Norway</h5>-->
    <!--                <a href="#" class="text-secondary"><i class="fa-brands fa-linkedin"></i> connect</a>-->
    <!--            </div>-->
    <!--            <div class="slide-img col-md-3 col-sm-12 col-lg-3 py-2 d-block">-->
    <!--                <img src="assets/img/IAM_Baanusha_500.jpg" alt="" class="img-fluid">-->
    <!--                <h2>Baanusha Niros</h2>-->
    <!--                <h5 class="text-secondary">Specialist - IAM,</h5>-->
    <!--                <h5 class="text-secondary">Norway</h5>-->
    <!--                <a href="#" class="text-secondary"><i class="fa-brands fa-linkedin"></i> connect</a>-->
    <!--            </div>-->
    <!--            <div class="slide-img col-md-3 col-sm-12 col-lg-3 py-2 d-block">-->
    <!--                <img src="assets/img/IAM_hakon_bommen-500.jpg" alt="" class="img-fluid">-->
    <!--                <h2>Hakon Bommen</h2>-->
    <!--                <h5 class="text-secondary">Senior Consultant - IAM,</h5>-->
    <!--                <h5 class="text-secondary">Norway</h5>-->
    <!--                <a href="#" class="text-secondary"><i class="fa-brands fa-linkedin"></i> connect</a>-->
    <!--            </div>-->
    <!--            <div class="slide-img col-md-3 col-sm-12 col-lg-3 py-2 d-block">-->
    <!--                <img src="assets/img/Atul.jpg" alt="" class="img-fluid">-->
    <!--                <h2>Atul Gupta</h2>-->
    <!--                <h5 class="text-secondary">Senior Architect - IAM, </h5>-->
    <!--                <h5 class="text-secondary">India</h5>-->
    <!--                <a href="#" class="text-secondary"><i class="fa-brands fa-linkedin"></i> connect</a>-->
    <!--            </div>-->
    <!--            <div class="slide-img col-md-3 col-sm-12 col-lg-3 py-2 d-block">-->
    <!--                <img src="assets/img/IAM_eirik_synnes-500.jpg" alt="" class="img-fluid">-->
    <!--                <h2>Eirik Synnes</h2>-->
    <!--                <h5 class="text-secondary">Senior Consultant - IAM, </h5>-->
    <!--                <h5 class="text-secondary">Norway</h5>-->
    <!--                <a href="#" class="text-secondary"><i class="fa-brands fa-linkedin"></i> connect</a>-->
    <!--            </div>-->
    <!--            <div class="slide-img col-md-3 col-sm-12 col-lg-3 py-2 d-block">-->
    <!--                <img src="assets/img/IAM_roger_hansen-500.jpg" alt="" class="img-fluid">-->
    <!--                <h2>Roger Hansen</h2>-->
    <!--                <h5 class="text-secondary">Senior Consultant - IAM,</h5>-->
    <!--                <h5 class="text-secondary">Norway</h5>-->
    <!--                <a href="#" class="text-secondary"><i class="fa-brands fa-linkedin"></i> connect</a>-->
    <!--            </div>-->
    <!--            <div class="slide-img col-md-3 col-sm-12 col-lg-3 py-2 d-block">-->
    <!--                <img src="assets/img/IAM_sachin_dave-500.jpg" alt="" class="img-fluid">-->
    <!--                <h2>Sachin Dave</h2>-->
    <!--                <h5 class="text-secondary">Senior Architect - IAM,</h5>-->
    <!--                <h5 class="text-secondary">Norway</h5>-->
    <!--                <a href="#" class="text-secondary"><i class="fa-brands fa-linkedin"></i> connect</a>-->
    <!--            </div>-->
    <!--            <div class="slide-img col-md-3 col-sm-12 col-lg-3 py-2 d-block">-->
    <!--                <img src="assets/img/IAM_jonn-erik_farmen-500.jpg" alt="" class="img-fluid">-->
    <!--                <h2>Jonn Erik Farmen</h2>-->
    <!--                <h5 class="text-secondary">Architect - IAM,</h5>-->
    <!--                <h5 class="text-secondary">Norway</h5>-->
    <!--                <a href="#" class="text-secondary"><i class="fa-brands fa-linkedin"></i> connect</a>-->
    <!--            </div>-->
    <!--            <div class="slide-img col-md-3 col-sm-12 col-lg-3 py-2 d-block">-->
    <!--                <img src="assets/img/IAM_frank-500.jpg" alt="" class="img-fluid">-->
    <!--                <h2>Frank R Svendson</h2>-->
    <!--                <h5 class="text-secondary">Practice Lead - IAM,</h5>-->
    <!--                <h5 class="text-secondary">Norway</h5>-->
    <!--                <a href="#" class="text-secondary"><i class="fa-brands fa-linkedin"></i> connect</a>-->
    <!--            </div>-->
    <!--            <div class="slide-img col-md-3 col-sm-12 col-lg-3 py-2 d-block">-->
    <!--                <img src="assets/img/IAM_Baanusha_500.jpg" alt="" class="img-fluid">-->
    <!--                <h2>Baanusha Niros</h2>-->
    <!--                <h5 class="text-secondary">Specialist - IAM,</h5>-->
    <!--                <h5 class="text-secondary">Norway</h5>-->
    <!--                <a href="#" class="text-secondary"><i class="fa-brands fa-linkedin"></i> connect</a>-->
    <!--            </div>-->
    <!--            <div class="slide-img col-md-3 col-sm-12 col-lg-3 py-2 d-block">-->
    <!--                <img src="assets/img/IAM_hakon_bommen-500.jpg" alt="" class="img-fluid">-->
    <!--                <h2>Hakon Bommen</h2>-->
    <!--                <h5 class="text-secondary">Senior Consultant - IAM,</h5>-->
    <!--                <h5 class="text-secondary">Norway</h5>-->
    <!--                <a href="#" class="text-secondary"><i class="fa-brands fa-linkedin"></i> connect</a>-->
    <!--            </div>-->
    <!--            <div class="slide-img col-md-3 col-sm-12 col-lg-3 py-2 d-block">-->
    <!--                <img src="assets/img/Atul.jpg" alt="" class="img-fluid">-->
    <!--                <h2>Atul Gupta</h2>-->
    <!--                <h5 class="text-secondary">Senior Architect - IAM, </h5>-->
    <!--                <h5 class="text-secondary">India</h5>-->
    <!--                <a href="#" class="text-secondary"><i class="fa-brands fa-linkedin"></i> connect</a>-->
    <!--            </div>-->
    <!--            <div class="slide-img col-md-3 col-sm-12 col-lg-3 py-2 d-block">-->
    <!--                <img src="assets/img/IAM_eirik_synnes-500.jpg" alt="" class="img-fluid">-->
    <!--                <h2>Eirik Synnes</h2>-->
    <!--                <h5 class="text-secondary">Senior Consultant - IAM, </h5>-->
    <!--                <h5 class="text-secondary">Norway</h5>-->
    <!--                <a href="#" class="text-secondary"><i class="fa-brands fa-linkedin"></i> connect</a>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</section>-->

    <!-- //user Review  -->
    <section class="py-3">
  <div class="container  responsive-container text-center">
    <h2 class="fs-2 pt-2 pt-5 text-center text-light">Our Community With User Review</h2>
    <div class="m-md-5 py-5 py-lg-0 py-md-0 row user-review-background">

      <div class="col-12 col-lg-4 col-sm-12 mt-0 mt-lg-5 mt-md-5 ps-sm-5 pt-sm-5"><img src="assets/img/Group 1.png" class="ellipseimg pt-0" alt="" width="150" height="100"></div>
      <div class="col-12 col-lg-5 col-sm-12 offset-lg-0 p-lg-5 text-center user-prghp" style="height: 240px;">
        <p>The system has produced a significant competitive advantage in the industry thanks to ICEICO Technologies well-thought opinions.

They shouldered the burden of constantly updating a project management tool with a high level of detail and were committed to producing the best possible solution. <br>-Amol Ramteke, Business Owner of Carbonblack.education</p>

      </div>

    </div>
  </div>

</section>



    <!-- footer section  start-->
    

<div class="mt-4">
  <div class="footer footer-bg">
    <div class="container ">
      <div class="row">
        <div class="col-sm-6 p-md-5 p-sm-2 text-center">
          <h3 style="color:white;">Contact Us</h3>
          <p style="color:#0fc88a;">ICEICO TECHNOLOGIES PVT. LTD. <br> Plot No. 91, Ganesh Nagar, Azamshah Layout, Nandanwan, Nagpur, Maharashtra 440009 </p>
         
        </div>


        <div class="col-sm-6 p-5 text-center">
          <div>
            <h3 style="color:white ;">NEWSLETTER</h3>
          </div>
          <div>
            <!--<span><input type="Email" class="emailform " placeholder="Email Address"><button class="formbutton">Submit</button></span>-->
            <div class="input-group mx-auto w-50">
                <input type="email" class="form-control emailform bg-transparent text-white" placeholder="Email Address" aria-label="Input group example" aria-describedby="btnGroupAddon" >
                <button class="input-group-text formbutton px-2" id="btnGroupAddon">Submit</button>    
            </div>

          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-sm-6 p-md-5  ">
          <div class="row">
            <div class="col-sm-6 col-12 p-3 text-center">
              <ul style="list-style-type:none;">
                <caption><span class="cptndetail"><b>About Us</b></span></caption>
                <li class="p-3"><a class="listdetails" href="">Whitepaper</a></li>
                <li class="p-3"><a class="listdetails" href="blog.php">Blog</a></li>
                <li class="p-3"><a class="listdetails" href="">Activity</a></li>

              </ul>
            </div>


            <div class="col-sm-6 col-12 p-md-3 text-center">
              <ul style="list-style-type:none;">
                <caption><span class="cptndetail"><b>support</b></span></caption>
                <li class="p-3"><a class="listdetails" href="">Author Profile</a></li>
                <li class="p-3"><a class="listdetails" href="">Community</a></li>
                <li class="p-3"><a class="listdetails" href="">Help & support</a></li>
                <li class="p-3"><a class="listdetails" href="contact_us.php">Contact</a></li>

              </ul>
            </div>
          </div>

        </div>
        <div class="col-sm-6 p-5 text-center">
          <h3 class="mt-5" style="color: white;">Social Media</h3>
          <div class="mt-2">
            <i class="bi bi-facebook p-2"></i>
            <i class="bi bi-twitter p-2"></i>
            <i class="bi bi-instagram p-2"></i>
          </div>
        </div>

      </div>
    </div>


  </div>
</div>    </section>

    <script src="assets/vendor/aos/aos.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
    <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
    <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
    <script src="assets/vendor/php-email-form/validate.js"></script>
    <script src="assets/js/main.js"></script>
</body>

</html>