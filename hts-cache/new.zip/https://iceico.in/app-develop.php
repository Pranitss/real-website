<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>ICEICO - Accelerated Quality</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Favicons -->
    <!-- <link href="assets/img/favicon.png" rel="icon"> -->
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- jquery cdn -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.3/jquery.min.js" integrity="sha512-STof4xm1wgkfm7heWqFJVn58Hm3EtS31XFaagaa8VMReCXAkQnJZ+jEy8PCC/iT18dFy95WcExNHFTqLyp72eQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <!-- Vendor CSS Files -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href="assets/vendor/aos/aos.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
    <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

    <!--Main CSS File -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/img_slider.css" rel="stylesheet">


    <style>
        .position-absolute {
            position: absolute;
            bottom: 20px;
            left: 35px;
        }

        .container-1 {
            height: 350px;
            margin: auto;
            position: relative;
            width: 90%;
            place-items: center;
            overflow: hidden;
        }

        .slide-container {
            display: flex;
        }

        .slide-img {
            height: 250px;
            width: 325px;
            display: flex;
            align-items: center;
            padding: 15px;
            perspective: 100px;
        }


        .img-s {
            aspect-ratio: 3/2 !important;
            width: 50%;
            /* height: 30%; */
            object-fit: contain;
        }
    </style>

</head>

<body id="aboutbg">

    <!-- ======= Header ======= -->
    <!-- ======= Header ======= -->

<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
    <div class="container-xl">
        <a class="navbar-brand" href="index.php"><img src="assets/img/Group 1.png" alt="logo" class="img-fluid" style="max-width: 100%; width: 70px" /></a>
        <button class="navbar-toggler collapsed" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon" style="width: 5vw"></span>
        </button>
        <div class="navbar-collapse collapse" id="navbarNavDropdown" style="">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <div class="separator" style="
                        height: 1px;
                        border-top: 1px solid rgba(255, 255, 255, 0.55);
                        margin-left: 20px;
                        margin-right: 20px;
                        width: 150px;
                        flex: 1;
                        margin-top: 20px;
            "></div>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="industries.php" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Industries
                    </a>
                    <ul class="text-light dropdown-menu p-3 pt-3 pb-3" aria-labelledby="navbarDropdownMenuLink">
                        <li>
                            <a class="link-light dropdown-item" href="gaming.php">Gaming &amp; Entertainment</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="life-sciences.php">Life sciences &amp;
                                healthcare</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="media.php">Media &amp; publishing</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="non-profits.php">Non-profits and education</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="retails.php">Retail &amp; cpg</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="smart-buildings.php">Smart buildings</a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Services
                    </a>
                    <ul class="container container-sm text-light dropdown-menu overflow dropdown-menu-scrollable" aria-labelledby="navbarDropdownMenuLink" style="width: 100vw; left: -400px; margin: 0px -20px">
                        <li class="p-2 pb-5 pt-5 row">
                            <section class="col-lg-3 col-md-12 col-sm-12 d-lg-block d-md-none">
                                <ul class="mylist">
                                    <li>
                                        <div class="menu-title fs-3">Services</div>
                                    </li>
                                    <li>
                                        <p class="">
                                            Accelerate your vision with technologies that are both
                                            agile and cutting edge.
                                        </p>
                                    </li>
                                    <li class="position-absolute top-50">
                                        <a href="all_services.php" class="link-light p-5 pt-2 pb-2 bg-success link-hover d-none d-lg-block" style="border-radius: 50px">view all services</a>
                                    </li>
                                </ul>
                            </section>
                            <section class="col-lg-3 col-md-12 col-sm-12">
                                <ul class="mylist">
                                    <li>
                                        <a href="accelerated-quality.php" class="link-light dropdown-item">
                                            <h6>accelerated quality &amp; test-engineering</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="agile.php" class="link-light dropdown-item">
                                            <h6>agile</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="api-mgmt.php" class="link-light dropdown-item">
                                            <h6>api management</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="app-develop.php" class="link-light dropdown-item">
                                            <h6>application development</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="app-manage.php" class="link-light dropdown-item">
                                            <h6>application managed services</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="ai-da.php" class="link-light dropdown-item">
                                            <h6>artificial intelligence, data &amp; analytics</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="blockchain.php" class="link-light dropdown-item">
                                            <h6>blockchain</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="cloud.php" class="link-light dropdown-item">
                                            <h6>cloud</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="crm.php" class="link-light dropdown-item">
                                            <h6>crm</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="customer-communications.php" class="link-light dropdown-item">
                                            <h6>customer communications</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="design.php" class="link-light dropdown-item">
                                            <h6>design</h6>
                                        </a>
                                    </li>
                                </ul>
                            </section>
                            <section class="col-lg-3 col-md-12 col-sm-12">
                                <ul class="mylist">
                                    <li>
                                        <a href="devops.php" class="link-light dropdown-item">
                                            <h6>devops</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="digital-commerce.php" class="link-light dropdown-item">
                                            <h6>digital commerce</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="digital-experiences.php" class="link-light dropdown-item">
                                            <h6>digital experiences</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="digital-ventures.php" class="link-light dropdown-item">
                                            <h6>digital ventures</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="ecm-&amp;-portals.php" class="link-light dropdown-item">
                                            <h6>ecm &amp; portals</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="embedded.php" class="link-light dropdown-item">
                                            <h6>embedded systems</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="enterprising consu.php" class="link-light dropdown-item">
                                            <h6>enterprise architecture consulting</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="erp.php" class="link-light dropdown-item">
                                            <h6>erp</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="identify man.php" class="link-light dropdown-item">
                                            <h6>identity and access management</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="inovation.php" class="link-light dropdown-item">
                                            <h6>innovation</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="internet of things.php" class="link-light dropdown-item">
                                            <h6>internet of things</h6>
                                        </a>
                                    </li>
                                </ul>
                            </section>
                            <section class="col-lg-3 col-md-12 col-sm-12">
                                <ul class="mylist">
                                    <li>
                                        <a href="low code.php" class="link-light dropdown-item">
                                            <h6>low code</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="mainfraim &amp; legacy.php" class="link-light dropdown-item">
                                            <h6>mainframe &amp; legacy</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="mobility solu.php" class="link-light dropdown-item">
                                            <h6>mobility solutions</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="process consulting.php" class="link-light dropdown-item">
                                            <h6>process consulting</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="product engeeniring.php" class="link-light dropdown-item">
                                            <h6>product engineering</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="resilience_engineering.php" class="link-light dropdown-item">
                                            <h6>resilience engineering</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="sap_services.php" class="link-light dropdown-item">
                                            <h6>sap services</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="security.php" class="link-light dropdown-item">
                                            <h6>security</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="technical_communication.php" class="link-light dropdown-item">
                                            <h6>technical communication</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="trainings.php" class="link-light dropdown-item">
                                            <h6>trainings</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="transformation.php" class="link-light dropdown-item">
                                            <h6>transformation and modernization</h6>
                                        </a>
                                    </li>
                                </ul>
                            </section>
                        </li>
                    </ul>
                </li>
                <li class="nav-item dropdown overflow">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Insights
                    </a>
                    <ul class="container container-sm text-light dropdown-menu dropdown-menu-scrollable" aria-labelledby="navbarDropdownMenuLink" style="width: 100vw; left: -490px; margin: 0 -20px">
                        <li class="container container-sm insight p-2 pb-4 pt-4" style="width: 100vw; left: -825px">
                            <div class="headings">
                                <div class="row text-center p-1 d-lg-flex d-md-none">
                                    <div class="col-md-6 fs-2">Thinking Breakthroughs</div>
                                    <div class="col-md-6">
                                        <a href="#" class="link-light p-5 pt-2 pb-2 bg-success link-hover d-none d-lg-inline-block">
                                            Explore our best ideas</a>
                                    </div>
                                </div>
                                <hr />
                                <div class="row p-5 pt-4 pb-4">
                                    <section class="col-lg-4 col-md-12 col-sm-12">
                                        <ul class="mylist">
                                            <li>
                                                <div class="fs-6 p-3 pt-0 pb-0 text-success">Filter by Goal</div>
                                            </li>
                                            <li>
                                                <a href="modernize.php" class="link-light dropdown-item fs-3">Modernize</a>
                                            </li>
                                            <li>
                                                <a href="optimize.php" class="link-light dropdown-item fs-3">Optimize</a>
                                            </li>
                                            <li>
                                                <a href="innovate.php" class="link-light dropdown-item fs-3">Innovate</a>
                                            </li>
                                            <li>
                                                <a href="disrupt.php" class="link-light dropdown-item fs-3">Disrupt</a>
                                            </li>
                                            <li>
                                                <a href="transform.php" class="link-light dropdown-item fs-3">Transform</a>
                                            </li>
                                        </ul>
                                    </section>
                                    <section class="col-lg-4 col-md-12 col-sm-12 border-right" style="border-left: 1px solid #999">
                                        <ul class="mylist">
                                            <li>
                                                <div class="fs-6 p-3 pt-0 pb-0 text-success">
                                                    Trending technologies
                                                </div>
                                            </li>
                                            <li>
                                                <a href="ai_ml.php" class="link-light dropdown-item fs-5">AI and ML</a>
                                            </li>
                                            <li>
                                                <a href="data_science.php" class="link-light dropdown-item fs-5">Data Science</a>
                                            </li>
                                            <li>
                                                <a href="iot.php" class="link-light dropdown-item fs-5">IoT</a>
                                            </li>
                                            <li>
                                                <a href="low_code_ins.php" class="link-light dropdown-item fs-5">Low Code</a>
                                            </li>
                                            <li>
                                                <a href="api_ins.php" class="link-light dropdown-item fs-5">API-Management</a>
                                            </li>
                                            <li>
                                                <a href="aqt.php" class="link-light dropdown-item fs-5">AQT</a>
                                            </li>
                                            <li>
                                                <a href="cloud_ins.php" class="link-light dropdown-item fs-5">Cloud</a>
                                            </li>
                                            <li>
                                                <a href="agile_ins.php" class="link-light dropdown-item fs-5">Agile</a>
                                            </li>
                                            <li>
                                                <a href="devops_ins.php" class="link-light dropdown-item fs-5">DevOps</a>
                                            </li>
                                            <li>
                                                <a href="chaos_engineering.php" class="link-light dropdown-item fs-5">Chaos Engineering</a>
                                            </li>
                                            <li>
                                                <a href="data_mesh.php" class="link-light dropdown-item fs-5">Data Mesh</a>
                                            </li>
                                        </ul>
                                    </section>
                                    <section class="col-lg-4 col-md-12 col-sm-12 border-right" style="border-left: 1px solid #999">
                                        <ul class="mylist">
                                            <li>
                                                <div class="fs-6 p-3 pt-0 pb-0 text-success">Industry</div>
                                            </li>
                                            <li>
                                                <a href="automotive_ins.php" class="link-light dropdown-item">Automotive</a>
                                            </li>
                                            <li>
                                                <a href="banking_financial_ins.php" class="link-light dropdown-item">Banking and Financial
                                                    Services</a>
                                            </li>
                                            <li>
                                                <a href="insurance_ins.php" class="link-light dropdown-item">Insurance</a>
                                            </li>
                                            <li>
                                                <a href="energy_ins.php" class="link-light dropdown-item">Energy and Utilities</a>
                                            </li>
                                            <li>
                                                <a href="gaming_ins.php" class="link-light dropdown-item">Gaming and
                                                    Entertainment</a>
                                            </li>
                                            <li>
                                                <a href="isv_ins.php" class="link-light dropdown-item">ISV</a>
                                            </li>
                                            <li>
                                                <a href="life_science_ins.php" class="link-light dropdown-item">Life-sciences and
                                                    Healthcare</a>
                                            </li>
                                            <li>
                                                <a href="media_ins.php" class="link-light dropdown-item">Media and Publishing</a>
                                            </li>
                                            <li>
                                                <a href="retail_cpg_ins.php" class="link-light dropdown-item">Retail and CPG</a>
                                            </li>
                                            <li>
                                                <a href="telecommunications_ins.php" class="link-light dropdown-item">Telecommunications</a>
                                            </li>
                                            <li>
                                                <a href="travel_ins.php" class="link-light dropdown-item">Travel &amp; Logistics</a>
                                            </li>
                                            <li>
                                                <a href="industry_ins.php" class="link-light dropdown-item">Industry and Automation</a>
                                            </li>
                                            <li>
                                                <a href="non_profits_ins.php" class="link-light dropdown-item">Non-profits and
                                                    Education</a>
                                            </li>
                                            <li>
                                                <a href="public_sector_ins.php" class="link-light dropdown-item">Public Sector</a>
                                            </li>
                                        </ul>
                                    </section>
                                </div>
                            </div>
                        </li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="maintenance.php" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-expanded="false">
                        Maintenance
                    </a>
                </li>
            </ul>

            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        About us
                    </a>
                    <div class="text-light dropdown-menu p-3 pt-3 pb-3" aria-labelledby="navbarDropdownMenuLink">
                        <a class="link-light dropdown-item" href="canyoutrustus.php">Can you trust us
                        </a>

                        <a class="link-light dropdown-item" href="reasontojoin.php">10 reason to join
                        </a>
                    </div>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Careers
                    </a>
                    <ul class="text-light dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                        <li>
                            <a class="link-light dropdown-item" href="action.php">Action</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="another_action.php">Another action</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="else_here.php">Something else here</a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="contact_us.php" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-expanded="false">
                        Contact us
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- End Header -->    <!-- End Header -->
    <section style="background-color: #13294B;padding: 100px 10px;">
        <div class="container builddetails">
            <div class=" py-lg-0 p-5 order-2 order-lg-1 mt-3" data-aos="fade-right">
                <a id=" " class="fs-3 text-white" href=""> Services </a> &nbsp;<a href="" class="text-success fs-3 text-capitalize">
                    application development & management </a>
                <h1 class="text-start"> Be technically agile and evolve</h1>
                <a href="contact_us.php" class="btn-get-started">Connect with us</a>
            </div>
        </div>
    </section>

    <section class="bg-white py-5">
        <div class="container pt-5" style="text-align:justify;">
            <p class="fs-5">Technology keeps evolving, and so do we. We are early adopters of technology and this, along with our agility, protects our customers from early obsolescence of the solutions we deliver and manage. Agile application development and management are at the center of ICEICO’s DNA. We have dedicated architecture groups for Java, Microsoft, and Open Source (PHP, ROR) platforms. ICEICO has vast experience in designing and building robust, scalable, and extensible applications for web, mobile, desktop, and cloud environments. Our competence in application software extends into managing and supporting applications in the most efficient and technically competent way possible.</p>
        </div>
    </section>

    <!-- What we do -->
    <section class="bg-white py-5">
        <div class="container">
            <h2 class=" pb-5 text-center text-capitalize"> what we do</h2>
            <div class="row justify-content-center">
                <div class="col-lg-4 col-12 p-4">
                    <h4 class="p-0 pt-0">Application Development</h4>
                    <img src="assets/img/title-underline.jpg" alt="">
                    <p class="text-secondary p-0 pt-4 pb-4">Provide the full gamut of services from application feasibility analysis to package based implementations. We minimize risk, maximize benefits, and deliver projects with impeccable quality, on-time and within budget.</p>
                </div>
                <div class="col-lg-4 col-12 p-4">
                    <h4 class="p-0 pt-0">Application Management</h4>
                    <img src="assets/img/title-underline.jpg" alt="">
                    <p class="text-secondary p-0 pt-4 pb-4">Provide ITSM consulting & implementation, portfolio rationalization, and operations services - to effectively consolidate and transform business operations. Click here for details.</p>
                </div>
                <div class="col-lg-4 col-12 p-4">
                    <h4 class="p-0 pt-0">Application Services Assessment & Consulting</h4>
                    <img src="assets/img/title-underline.jpg" alt="">
                    <p class="text-secondary p-0 pt-4 pb-4">Assess current application-related services provided to the business and evaluate the potential to re-orient them according to business goals.</p>
                </div>
            </div>
        </div>
    </section>
    <!--  End what we do -->

    <!-- Image Slider -->
    <div class="bg-white py-5 row-depth-1 row-fluid-wrapper row-number-7">
        <div class="row-fluid">
            <div class="span12 widget-span widget-type-custom_widget" data-widget-type="custom_widget" data-x="0" data-w="12">
                <div id="hs_cos_wrapper_module_159558284117034" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_module" data-hs-cos-general-type="widget" data-hs-cos-type="module">
                    <div class="featured-story-wrapper">
                        <div class="page-center page-pad">
                            <div class="row-fluid">
                                <div class="span12 section-center">
                                    <div class="featured-story-heading mb-20">
                                        <h3 class="fs-2 mb-3 ps-5 text-capitalize pt-4">
                                            featured success story

                                            <span class="featured-story-list-view-all-wrapper pe-4">
                                                <a href="https://www.ICEICO.com/en/success-stories" class="featured-story-list-view-all brand-08">view all</a>
                                            </span>
                                        </h3>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="featured-story-list mb-30">
                            <section class="slider-outer">
                                <div class="row-fluid">
                                    <div class="span1">
                                        <div class="carousel__progress hide-mobile">
                                            <span class="carousel__progress-background">
                                                <span class="carousel__progress-bar"></span>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="span11 content-section">
                                        <div id="StorySliderID" class="storyslider regular slider">
                                            <div class="story-slider-wrapper" data-cursor="cursor" data-cursor-type="drag">
                                                <div class="story-list active-slide newlogoanimate" data-slide-index="0">
                                                    <div class="left-section span5">
                                                        <div class="drag-overlay hide-mobile"></div>
                                                        <div class="client-logo hide-mobile">
                                                            <img src="assets/img/download (4).png" alt="" style="max-width: 1000%; height: auto">
                                                        </div>
                                                        <div class="client-logo hide-desktop">

                                                        </div>
                                                        <div class="story-content">
                                                            <h4>
                                                                <div id="hs_cos_wrapper_module_159558284117034_" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_inline_text" data-hs-cos-general-type="widget" data-hs-cos-type="inline_text" data-hs-cos-field="story_title">
                                                                    Adapting to today's digital age
                                                                </div>
                                                            </h4>
                                                            <div class="description brand-04-neg-20 small-text">
                                                                <div id="hs_cos_wrapper_module_159558284117034_" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_inline_rich_text" data-hs-cos-general-type="widget" data-hs-cos-type="inline_rich_text" data-hs-cos-field="description">
                                                                    A digital learning platform to gain a competitive advantage.
                                                                </div>
                                                            </div>
                                                            <h6 class="bottom-text brand-04-neg-20">
                                                                <div id="hs_cos_wrapper_module_159558284117034_" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_inline_rich_text" data-hs-cos-general-type="widget" data-hs-cos-type="inline_rich_text" data-hs-cos-field="bottom_text"></div>
                                                            </h6>

                                                            <a href="#" target="_blank" class="page-btn page-btn03 btn btn-outline-secondary text-capitalize">read success
                                                                story</a>
                                                        </div>
                                                    </div>
                                                    <div class="right-section span7">
                                                        <div class="right-section-content">
                                                            <div class="right-section--image">
                                                                <img src="assets/img/Schrack_Technik_Tile.jpg" loading="lazy" class="right-section--imageSrc">

                                                                <div class="mobile-overlay"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="story-list" data-slide-index="1">
                                                    <div class="left-section span5">
                                                        <div class="drag-overlay hide-mobile"></div>
                                                        <div class="client-logo hide-mobile">
                                                            <img src="assets/img/obf.png" alt="" width="100%" style="max-width: 135px; max-height: 55px">
                                                        </div>
                                                        <div class="client-logo hide-desktop">

                                                        </div>
                                                        <div class="story-content">
                                                            <h4>
                                                                <div id="hs_cos_wrapper_module_159558284117034_" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_inline_text" data-hs-cos-general-type="widget" data-hs-cos-type="inline_text" data-hs-cos-field="story_title">
                                                                    Nurturing the community with digital avenues
                                                                </div>
                                                            </h4>
                                                            <div class="description brand-04-neg-20 small-text">
                                                                <div id="hs_cos_wrapper_module_159558284117034_" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_inline_rich_text" data-hs-cos-general-type="widget" data-hs-cos-type="inline_rich_text" data-hs-cos-field="description">
                                                                    <p>
                                                                        A state-of-the-art, unified platform to streamline communication and administration among the hunters, hunting area specialist, and customers.
                                                                    </p>
                                                                </div>
                                                            </div>
                                                            <h6 class="bottom-text brand-04-neg-20">
                                                                <div id="hs_cos_wrapper_module_159558284117034_" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_inline_rich_text" data-hs-cos-general-type="widget" data-hs-cos-type="inline_rich_text" data-hs-cos-field="bottom_text"></div>
                                                            </h6>

                                                            <a href="#" class="btn btn-outline-secondary page-btn page-btn03 text-capitalize">read
                                                                success story</a>
                                                        </div>
                                                    </div>
                                                    <div class="right-section span7">
                                                        <div class="right-section-content">
                                                            <div class="right-section--image">
                                                                <img src="assets/img/Nagarro builds unified platform to streamline communication and administration.jpg" loading="lazy" class="right-section--imageSrc">

                                                                <div class="mobile-overlay"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="story-list" data-slide-index="2">
                                                    <div class="left-section span5">
                                                        <div class="drag-overlay hide-mobile"></div>
                                                        <div class="client-logo hide-mobile">
                                                            <img src="assets/img/Hoerbiger_Holding_Logo.png" alt="" style="max-width: 100%; height: auto">
                                                        </div>
                                                        <div class="client-logo hide-desktop">

                                                        </div>
                                                        <div class="story-content">
                                                            <h4>
                                                                <div id="hs_cos_wrapper_module_159558284117034_" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_inline_text" data-hs-cos-general-type="widget" data-hs-cos-type="inline_text" data-hs-cos-field="story_title">
                                                                    One-stop shop for improved service management
                                                                </div>
                                                            </h4>
                                                            <div class="description brand-04-neg-20 small-text">
                                                                <div id="hs_cos_wrapper_module_159558284117034_" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_inline_rich_text" data-hs-cos-general-type="widget" data-hs-cos-type="inline_rich_text" data-hs-cos-field="description">
                                                                    A solution to bring customers and employees closer throughout the value chain, and improving transparency,and ensuring ease of customer service operations.
                                                                </div>
                                                            </div>
                                                            <h6 class="bottom-text brand-04-neg-20">
                                                                <div id="hs_cos_wrapper_module_159558284117034_" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_inline_rich_text" data-hs-cos-general-type="widget" data-hs-cos-type="inline_rich_text" data-hs-cos-field="bottom_text"></div>
                                                            </h6>

                                                            <a href="#" target="_blank" class="page-btn page-btn03 btn btn-outline-secondary text-capitalize">read success
                                                                story</a>
                                                        </div>
                                                    </div>
                                                    <div class="right-section span7">
                                                        <div class="right-section-content">
                                                            <div class="right-section--image">
                                                                <img src="assets/img/One-stop solution for service management.jpg" loading="lazy" class="right-section--imageSrc">

                                                                <div class="mobile-overlay"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="story-list" data-slide-index="3">
                                                    <div class="left-section span5">
                                                        <div class="drag-overlay hide-mobile"></div>
                                                        <div class="client-logo hide-mobile">

                                                        </div>
                                                        <div class="client-logo hide-desktop">

                                                        </div>
                                                        <div class="story-content">
                                                            <h4>
                                                                <div id="hs_cos_wrapper_module_159558284117034_" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_inline_text" data-hs-cos-general-type="widget" data-hs-cos-type="inline_text" data-hs-cos-field="story_title">
                                                                    Delivering high-touch through high-tech
                                                                </div>
                                                            </h4>
                                                            <div class="description brand-04-neg-20 small-text">
                                                                <div id="hs_cos_wrapper_module_159558284117034_" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_inline_rich_text" data-hs-cos-general-type="widget" data-hs-cos-type="inline_rich_text" data-hs-cos-field="description">
                                                                    High-end website makeover for a luxury cosmetics gaint. Greater global reach and significant increase in website visitors.
                                                                </div>
                                                            </div>
                                                            <h6 class="bottom-text brand-04-neg-20">
                                                                <div id="hs_cos_wrapper_module_159558284117034_" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_inline_rich_text" data-hs-cos-general-type="widget" data-hs-cos-type="inline_rich_text" data-hs-cos-field="bottom_text"></div>
                                                            </h6>

                                                            <a href="#" target="_blank" class="page-btn page-btn03 btn btn-outline-secondary text-capitalize">read success
                                                                story</a>
                                                        </div>
                                                    </div>
                                                    <div class="right-section span7">
                                                        <div class="right-section-content">
                                                            <div class="right-section--image">
                                                                <img src="assets/img/retail giant case study_nagarro.jpg" loading="lazy" class="right-section--imageSrc">

                                                                <div class="mobile-overlay"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <!-- Pagination section start -->
                                                <ul class="story--slider-pagination-section">
                                                    <li class="slider-numbers">
                                                        <span class="xs-pagination-number">1</span>
                                                        <span class="total-number">4</span>
                                                    </li>
                                                    <li class="slide-arrow slider-pagination-left" id="storyprevSlideControl">
                                                        <svg width="36" height="32" viewBox="0 0 36 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M34 2C28.5 8.00001 6 16 6 16C6 16 29 25.5 34 30" stroke="#13294B" stroke-width="4" stroke-linecap="round"></path>
                                                        </svg>
                                                    </li>
                                                    <li class="slide-arrow slider-pagination-right" id="storynextSlideControl">
                                                        <svg width="36" height="32" viewBox="0 0 36 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M2 2C7.5 8.00001 30 16 30 16C30 16 7 25.5 2 30" stroke="#13294B" stroke-width="4" stroke-linecap="round"></path>
                                                        </svg>
                                                    </li>
                                                </ul>
                                                <!--  Pagination section end -->
                                                <!-- Pagination section start -->
                                                <ul class="story--slider-pagination-section" style="overflow: hidden">
                                                    <li data-pagination-index="0" class="slide-pagination-block">
                                                        <div class="slide-pagination-number">1</div>
                                                        <div class="slide-pagination-text"></div>
                                                    </li>

                                                    <li data-pagination-index="1" class="slide-pagination-block active-slide-pagination-block">
                                                        <div class="slide-pagination-number">2</div>
                                                        <div class="slide-pagination-text"></div>
                                                    </li>

                                                    <li data-pagination-index="2" class="slide-pagination-block">
                                                        <div class="slide-pagination-number">3</div>
                                                        <div class="slide-pagination-text"></div>
                                                    </li>
                                                    <li data-pagination-index="3" class="slide-pagination-block">
                                                        <div class="slide-pagination-number">4</div>
                                                        <div class="slide-pagination-text"></div>
                                                    </li>
                                                </ul>
                                                <!--  Pagination section end -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <!--end widget-span -->
        </div>
        <!--end row-->
    </div>

    <section style="background: #205463; color: #f3f3f3">
        <div class="mx-0 row" style="--bs-gutter-x: -0.5rem;">
            <div class="col-md-5 col-lg-5 col-sm-12">
                <img src="assets/img/infrastruture-cities-rail-systems_SIEMENS.jpg" alt="img" style="max-width: 100%" class="h-100">
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 px-4">
                <div class="my-4">
                    <img src="assets/img/quote-start.jpg " alt="" class="">
                    <p class="fs-4 px-5">
                        Our expectations were met! Successful teamwork between the technical department, purchase department, and the suppliers leads to service advantages and saves expenditure.
                    </p>
                    <img src="assets/img/quote-end.jpg " alt="" class="float-end">
                </div>
                <div class="mx-5 my-5 pt-5">
                    <img src="assets/img/SIEMENS_160-White.png" alt="">
                </div>
            </div>
        </div>
    </section>

    <!-- our partner -->
    <section class=" bg-white py-5">
        <h2 class="pb-5 text-center text-uppercase">Our Partners</h2>
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-12 col-lg-3 text-center">
                    <img src="assets/img/Microsoft_logo_(2012) 1.svg" class="img-s" alt="">
                    <p class="fs-5 fst-italic">As a Microsoft Gold Certified Partner for Application Development as well as for Collaboration and Content, we provide a comprehensive suite of services around Microsoft technologies.</p>
                </div>
                <div class="col-md-3 col-sm-12 col-lg-3 text-center">
                    <img src="assets/img/google-logo-png-hd-11.png" class="img-s" alt="">
                    <p class="fs-5 fst-italic">As a Google Enterprise Partner, our expertise spans the complete range of Google Enterprise applications.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- featured insights -->
    <section class="container-fluid bg-white py-3">
        <div class="container">
            <div class="featured1">
                <h2 class="text-center pb-5 text-capitalize">featured insights</h2>
                <div class="row justify-content-center">
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Knowledge Management_B.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Knowledge management during service transition and beyond
                                </p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Feb 12, 2020</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Continuous-Everything_tile.png" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Continuous Everything in mobile app development using microsoft technologies</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Oct 05, 2018</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/express_delivery_tile.png" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Express Delivery: MVP for last mile connectivity in 7 days</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Jun 15, 2017</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/DS_The_Dice_img_tile.png" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-1 p-md-3 p-sm-3">Changing image of offshoring: The dice has been rolled</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Dec 29, 2016</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Cropped_White-paper-Microsoft-ALM-tools-Landing-page-2.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-1 p-md-3 p-sm-3">A comparative analysis of two microsoft ALM tools</p>
                                <span class="position-absolute"><a href="" class="text-success">White Paper</a></span>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- why choose us -->

    <!-- What can we you archieve -->
    <section class="pt-5 pb-5" style="background:#13294b;">
        <div class="container">
            <div id="lets-go" style="padding: 100px 0;">
                <div class="row">
                    <div class="col-lg-6 col-md-12 col-sm-12 text-center  pb-5">
                        <h2 class="text-light pb-3">What can we help you <br>achieve?</h2>
                        <a href="" class="link-light border p-5 pt-2 pb-2" style="border-radius: 50px;"> Let's get
                            to work</a>
                    </div>
                    <div class="col-lg-6 col-md-12 col-sm-12 text-center  pb-5">
                        <h2 class="text-light pb-3">Where will your career take<br> you?</h2>
                        <a href="" class="link-light border p-5 pt-2 pb-2" style="border-radius: 50px;">Come and
                            find out</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End What can we you archieve -->



    <!-- //user Review  -->
    <section class="py-3">
  <div class="container  responsive-container text-center">
    <h2 class="fs-2 pt-2 pt-5 text-center text-light">Our Community With User Review</h2>
    <div class="m-md-5 py-5 py-lg-0 py-md-0 row user-review-background">

      <div class="col-12 col-lg-4 col-sm-12 mt-0 mt-lg-5 mt-md-5 ps-sm-5 pt-sm-5"><img src="assets/img/Group 1.png" class="ellipseimg pt-0" alt="" width="150" height="100"></div>
      <div class="col-12 col-lg-5 col-sm-12 offset-lg-0 p-lg-5 text-center user-prghp" style="height: 240px;">
        <p>The system has produced a significant competitive advantage in the industry thanks to ICEICO Technologies well-thought opinions.

They shouldered the burden of constantly updating a project management tool with a high level of detail and were committed to producing the best possible solution. <br>-Amol Ramteke, Business Owner of Carbonblack.education</p>

      </div>

    </div>
  </div>

</section>



    <!-- footer section  start-->
    

<div class="mt-4">
  <div class="footer footer-bg">
    <div class="container ">
      <div class="row">
        <div class="col-sm-6 p-md-5 p-sm-2 text-center">
          <h3 style="color:white;">Contact Us</h3>
          <p style="color:#0fc88a;">ICEICO TECHNOLOGIES PVT. LTD. <br> Plot No. 91, Ganesh Nagar, Azamshah Layout, Nandanwan, Nagpur, Maharashtra 440009 </p>
         
        </div>


        <div class="col-sm-6 p-5 text-center">
          <div>
            <h3 style="color:white ;">NEWSLETTER</h3>
          </div>
          <div>
            <!--<span><input type="Email" class="emailform " placeholder="Email Address"><button class="formbutton">Submit</button></span>-->
            <div class="input-group mx-auto w-50">
                <input type="email" class="form-control emailform bg-transparent text-white" placeholder="Email Address" aria-label="Input group example" aria-describedby="btnGroupAddon" >
                <button class="input-group-text formbutton px-2" id="btnGroupAddon">Submit</button>    
            </div>

          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-sm-6 p-md-5  ">
          <div class="row">
            <div class="col-sm-6 col-12 p-3 text-center">
              <ul style="list-style-type:none;">
                <caption><span class="cptndetail"><b>About Us</b></span></caption>
                <li class="p-3"><a class="listdetails" href="">Whitepaper</a></li>
                <li class="p-3"><a class="listdetails" href="blog.php">Blog</a></li>
                <li class="p-3"><a class="listdetails" href="">Activity</a></li>

              </ul>
            </div>


            <div class="col-sm-6 col-12 p-md-3 text-center">
              <ul style="list-style-type:none;">
                <caption><span class="cptndetail"><b>support</b></span></caption>
                <li class="p-3"><a class="listdetails" href="">Author Profile</a></li>
                <li class="p-3"><a class="listdetails" href="">Community</a></li>
                <li class="p-3"><a class="listdetails" href="">Help & support</a></li>
                <li class="p-3"><a class="listdetails" href="contact_us.php">Contact</a></li>

              </ul>
            </div>
          </div>

        </div>
        <div class="col-sm-6 p-5 text-center">
          <h3 class="mt-5" style="color: white;">Social Media</h3>
          <div class="mt-2">
            <i class="bi bi-facebook p-2"></i>
            <i class="bi bi-twitter p-2"></i>
            <i class="bi bi-instagram p-2"></i>
          </div>
        </div>

      </div>
    </div>


  </div>
</div>    </section>

    <script src="assets/vendor/aos/aos.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
    <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
    <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
    <script src="assets/vendor/php-email-form/validate.js"></script>
    <script src="assets/js/main.js"></script>
    <script src="assets/js/img_slider.js"></script>

</body>

</html>