<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>ICEICO - Optimize</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Favicons -->
    <!-- <link href="assets/img/favicon.png" rel="icon"> -->
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- jquery cdn -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.3/jquery.min.js" integrity="sha512-STof4xm1wgkfm7heWqFJVn58Hm3EtS31XFaagaa8VMReCXAkQnJZ+jEy8PCC/iT18dFy95WcExNHFTqLyp72eQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <!-- Vendor CSS Files -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <link href="assets/vendor/aos/aos.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
    <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

    <!--Main CSS File -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/slide_animation.css" rel="stylesheet">

    <style>
        .position-absolute {
            position: absolute;
            bottom: 20px;
            left: 35px;
        }

        .img_media {
            position: absolute;
            left: 384px;
            right: 84px;
            z-index: 9;
            height: 400px;
            max-width: 900px;
            width: 100%;
        }

        .backPos {
            padding: 20px 108px;
            position: relative;
        }

        .backImg {
            background: url(assets/img/AdobeStock_568279856-min-AG.jpg) center no-repeat;
            background-size: cover;
            height: 450px;
            position: relative;
            bottom: 250px;
        }

        .pad {
            padding: 147px;
        }

        @media (max-width: 755px) {
            .backImg {
                bottom: 160px !important;
                width: 320px;
                height: 300px;
                right: 55px;
                background-size: 100% 75%;
            }

            .pad {
                padding: 20px !important;
                align-self: center;
            }
        }

        .container-1 {
            height: 100px !important;
        }

        #myRow>div {
            display: none;
        }
        #myRow {
            justify-content: center!important;
        }
    </style>

</head>

<body id="aboutbg">

    <!-- ======= Header ======= -->
    <!-- ======= Header ======= -->

<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
    <div class="container-xl">
        <a class="navbar-brand" href="index.php"><img src="assets/img/Group 1.png" alt="logo" class="img-fluid" style="max-width: 100%; width: 70px" /></a>
        <button class="navbar-toggler collapsed" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon" style="width: 5vw"></span>
        </button>
        <div class="navbar-collapse collapse" id="navbarNavDropdown" style="">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <div class="separator" style="
                        height: 1px;
                        border-top: 1px solid rgba(255, 255, 255, 0.55);
                        margin-left: 20px;
                        margin-right: 20px;
                        width: 150px;
                        flex: 1;
                        margin-top: 20px;
            "></div>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="industries.php" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Industries
                    </a>
                    <ul class="text-light dropdown-menu p-3 pt-3 pb-3" aria-labelledby="navbarDropdownMenuLink">
                        <li>
                            <a class="link-light dropdown-item" href="gaming.php">Gaming &amp; Entertainment</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="life-sciences.php">Life sciences &amp;
                                healthcare</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="media.php">Media &amp; publishing</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="non-profits.php">Non-profits and education</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="retails.php">Retail &amp; cpg</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="smart-buildings.php">Smart buildings</a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Services
                    </a>
                    <ul class="container container-sm text-light dropdown-menu overflow dropdown-menu-scrollable" aria-labelledby="navbarDropdownMenuLink" style="width: 100vw; left: -400px; margin: 0px -20px">
                        <li class="p-2 pb-5 pt-5 row">
                            <section class="col-lg-3 col-md-12 col-sm-12 d-lg-block d-md-none">
                                <ul class="mylist">
                                    <li>
                                        <div class="menu-title fs-3">Services</div>
                                    </li>
                                    <li>
                                        <p class="">
                                            Accelerate your vision with technologies that are both
                                            agile and cutting edge.
                                        </p>
                                    </li>
                                    <li class="position-absolute top-50">
                                        <a href="all_services.php" class="link-light p-5 pt-2 pb-2 bg-success link-hover d-none d-lg-block" style="border-radius: 50px">view all services</a>
                                    </li>
                                </ul>
                            </section>
                            <section class="col-lg-3 col-md-12 col-sm-12">
                                <ul class="mylist">
                                    <li>
                                        <a href="accelerated-quality.php" class="link-light dropdown-item">
                                            <h6>accelerated quality &amp; test-engineering</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="agile.php" class="link-light dropdown-item">
                                            <h6>agile</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="api-mgmt.php" class="link-light dropdown-item">
                                            <h6>api management</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="app-develop.php" class="link-light dropdown-item">
                                            <h6>application development</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="app-manage.php" class="link-light dropdown-item">
                                            <h6>application managed services</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="ai-da.php" class="link-light dropdown-item">
                                            <h6>artificial intelligence, data &amp; analytics</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="blockchain.php" class="link-light dropdown-item">
                                            <h6>blockchain</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="cloud.php" class="link-light dropdown-item">
                                            <h6>cloud</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="crm.php" class="link-light dropdown-item">
                                            <h6>crm</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="customer-communications.php" class="link-light dropdown-item">
                                            <h6>customer communications</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="design.php" class="link-light dropdown-item">
                                            <h6>design</h6>
                                        </a>
                                    </li>
                                </ul>
                            </section>
                            <section class="col-lg-3 col-md-12 col-sm-12">
                                <ul class="mylist">
                                    <li>
                                        <a href="devops.php" class="link-light dropdown-item">
                                            <h6>devops</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="digital-commerce.php" class="link-light dropdown-item">
                                            <h6>digital commerce</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="digital-experiences.php" class="link-light dropdown-item">
                                            <h6>digital experiences</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="digital-ventures.php" class="link-light dropdown-item">
                                            <h6>digital ventures</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="ecm-&amp;-portals.php" class="link-light dropdown-item">
                                            <h6>ecm &amp; portals</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="embedded.php" class="link-light dropdown-item">
                                            <h6>embedded systems</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="enterprising consu.php" class="link-light dropdown-item">
                                            <h6>enterprise architecture consulting</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="erp.php" class="link-light dropdown-item">
                                            <h6>erp</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="identify man.php" class="link-light dropdown-item">
                                            <h6>identity and access management</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="inovation.php" class="link-light dropdown-item">
                                            <h6>innovation</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="internet of things.php" class="link-light dropdown-item">
                                            <h6>internet of things</h6>
                                        </a>
                                    </li>
                                </ul>
                            </section>
                            <section class="col-lg-3 col-md-12 col-sm-12">
                                <ul class="mylist">
                                    <li>
                                        <a href="low code.php" class="link-light dropdown-item">
                                            <h6>low code</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="mainfraim &amp; legacy.php" class="link-light dropdown-item">
                                            <h6>mainframe &amp; legacy</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="mobility solu.php" class="link-light dropdown-item">
                                            <h6>mobility solutions</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="process consulting.php" class="link-light dropdown-item">
                                            <h6>process consulting</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="product engeeniring.php" class="link-light dropdown-item">
                                            <h6>product engineering</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="resilience_engineering.php" class="link-light dropdown-item">
                                            <h6>resilience engineering</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="sap_services.php" class="link-light dropdown-item">
                                            <h6>sap services</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="security.php" class="link-light dropdown-item">
                                            <h6>security</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="technical_communication.php" class="link-light dropdown-item">
                                            <h6>technical communication</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="trainings.php" class="link-light dropdown-item">
                                            <h6>trainings</h6>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="transformation.php" class="link-light dropdown-item">
                                            <h6>transformation and modernization</h6>
                                        </a>
                                    </li>
                                </ul>
                            </section>
                        </li>
                    </ul>
                </li>
                <li class="nav-item dropdown overflow">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Insights
                    </a>
                    <ul class="container container-sm text-light dropdown-menu dropdown-menu-scrollable" aria-labelledby="navbarDropdownMenuLink" style="width: 100vw; left: -490px; margin: 0 -20px">
                        <li class="container container-sm insight p-2 pb-4 pt-4" style="width: 100vw; left: -825px">
                            <div class="headings">
                                <div class="row text-center p-1 d-lg-flex d-md-none">
                                    <div class="col-md-6 fs-2">Thinking Breakthroughs</div>
                                    <div class="col-md-6">
                                        <a href="#" class="link-light p-5 pt-2 pb-2 bg-success link-hover d-none d-lg-inline-block">
                                            Explore our best ideas</a>
                                    </div>
                                </div>
                                <hr />
                                <div class="row p-5 pt-4 pb-4">
                                    <section class="col-lg-4 col-md-12 col-sm-12">
                                        <ul class="mylist">
                                            <li>
                                                <div class="fs-6 p-3 pt-0 pb-0 text-success">Filter by Goal</div>
                                            </li>
                                            <li>
                                                <a href="modernize.php" class="link-light dropdown-item fs-3">Modernize</a>
                                            </li>
                                            <li>
                                                <a href="optimize.php" class="link-light dropdown-item fs-3">Optimize</a>
                                            </li>
                                            <li>
                                                <a href="innovate.php" class="link-light dropdown-item fs-3">Innovate</a>
                                            </li>
                                            <li>
                                                <a href="disrupt.php" class="link-light dropdown-item fs-3">Disrupt</a>
                                            </li>
                                            <li>
                                                <a href="transform.php" class="link-light dropdown-item fs-3">Transform</a>
                                            </li>
                                        </ul>
                                    </section>
                                    <section class="col-lg-4 col-md-12 col-sm-12 border-right" style="border-left: 1px solid #999">
                                        <ul class="mylist">
                                            <li>
                                                <div class="fs-6 p-3 pt-0 pb-0 text-success">
                                                    Trending technologies
                                                </div>
                                            </li>
                                            <li>
                                                <a href="ai_ml.php" class="link-light dropdown-item fs-5">AI and ML</a>
                                            </li>
                                            <li>
                                                <a href="data_science.php" class="link-light dropdown-item fs-5">Data Science</a>
                                            </li>
                                            <li>
                                                <a href="iot.php" class="link-light dropdown-item fs-5">IoT</a>
                                            </li>
                                            <li>
                                                <a href="low_code_ins.php" class="link-light dropdown-item fs-5">Low Code</a>
                                            </li>
                                            <li>
                                                <a href="api_ins.php" class="link-light dropdown-item fs-5">API-Management</a>
                                            </li>
                                            <li>
                                                <a href="aqt.php" class="link-light dropdown-item fs-5">AQT</a>
                                            </li>
                                            <li>
                                                <a href="cloud_ins.php" class="link-light dropdown-item fs-5">Cloud</a>
                                            </li>
                                            <li>
                                                <a href="agile_ins.php" class="link-light dropdown-item fs-5">Agile</a>
                                            </li>
                                            <li>
                                                <a href="devops_ins.php" class="link-light dropdown-item fs-5">DevOps</a>
                                            </li>
                                            <li>
                                                <a href="chaos_engineering.php" class="link-light dropdown-item fs-5">Chaos Engineering</a>
                                            </li>
                                            <li>
                                                <a href="data_mesh.php" class="link-light dropdown-item fs-5">Data Mesh</a>
                                            </li>
                                        </ul>
                                    </section>
                                    <section class="col-lg-4 col-md-12 col-sm-12 border-right" style="border-left: 1px solid #999">
                                        <ul class="mylist">
                                            <li>
                                                <div class="fs-6 p-3 pt-0 pb-0 text-success">Industry</div>
                                            </li>
                                            <li>
                                                <a href="automotive_ins.php" class="link-light dropdown-item">Automotive</a>
                                            </li>
                                            <li>
                                                <a href="banking_financial_ins.php" class="link-light dropdown-item">Banking and Financial
                                                    Services</a>
                                            </li>
                                            <li>
                                                <a href="insurance_ins.php" class="link-light dropdown-item">Insurance</a>
                                            </li>
                                            <li>
                                                <a href="energy_ins.php" class="link-light dropdown-item">Energy and Utilities</a>
                                            </li>
                                            <li>
                                                <a href="gaming_ins.php" class="link-light dropdown-item">Gaming and
                                                    Entertainment</a>
                                            </li>
                                            <li>
                                                <a href="isv_ins.php" class="link-light dropdown-item">ISV</a>
                                            </li>
                                            <li>
                                                <a href="life_science_ins.php" class="link-light dropdown-item">Life-sciences and
                                                    Healthcare</a>
                                            </li>
                                            <li>
                                                <a href="media_ins.php" class="link-light dropdown-item">Media and Publishing</a>
                                            </li>
                                            <li>
                                                <a href="retail_cpg_ins.php" class="link-light dropdown-item">Retail and CPG</a>
                                            </li>
                                            <li>
                                                <a href="telecommunications_ins.php" class="link-light dropdown-item">Telecommunications</a>
                                            </li>
                                            <li>
                                                <a href="travel_ins.php" class="link-light dropdown-item">Travel &amp; Logistics</a>
                                            </li>
                                            <li>
                                                <a href="industry_ins.php" class="link-light dropdown-item">Industry and Automation</a>
                                            </li>
                                            <li>
                                                <a href="non_profits_ins.php" class="link-light dropdown-item">Non-profits and
                                                    Education</a>
                                            </li>
                                            <li>
                                                <a href="public_sector_ins.php" class="link-light dropdown-item">Public Sector</a>
                                            </li>
                                        </ul>
                                    </section>
                                </div>
                            </div>
                        </li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="maintenance.php" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-expanded="false">
                        Maintenance
                    </a>
                </li>
            </ul>

            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        About us
                    </a>
                    <div class="text-light dropdown-menu p-3 pt-3 pb-3" aria-labelledby="navbarDropdownMenuLink">
                        <a class="link-light dropdown-item" href="canyoutrustus.php">Can you trust us
                        </a>

                        <a class="link-light dropdown-item" href="reasontojoin.php">10 reason to join
                        </a>
                    </div>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Careers
                    </a>
                    <ul class="text-light dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                        <li>
                            <a class="link-light dropdown-item" href="action.php">Action</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="another_action.php">Another action</a>
                        </li>
                        <li>
                            <a class="link-light dropdown-item" href="else_here.php">Something else here</a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="contact_us.php" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-expanded="false">
                        Contact us
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- End Header -->    <!-- End Header -->
    <section style="background-color: #13294B;padding: 100px 10px; height:400px ">
        <div class="container builddetails">
            <div id="acc-bgimg">
                <div class=" py-lg-0 p-5 order-2 order-lg-1 mt-3" data-aos="fade-right">
                    <a id=" " class="fs-3 text-white" href="">Thinking Breackthroughs</a> &nbsp;<a href="" class="text-success fs-3">Optimize</a>
                </div>
            </div>
        </div>
    </section>

    <section class="bg-white py-5 backPos container-fluid">
        <div class="backImg row">
            <div class="col-md-6 pad">
                <h5 class="fs-4 fst-italic text-capitalize text-success">Featured success story</h5>
                <h2 class="fs-2 fst-italic text-white">Upgrading CCM platform</h2>
                <a href="#" class="btn btn-success fst-italic rounded-pill">View success story</a>
            </div>
        </div>
    </section>

    <!-- featured insights -->
    <section class="container-fluid bg-white pt-1  mt-0 pb-5"> 
        <div class="container">
            <div class="featured1 mt-5 mb-5">
                <div class="row justify-content-center">
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Shift left the new savior.png" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Shift - left testing: The new savior for the automotive industry</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Feb 22, 2023</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/AdobeStock_304603275-min-AG.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Migrating legacy customer communications </p>
                                <span class="position-absolute"><a href="" class="text-success">Success Story</a> &nbsp;
                                    &nbsp; Feb 20, 2023</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/AdobeStock_274253442-min-AG.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Migrating legacy documents to Quadient Inspire</p>
                                <span class="position-absolute"><a href="" class="text-success">Success Story</a> &nbsp;
                                    &nbsp; Feb 20, 2023</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Nagarro_Blog_default_image_desktop.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-1 p-md-3 p-sm-3">Embracing futuristic APIs in insurance</p>
                                <span class="position-absolute"><a href="" class="text-success">Webinar</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/building a resilient ecommerce store for better customer experience.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-1 p-md-3 p-sm-3">Digitally resilient e-commerce stores with reliability testing</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Jan 12, 2023</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/impact of digital on telcos.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-1 p-md-3 p-sm-3">Enabling the exchange of financial knowledge in a virtual environment</p>
                                <span class="position-absolute"><a href="" class="text-success">Success Story</a> &nbsp;
                                    &nbsp; Jan 9, 2023</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section style="background-color: #CBBFE2;">
        <div class="row" style="--bs-gutter-x: -0.5rem;">
            <div class="col-lg-6 col-md-6 col-sm-12 m-auto px-5 py-5 py-lg-0">
                <h4 class="text-black-50">Event Series</h4>
                <h1 class="fs-1 py-3">Sommelier by ICEICO</h1>
                <p class="text-black-50">The Sommelier series pairs speakers from different backgrounds and expertise to create the perfect exchange. The goal is simple, they talk, engage, and discuss. Inspiration is sure to follow.</p>
                <div class="d-grid d-md-block gap-2">
                    <button class="btn btn-primary fs-5 rounded-pill" type="button">Know More</button>
                    <button class="btn btn-outline-primary fs-5 rounded-pill" type="button">View all events</button>
                </div>
            </div>
            <div class="col-md-6 col-sm-12 col-lg-6">
                <img src="assets/img/team.png" alt="team" style=" max-width: 100%;">
            </div>
        </div>
    </section>

    <!-- featured insights -->
    <section class="container-fluid bg-white pt-1  mt-0 pb-5">
        <div class="container">
            <div class="featured1 mt-5 mb-5">
                <div class="row justify-content-center">
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Apis-in-insurance-Panel-discussion-D-min.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Embracing futuristic APIs in insurance</p>
                                <span class="position-absolute"><a href="" class="text-success">Webinar</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Integrating data and advanced analytics in decision-making.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Integrating data and advanced analytics in decision-making </p>
                                <span class="position-absolute"><a href="" class="text-success">Success Story</a> &nbsp;
                                    &nbsp; Dec 23, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/DevOps 2022-Banner Desktop.png" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">State of DevOps Report 2022</p>
                                <span class="position-absolute"><a href="" class="text-success">White Paper</a> &nbsp;
                                    &nbsp; Dec 21, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Adopt GreenOps for cloud sustainability-1.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">GreenOps: Reducing cloud spends and enhancing cloud sustainability</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Dec 8, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Accelerating-Digitalization-Through-Low-code-D-min.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Accelerating digitalization through low-code</p>
                                <span class="position-absolute"><a href="" class="text-success">Webinar</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Minimize cloud costs with FinOps.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Optimizing cloud costs</p>
                                <span class="position-absolute"><a href="" class="text-success">Success Story</a> &nbsp;
                                    &nbsp; Dec 1, 2022</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row" id="myRow">
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Building a Data Lakehouse solution on Azure and Databricks for better reporting, visualization, and insights.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Initiating data-driven deccision-making</p>
                                <span class="position-absolute"><a href="" class="text-success">Success Story</a> &nbsp;
                                    &nbsp; 7 Sep 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/K-12 education.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">K -12 education: Challenges, approaches, and the way forward</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Sep 6, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/data mesh explained_data architecture-1.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Data mesh explained: Redefining enterprise data architecture</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Aug 16, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/MicrosoftTeams-image (13)-4.png" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">XPLOR 22: The Customer Communications event</p>
                                <span class="position-absolute"><a href="" class="text-success">Event</a> </span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/impact of sales enablement with automation.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Maximizing the impact of sales enablement with automation</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Aug 1, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Star Alliance_Creating an intuitive, rich UI and state-of-the-art CMS portal.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Evolving in the digital landscape</p>
                                <span class="position-absolute"><a href="" class="text-success">Success Story</a> &nbsp;
                                    &nbsp; Jul 26, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/measure fundraising success of nonprofits.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">7 essential KPIs for measuring fundraising success of non-profits</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Jul 18, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Web3-Desk-min.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">What is Web3 - a beginner's guide</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Jul 15, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Edge-computing-D-min.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Computing in the fog: From cloud to edge</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; May 4, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Nagarro_Blog_default_image_desktop.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Leveraging Artificial Intelligence for Insurance Claims</p>
                                <span class="position-absolute"><a href="" class="text-success">Webinar</a> </span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/sap-s4hana-blog.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Temenos Community Forum 2022</p>
                                <span class="position-absolute"><a href="" class="text-success">Event</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Nagarro_Blog_default_image_desktop.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Intelligent decision - making to create a competitive advantage</p>
                                <span class="position-absolute"><a href="" class="text-success">Webinar</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Money_2020.png" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Money 2020</p>
                                <span class="position-absolute"><a href="" class="text-success">Event</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/intelligent decision-making_desktop.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Decision Intelligence: AI & Data-driven decision making</p>
                                <span class="position-absolute"><a href="" class="text-success">White Paper</a> &nbsp;
                                    &nbsp; Apr 5, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Building a 360-degree customer view_Banner.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Building a 360-degree customer view</p>
                                <span class="position-absolute"><a href="" class="text-success">Success Story</a> &nbsp;
                                    &nbsp; Mar 29, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Innovation with value based portfolio management-SS_Tile.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Driving Innovation with value-based Portfolio Management</p>
                                <span class="position-absolute"><a href="" class="text-success">Success Story</a> &nbsp;
                                    &nbsp; Mar 17, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Quality 4.0 – evolution, principles, and tools for implementation-D-min.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Journey to Quality 4.0 - Its evolution, principles, and tools for implementation</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Mar 15, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/DevOps for databases-d-1-min.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">DevOps for databases: How to do it right?</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Mar 11, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Omnichannel sales in B2B-D-min.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">B2B commerce goes omnichannel</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Mar 10, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/AdobeStock_280704717_banner.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Modernize and refactor using microservices architecture</p>
                                <span class="position-absolute"><a href="" class="text-success">Success Story</a> &nbsp;
                                    &nbsp; Mar 7, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/AdobeStock_359397898_Open_Banking_WhitePaper_Banner.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Embracing Open Banking</p>
                                <span class="position-absolute"><a href="" class="text-success">White Paper</a> &nbsp;
                                    &nbsp; Mar 4, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Nasscom report on Low Code No Code India.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Low Code No Code</p>
                                <span class="position-absolute"><a href="" class="text-success">White Paper</a> &nbsp;
                                    &nbsp; Mar 4, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Avista_banner-new4.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Predictive and intelligent decision support for Avista</p>
                                <span class="position-absolute"><a href="" class="text-success">Success Story</a> &nbsp;
                                    &nbsp; Mar 1, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Choosing the right strategy for Industrial IoT and a resilient smarter factory-D-min.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Choosing the right Industrial IoT(IIOT) strategy to be a resilient Smart Factory</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Feb 26, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/apim-aviation-webinar-airline newsletter.png" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Building a future - ready airline based on API Management</p>
                                <span class="position-absolute"><a href="" class="text-success">Webinar</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/apim-aviation-webinar-2.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">APIs - the digital gateway to a modern airline</p>
                                <span class="position-absolute"><a href="" class="text-success">White Paper</a> &nbsp;
                                    &nbsp; Feb 25, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Smart Ticketing – Enabling multi-modality-D-min.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Smart ticketing revolution as an enabler for multi-modality</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Feb 22, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/thumb.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Connected worker 4.0 - The future workforce, Michel Dorochevsky, ICEICO</p>
                                <span class="position-absolute"><a href="" class="text-success">Talk</a> &nbsp;
                                    &nbsp; Feb 5, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/PALFINGER_Loader_Cranes_20200312-PK48002TEC7_3-500_Operator_Bildschirm-D-min.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Digitalizing the visual inspection process</p>
                                <span class="position-absolute"><a href="" class="text-success">Success Story</a> &nbsp;
                                    &nbsp; Feb 4, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/MicrosoftTeams-image (23)-2.png" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Sustainable Shipping : Enable solutions for a greener future</p>
                                <span class="position-absolute"><a href="" class="text-success">White Paper</a> &nbsp;
                                    &nbsp; Jan 31, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/mobile apps for sales and dealers_desktop.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Enabling agility in sales processes and dealer engagement</p>
                                <span class="position-absolute"><a href="" class="text-success">Success Story</a> &nbsp;
                                    &nbsp; Jan 29, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/legacy and modernization.png" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Legacy modernization for exponential growth</p>
                                <span class="position-absolute"><a href="" class="text-success">Success Story</a> &nbsp;
                                    &nbsp; Jan 26, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/building resilience for power utilities to manage threats_mobile.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Digitally reinforced business resilience</p>
                                <span class="position-absolute"><a href="" class="text-success">White Paper</a> &nbsp;
                                    &nbsp; Jan 25, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Swiss2.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Building a smarter factory with SAP re-engineering and AI</p>
                                <span class="position-absolute"><a href="" class="text-success">Success Story</a> &nbsp;
                                    &nbsp; Jan 15, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Banking-D-min.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Traditional banking in modern times</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Jan 12, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/MicrosoftTeams-image (59).jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Hyperautomation - Putting people at the center again</p>
                                <span class="position-absolute"><a href="" class="text-success">White Paper</a> &nbsp;
                                    &nbsp; Dec 1, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Web.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Banking in transition - Embracing API-enabled business transformation</p>
                                <span class="position-absolute"><a href="" class="text-success">White Paper</a> &nbsp;
                                    &nbsp; Nov 2, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Article_Ideation to adoption_Header image.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Ideation to adoption : A framework approach to enable Assisted Reality field trials</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Oct 31, 2021</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/New Distribution Capability in Airlines-D-min.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Choreographing the New Distribution Capability ecosystem</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Oct 26, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Low-code.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Making process digitalization a reality</p>
                                <span class="position-absolute"><a href="" class="text-success">Success Story</a> &nbsp;
                                    &nbsp; Oct 25, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/low code.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">To low-code or not to low-code?</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Oct 19, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/AutomotiveHomepage_Background.png" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Create next-gen shared mobility solutions</p>
                                <span class="position-absolute"><a href="" class="text-success">White Paper</a> &nbsp;
                                    &nbsp; Oct 18, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/AdobeStock_305628557_banner.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Automotive OEM 2.0</p>
                                <span class="position-absolute"><a href="" class="text-success">White Paper</a> &nbsp;
                                    &nbsp; Oct 5, 2021</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Devops_banner-new.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">A holistic approach to DevOps</p>
                                <span class="position-absolute"><a href="" class="text-success">White Paper</a> &nbsp;
                                    &nbsp; Sep 10, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Mask Group-2.png" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Intelligent Enterprise : AI - Enabled Diggerntiation is now!</p>
                                <span class="position-absolute"><a href="" class="text-success">Event</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Tesvolt_Digital_transformation-new.png" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Digital transformation journey and remote academy roll out</p>
                                <span class="position-absolute"><a href="" class="text-success">Success Story</a> &nbsp;
                                    &nbsp; Jul 8, 2021</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Automated feed generation_public broadcaster.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Feed Generator System for a leading public broadcaster</p>
                                <span class="position-absolute"><a href="" class="text-success">Success Story</a> &nbsp;
                                    &nbsp; Jul 8, 2021</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/AIML_telcos.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">AI & ML for Telecom</p>
                                <span class="position-absolute"><a href="" class="text-success">White Paper</a> &nbsp;
                                    &nbsp; Jul 2, 2021</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/LMS-Blog-D-min.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Which Learning Management System (LMS) solution suits you best?</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Jun 22, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/RPA-Banking-D-min.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">"Banking" on Robotic Process Automation (RPA)</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Jun 18, 2021</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/EB-banner.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Digitizing wind turbine inspections using smart glass</p>
                                <span class="position-absolute"><a href="" class="text-success">Success Story</a> &nbsp;
                                    &nbsp; Jun 7, 2021</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/KYC-Conundrum-D-min.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Helping BFSI navigate the KYC conudrum</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Jun 4, 2021</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Responsible-Casino-Gaming-D-min.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Responsible casino gaming: Do not ignore the fine print</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; May 10, 2021</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Airbus-A330300-at-JFK-International-Airport-000022830961_Full (2)-new.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Taking flight : Designing automated test frameworks</p>
                                <span class="position-absolute"><a href="" class="text-success">Success Story</a> &nbsp;
                                    &nbsp; Apr 28, 2021</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Intelligent-Supply-Chain-D.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Intelligent supply chains: Moving from fragmented to coordinated management</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Apr 20, 2021</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Automic_Case_Study_banner1-1.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Adapting to change with Salesforce Service Cloud</p>
                                <span class="position-absolute"><a href="" class="text-success">Success Story</a> &nbsp;
                                    &nbsp; Apr 14, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/AdobeStock_403024148.jpeg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Seismic : Long-term partnership building a market-leading SaaS company</p>
                                <span class="position-absolute"><a href="" class="text-success">Success Story</a> &nbsp;
                                    &nbsp; Apr 14, 2021</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/AdobeStock_341429186.jpeg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Leveraging AI for automated vehicle evaluation</p>
                                <span class="position-absolute"><a href="" class="text-success">Success Story</a> &nbsp;
                                    &nbsp; Apr 13, 2021</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/EdgeComputing for Oil-Gas-Banner-desk-min.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Edge computing for oil and gas companies</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Mar 31, 2021</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/legacy and modernization.png" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Legacy system modernization : Top drivers and approaches</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Mar 8, 2021</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/VirtualEventsPlatform-Desk-min.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">7 essential features of a virtual event platform</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Feb 11, 2021</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Request to Pay-desk-min.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Request to Pay - A peek into the future of payments</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Feb 4, 2021</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/JiraCloud-Desk.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Is migrating to Jira Cloud a good move?</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Jan 29, 2021</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Atlassian Landing Page Banner.png" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">From server to Cloud: Proven strategies for a successful migration</p>
                                <span class="position-absolute"><a href="" class="text-success">Webinar</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/robot hand and human hand signifying test automation.jpeg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Intelligent automation beyond test execution with AI4T</p>
                                <span class="position-absolute"><a href="" class="text-success">Webinar</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Insurance-customer-B-min.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Moving towards a customer - focused and agile insutance business</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Oct 31, 2020</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/TestAutomation-Web.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Microsoft Dynamics 365 : Key considerations for test automation</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Sep 16, 2020</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/8_1272x550.png" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Harnessing tech for humanity : How non-profits can go mobile</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Jun 12, 2020</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/legacy code refactoring in test automation-B.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Legacy code factoring in test automation</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Jun 5, 2020</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Tips to take your business online amid COVID-19 crisis-1.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">The new normal : Taking your business online. Are you ready?</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Apr 29, 2020</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Role Of Microfinance (MFIs) In Financial Inclusion-B.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Nothing too small about it: The role of MFIs in financial inclusion</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Apr 24, 2020</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/impact of digital on telcos.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Finding new revenue streams: The impact of digital transformation on telcos</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Jan 30, 2020</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Enhance Airline Passenger Experience with Augmented Reality.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Augmented reality in Aviation: Emhancing passenger experience</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Jan 22, 2020</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Omnichannel_Banner.webp" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">You are special : Delivering a personalized customer experience through omnichannel e-commerce</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp;
                                    &nbsp; Nov 20, 2019</span>
                            </div>
                        </div>
                    </div>
                </div>
                <button id="loadMore" class="btn btn-outline-success fs-5 rounded-pill w-100">Load More Items</button>
            </div>
        </div>
    </section>

    <section class="container-fluid bg-white py-5">
        <div class="container">
            <div class="featured1 mt-5 mb-5">
                <h2 class="pb-5 text-center text-capitalize">Other content that may interest you</h2>
                <div class="row justify-content-center">
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/8 recipes blog testing_tile-1 (1).jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Eight recipes to get your testing to the next level</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp; &nbsp; Oct 07, 2022</span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Oracle CPQ featured.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Oracle CPQ chatbot for swift quoting</p>
                                <span class="position-absolute"><a href="" class="text-success">Accelerator</a></span>
                            </div>
                        </div>
                    </div>
                    <div class="card1 col-lg-4  col-11 p-sm-1 ">
                        <div class="card2 m-lg-3 m-md-3 m-sm-3 m-2 border position-relative">
                            <div class=" HoverDiv">
                                <img class="card-img-top w-100 img" src="assets/img/Gaming-Development-M-min.jpg" alt="Card image cap">
                            </div>
                            <div class="card-body">
                                <p class="card-text text-dark p-md-3 p-sm-3 p-2">Conquering new horizons in gaming: Compliance, geo - fencing, and real-world testing</p>
                                <span class="position-absolute"><a href="" class="text-success">Article</a> &nbsp; &nbsp; Oct 04, 2022</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- feature topic -->
    <section class="bg-white py-5">
        <h2 class="pb-5 text-center text-capitalize">Our Partners</h2>
        <div class="container-1 mt-5">
            <div class="slide-container">
                <div class="slide-img d-block text-center">
                    <h3 class="fs-5 fst-italic">Agile</h3>
                </div>
                <div class="slide-img d-block text-center">
                    <h3 class="fs-5 fst-italic">Life at ICEICO</h3>
                </div>
                <div class="slide-img d-block text-center">
                    <h3 class="fs-5 fst-italic">Coronavirus</h3>
                </div>
                <div class="slide-img d-block text-center">
                    <h3 class="fs-5 fst-italic">Innovation</h3>
                </div>
                <div class="slide-img d-block text-center">
                    <h3 class="fs-5 fst-italic">Cloud</h3>
                </div>
                <div class="slide-img d-block text-center">
                    <h3 class="fs-5 fst-italic">Digital Transformation</h3>
                </div>
                <div class="slide-img d-block text-center">
                    <h3 class="fs-5 fst-italic">DevOps</h3>
                </div>
                <div class="slide-img d-block text-center">
                    <h3 class="fs-5 fst-italic">Business Intelligence</h3>
                </div>
                <div class="slide-img d-block text-center">
                    <h3 class="fs-5 fst-italic">Agile</h3>
                </div>
                <div class="slide-img d-block text-center">
                    <h3 class="fs-5 fst-italic">Life at ICEICO</h3>
                </div>
                <div class="slide-img d-block text-center">
                    <h3 class="fs-5 fst-italic">Coronavirus</h3>
                </div>
                <div class="slide-img d-block text-center">
                    <h3 class="fs-5 fst-italic">Innovation</h3>
                </div>
                <div class="slide-img d-block text-center">
                    <h3 class="fs-5 fst-italic">Cloud</h3>
                </div>

            </div>
        </div>
    </section>

    <!-- //user Review  -->
    <section class="py-3">
  <div class="container  responsive-container text-center">
    <h2 class="fs-2 pt-2 pt-5 text-center text-light">Our Community With User Review</h2>
    <div class="m-md-5 py-5 py-lg-0 py-md-0 row user-review-background">

      <div class="col-12 col-lg-4 col-sm-12 mt-0 mt-lg-5 mt-md-5 ps-sm-5 pt-sm-5"><img src="assets/img/Group 1.png" class="ellipseimg pt-0" alt="" width="150" height="100"></div>
      <div class="col-12 col-lg-5 col-sm-12 offset-lg-0 p-lg-5 text-center user-prghp" style="height: 240px;">
        <p>The system has produced a significant competitive advantage in the industry thanks to ICEICO Technologies well-thought opinions.

They shouldered the burden of constantly updating a project management tool with a high level of detail and were committed to producing the best possible solution. <br>-Amol Ramteke, Business Owner of Carbonblack.education</p>

      </div>

    </div>
  </div>

</section>

    <!-- footer section  start-->
    

<div class="mt-4">
  <div class="footer footer-bg">
    <div class="container ">
      <div class="row">
        <div class="col-sm-6 p-md-5 p-sm-2 text-center">
          <h3 style="color:white;">Contact Us</h3>
          <p style="color:#0fc88a;">ICEICO TECHNOLOGIES PVT. LTD. <br> Plot No. 91, Ganesh Nagar, Azamshah Layout, Nandanwan, Nagpur, Maharashtra 440009 </p>
         
        </div>


        <div class="col-sm-6 p-5 text-center">
          <div>
            <h3 style="color:white ;">NEWSLETTER</h3>
          </div>
          <div>
            <!--<span><input type="Email" class="emailform " placeholder="Email Address"><button class="formbutton">Submit</button></span>-->
            <div class="input-group mx-auto w-50">
                <input type="email" class="form-control emailform bg-transparent text-white" placeholder="Email Address" aria-label="Input group example" aria-describedby="btnGroupAddon" >
                <button class="input-group-text formbutton px-2" id="btnGroupAddon">Submit</button>    
            </div>

          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-sm-6 p-md-5  ">
          <div class="row">
            <div class="col-sm-6 col-12 p-3 text-center">
              <ul style="list-style-type:none;">
                <caption><span class="cptndetail"><b>About Us</b></span></caption>
                <li class="p-3"><a class="listdetails" href="">Whitepaper</a></li>
                <li class="p-3"><a class="listdetails" href="blog.php">Blog</a></li>
                <li class="p-3"><a class="listdetails" href="">Activity</a></li>

              </ul>
            </div>


            <div class="col-sm-6 col-12 p-md-3 text-center">
              <ul style="list-style-type:none;">
                <caption><span class="cptndetail"><b>support</b></span></caption>
                <li class="p-3"><a class="listdetails" href="">Author Profile</a></li>
                <li class="p-3"><a class="listdetails" href="">Community</a></li>
                <li class="p-3"><a class="listdetails" href="">Help & support</a></li>
                <li class="p-3"><a class="listdetails" href="contact_us.php">Contact</a></li>

              </ul>
            </div>
          </div>

        </div>
        <div class="col-sm-6 p-5 text-center">
          <h3 class="mt-5" style="color: white;">Social Media</h3>
          <div class="mt-2">
            <i class="bi bi-facebook p-2"></i>
            <i class="bi bi-twitter p-2"></i>
            <i class="bi bi-instagram p-2"></i>
          </div>
        </div>

      </div>
    </div>


  </div>
</div>    </section>

    <script src="assets/vendor/aos/aos.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
    <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
    <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
    <script src="assets/vendor/php-email-form/validate.js"></script>
    <script src="assets/js/main.js"></script>
    <script src="assets/js/loadMore.js"></script>
</body>

</html>